# K05 — Muted-First Resilience (MFR)

## Claim

Sound-off viewers need overlays that can carry gist independently.

## Source support

S03; S01

## Methods that rely on this kernel

MFM; DLC; SCC; BCC+

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Muted viewers fail gist/action recall even when overlay is present.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
