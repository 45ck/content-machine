# ACC-009 / RSA — Reader-Speed Adaptive Mode

## Definition

Allow overlays to persist longer or simplify if viewer often pauses/rewatches.

## Method family

- Category: Personalization / Access
- Family: Accessibility and Personalization
- Class: Rule / Mode
- Phase: Explore later
- Priority: P3

## Proof claim

Should beat baseline on target metric.

## Mechanism bundle

AR; DLA

## Evidence grade

- Existing grade: Speculative / future
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

current best baseline

## Minimum viable experiment

Manual slow/fast versions.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Platform data may be inaccessible.

## Source IDs

S06; S16
