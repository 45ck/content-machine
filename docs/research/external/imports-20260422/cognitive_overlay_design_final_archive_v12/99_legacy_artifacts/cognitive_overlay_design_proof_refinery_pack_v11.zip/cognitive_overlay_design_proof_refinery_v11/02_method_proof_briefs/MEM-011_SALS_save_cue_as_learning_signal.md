# MEM-011 / SALS — Save Cue as Learning Signal

## Definition

Use a save-worthy rule card, not a begging call-to-action.

## Method family

- Category: Memory / Learning
- Family: Memory and Learning
- Class: Learning Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves delayed/action recall or save intent.

## Mechanism bundle

SIG; VWM

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

no memory prompt; payoff card only

## Minimum viable experiment

Rule card vs generic CTA.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Can feel manipulative if overused.

## Source IDs

S25
