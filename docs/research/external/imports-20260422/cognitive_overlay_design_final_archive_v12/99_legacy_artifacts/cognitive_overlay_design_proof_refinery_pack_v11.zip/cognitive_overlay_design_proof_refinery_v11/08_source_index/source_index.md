# Source Index

## S01 — W3C WAI: Captions/Subtitles

- Field: Accessibility / Captions
- URL: https://www.w3.org/WAI/media/av/captions/
- Key finding: Captions are synchronized text versions of speech and needed non-speech audio.
- Supports: DLC, CCP, NSS, accessibility guardrails

## S02 — Section 508: Captions and Transcripts

- Field: Caption speed / Standards
- URL: https://www.section508.gov/create/captions-transcripts/
- Key finding: Speech above about 180 words per minute may be too fast for captions; keep captions short.
- Supports: SCC, CRL, MEG, VLAC

## S03 — Szarkowska et al. 2024, PLOS ONE: sound-off subtitled video

- Field: Sound-off viewing
- URL: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0306251
- Key finding: Sound-off subtitled viewing increased cognitive load and reduced comprehension, immersion and enjoyment; viewers processed subtitles more heavily.
- Supports: MFM, DLC, SCC, BCC+

## S04 — Kruger et al.: Why subtitle speed matters

- Field: Subtitle speed / Eye tracking
- URL: https://www.cambridge.org/core/journals/applied-psycholinguistics/article/why-subtitle-speed-matters-evidence-from-word-skipping-and-rereading/A7DB0CBF5910353143738CF9C1721317
- Key finding: Higher subtitle speed can reduce comprehension, increase incomplete reading and reduce rereading.
- Supports: SCC, CRL, MEG, MRR, VLAC

## S05 — Mirzaei et al. 2017: Partial and Synchronized Captioning

- Field: Partial captions
- URL: https://www.cambridge.org/core/journals/recall/article/partial-and-synchronized-captioning-a-new-tool-to-assist-learners-in-developing-second-language-listening-skill/9394E3F0AD25FD5F32895F965F7ECCAD
- Key finding: Partial synchronized captions produced full-caption-level comprehension while presenting less than 30% of transcript in an L2 context.
- Supports: SCC, CRL, KMC, GET

## S06 — Kafle et al. 2019 ASSETS: Highlighting key words in captions

- Field: Keyword highlighting / DHH captions
- URL: https://dl.acm.org/doi/10.1145/3308561.3353781
- Key finding: Highlighted keywords were rated easier to read/follow and lower task load by DHH participants.
- Supports: SKH, FOA, BCA, KHT

## S07 — Schneider et al. 2018: Signaling meta-analysis

- Field: Multimedia learning / Signaling
- URL: https://www.sciencedirect.com/science/article/abs/pii/S1747938X17300581
- Key finding: Signaling benefits retention and transfer, affects eye fixations and reduces cognitive load.
- Supports: OFC, PCFB, TBSM, SCC, BCC+

## S08 — Richter et al. 2016: text-picture signaling meta-analysis

- Field: Multimedia learning / Signaling
- URL: https://www.sciencedirect.com/science/article/abs/pii/S1747938X15000664
- Key finding: Cues that highlight organization of relevant information can improve retention/transfer.
- Supports: PCFB, TBSM, REN, CEP

## S09 — Henderson & Hayes 2018: Meaning maps and attention

- Field: Meaning-guided attention
- URL: https://www.nature.com/articles/s41598-018-31894-5
- Key finding: Meaning maps predict attention in real-world scenes beyond low-level salience.
- Supports: MMP, SAP, GSP, ASOE

## S10 — Schwetlick & Harrison 2024/2025 review: Visual Crowding

- Field: Visual crowding
- URL: https://www.annualreviews.org/content/journals/10.1146/annurev-vision-110423-024409
- Key finding: Crowding impairs perception when objects/letters are surrounded by clutter.
- Supports: CAC, CBU, STB, CCD

## S11 — Stewart et al. 2020: peripheral and foveal interactions

- Field: Peripheral/foveal vision
- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC7645222/
- Key finding: Peripheral and foveal signals are integrated across saccades; detailed recognition depends on foveal/parafoveal sampling.
- Supports: FAP, GSP, VLAW

## S12 — Luck & Vogel 2013: Visual working memory capacity

- Field: Visual working memory
- URL: https://www.sciencedirect.com/science/article/abs/pii/S1364661313001265
- Key finding: Visual working memory is capacity-limited and varies across individuals.
- Supports: OIOS, MRR, PCFB, TBSM

## S13 — Dias et al. 2016: Visibility of speech articulation

- Field: Audiovisual speech
- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC8081648/
- Key finding: Visual speech information can compensate when auditory speech is degraded.
- Supports: MSC, ESC, GSP

## S14 — Snell 2024: No, Bionic Reading does not work

- Field: Bionic Reading
- URL: https://www.sciencedirect.com/science/article/pii/S0001691824001811
- Key finding: No significant reading-time benefit between Bionic and normal text.
- Supports: BCA as weak/optional; HBF negative control

## S15 — Možina et al. 2025: Usability of Bionic Reading

- Field: Bionic Reading / Eye tracking
- URL: https://journals.sagepub.com/doi/10.1177/21582440251376158
- Key finding: No clear speed/comprehension advantage; bionic formatting produced more saccades and longer reading time in some conditions.
- Supports: HBF negative control; BCA dose testing

## S16 — Brown et al. 2015: Dynamic Subtitles user experience

- Field: Dynamic subtitles
- URL: https://research.manchester.ac.uk/en/publications/dynamic-subtitles-the-user-experience/
- Key finding: Dynamic subtitles produced gaze patterns closer to no-subtitle baseline than traditional subtitles in the study.
- Supports: SFC, GSP, DRAR

## S17 — AIM 2024 / AViMoS video saliency prediction challenge

- Field: Video saliency prediction
- URL: https://arxiv.org/abs/2409.14827
- Key finding: AViMoS provides 1,500 videos with observer data, including vertical videos; saliency prediction is technically mature enough to inform placement.
- Supports: SHP, SAP, ASOE, VLP

## S18 — Lee 2023: Learning benefits of moving text

- Field: Kinetic typography
- URL: https://www.nature.com/articles/s41599-023-01646-6
- Key finding: Moving text can help when aligned with logic, but excessive/inappropriate kinetic typography can cause fatigue and overload.
- Supports: LM, PRL, DKC, MBS

## S19 — Caption Royale 2024: affective captions for DHH users

- Field: Affective captions
- URL: https://dl.acm.org/doi/10.1145/3613904.3642258
- Key finding: Affective captions use typographic modulation to convey emotion; explored with DHH participants.
- Supports: PAE, TI, affective-semantic variants

## S20 — Gerber-Morón et al. 2018: subtitle line breaks

- Field: Subtitle segmentation
- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC7733619/
- Key finding: Viewers preferred syntactically segmented line breaks; linguistic segmentation affects processing.
- Supports: SLB, OIOS, SLSB

## S21 — Duraj & Szarkowska 2025: non-standard TikTok subtitle styles

- Field: TikTok subtitle style
- URL: https://www.jatjournal.org/index.php/jat/article/view/339
- Key finding: TikTok subtitle style with emojis/non-standard typography affected preference and engagement in reported studies.
- Supports: PNT, ENS, platform-native variants

## S22 — Alruwaili 2025: scroll immersion and short-form video use

- Field: Short-form cognition
- URL: https://www.sciencedirect.com/science/article/pii/S0001691825009874
- Key finding: Short-form use and scroll immersion predicted attention difficulty, working-memory disruption and cognitive fatigue in survey data.
- Supports: FPR, HOO, MRR, ERF

## S23 — Fallon et al. 2024 Science Advances: Language at a glance

- Field: Phrase structure / Rapid language
- URL: https://www.science.org/doi/10.1126/sciadv.adr9951
- Key finding: The left temporal cortex detects rough syntactic structure starting as early as 125 ms after visual multiword expression onset.
- Supports: OFC, CPC, PCFB, KMC

## S24 — Nielsen Norman Group 2024: A/B Testing 101

- Field: A/B testing
- URL: https://www.nngroup.com/articles/ab-testing/
- Key finding: A/B testing compares design variations with live audiences against predetermined success metrics.
- Supports: ABG, proof ladder, platform validation

## S25 — NN/g 2026: Statistical significance is not practical significance

- Field: Practical significance
- URL: https://www.nngroup.com/articles/practical-significance/
- Key finding: Results must be reliable and worth acting on; statistical significance alone is insufficient.
- Supports: decision rules, MDEs

## S26 — Kumar et al. 2024: adaptive bandit experiments

- Field: Contextual bandits
- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC11044947/
- Key finding: Bandit algorithms adapt assignment based on collected data and context.
- Supports: ASOE, AR, VSA

## S27 — Lakens 2024: benefits of preregistration and Registered Reports

- Field: Preregistration
- URL: https://www.tandfonline.com/doi/full/10.1080/2833373X.2024.2376046
- Key finding: Registered Reports move peer review earlier so feedback happens before data collection.
- Supports: proof contract, prereg templates

## S28 — Kishore et al. 2020: superiority, noninferiority, equivalence

- Field: Equivalence / non-inferiority
- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC7734976/
- Key finding: Non-inferiority/equivalence designs answer different questions from superiority designs and require margins.
- Supports: accessibility non-regression and visual recall guardrails

## S29 — WCAG 2.2 contrast minimum understanding

- Field: Contrast accessibility
- URL: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html
- Key finding: Sufficient contrast is needed so text can be read by people with moderately low vision or contrast impairment.
- Supports: ACAC, FLCC, CBU
