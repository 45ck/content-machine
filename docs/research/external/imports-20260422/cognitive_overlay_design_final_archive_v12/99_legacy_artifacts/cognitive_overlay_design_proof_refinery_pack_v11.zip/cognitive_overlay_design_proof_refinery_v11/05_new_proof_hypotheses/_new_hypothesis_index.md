# New Proof Hypotheses

- **NH-001 — Syntax-At-A-Glance Captions**
- **NH-002 — Dual-Outcome Overlay Design**
- **NH-003 — Cognitive Saccade Budget**
- **NH-004 — ROI Obstruction Tax**
- **NH-005 — Crowding Margin Rule**
- **NH-006 — Bionic Dose Response Curve**
- **NH-007 — Semantic Precue Window**
- **NH-008 — Muted First Compression Floor**
- **NH-009 — Action Mode Minimal Labels**
- **NH-010 — Meaning-Map Placement Beats Saliency Pop**
- **NH-011 — Memory Stamp Final Frame**
- **NH-012 — Affective Load Boundary**
- **NH-013 — Micro-Rest Eye Recovery**
- **NH-014 — Line-Break Syntax Effect in Short Form**
- **NH-015 — Platform-Native vs Trust-Safe Tradeoff**
