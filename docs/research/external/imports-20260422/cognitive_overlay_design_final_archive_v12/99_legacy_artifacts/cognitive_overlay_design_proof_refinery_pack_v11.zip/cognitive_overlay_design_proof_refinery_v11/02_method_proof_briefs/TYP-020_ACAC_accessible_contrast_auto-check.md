# TYP-020 / ACAC — Accessible Contrast Auto-Check

## Definition

Auto-check caption/backplate contrast per frame.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Pilot first
- Priority: P0

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Manual vs auto contrast corrected.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May force ugly backplates in complex frames.

## Source IDs

S28; S15
