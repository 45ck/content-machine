# NH-007 — Semantic Precue Window

## Mechanism

Find timing window where prediction helps without causing mismatch.

## Minimum test

pre 600/400/200ms vs sync/post.

## Source IDs

S23; S04

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
