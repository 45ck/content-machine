# TYP-005 / SLB — Semantic Line Breaks

## Definition

Break lines by meaning, not by width alone.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Pilot second
- Priority: P1

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Natural vs arbitrary line breaks.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Poor breaks hurt grammar comprehension.

## Source IDs

S02; S04; S09
