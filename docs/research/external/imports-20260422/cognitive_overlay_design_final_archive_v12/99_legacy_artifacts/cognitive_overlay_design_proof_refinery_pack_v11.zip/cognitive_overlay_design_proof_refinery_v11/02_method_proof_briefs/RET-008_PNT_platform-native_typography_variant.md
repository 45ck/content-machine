# RET-008 / PNT — Platform-Native Typography Variant

## Definition

Test clean professional vs TikTok-native emoji/non-standard style.

## Method family

- Category: Platform / Retention
- Family: Platform Retention
- Class: Retention Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves early hold/completion while preserving comprehension.

## Mechanism bundle

PNF; AR

## Evidence grade

- Existing grade: Emerging direct evidence
- Proof grade: G-2E: emerging direct evidence
- Proof level needed: P0/P1 pilot only

## Comparator

standard caption style

## Minimum viable experiment

Clean vs native style.

## Primary metrics

gist recall; action recall; perceived effort; 3s hold; completion; saves

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Can reduce professionalism/accessibility.

## Source IDs

S21; S28
