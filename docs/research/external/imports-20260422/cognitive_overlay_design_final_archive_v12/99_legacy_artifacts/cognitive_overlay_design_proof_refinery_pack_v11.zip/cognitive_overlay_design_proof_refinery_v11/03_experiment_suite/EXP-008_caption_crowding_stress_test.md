# EXP-008 — Caption Crowding Stress Test

## Purpose

Prove crowding-aware placement and plates.

## Conditions

clean background; patterned background; UI conflict; plate; outline; dim window

## Primary metric

readability rating + recognition accuracy

## Secondary metrics

effort; text dwell

## Decision rule

CAC/CBU/BBAP pass if readability improves in clutter without reducing trust.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
