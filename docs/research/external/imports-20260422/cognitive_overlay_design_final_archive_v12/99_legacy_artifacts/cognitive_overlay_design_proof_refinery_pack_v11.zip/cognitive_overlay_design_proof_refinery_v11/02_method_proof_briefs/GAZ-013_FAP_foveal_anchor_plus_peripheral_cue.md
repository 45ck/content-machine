# GAZ-013 / FAP — Foveal Anchor + Peripheral Cue

## Definition

Put readable text centrally; use peripheral arrows/icons for orientation.

## Method family

- Category: Placement / Gaze
- Family: Placement and Gaze
- Class: Placement Method
- Phase: Explore later
- Priority: P2

## Proof claim

Preserves visual recall and reduces gaze travel/conflict.

## Mechanism bundle

GSPM; CRD; FPA

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

bottom-fixed placement; random safe placement

## Minimum viable experiment

Text-only vs text+peripheral cue.

## Primary metrics

gist recall; action recall; perceived effort; visual recall; text-face/object dwell ratio

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Could increase visual complexity.

## Source IDs

S31; S15
