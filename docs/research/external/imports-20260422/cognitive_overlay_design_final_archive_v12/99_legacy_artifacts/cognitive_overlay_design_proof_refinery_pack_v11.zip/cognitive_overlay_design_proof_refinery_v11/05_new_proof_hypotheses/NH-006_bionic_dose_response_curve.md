# NH-006 — Bionic Dose Response Curve

## Mechanism

Bionic anchors may help at low density and harm at high density.

## Minimum test

0%, 5%, 15%, 30%, 60% bionic density.

## Source IDs

S14; S15; S06

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
