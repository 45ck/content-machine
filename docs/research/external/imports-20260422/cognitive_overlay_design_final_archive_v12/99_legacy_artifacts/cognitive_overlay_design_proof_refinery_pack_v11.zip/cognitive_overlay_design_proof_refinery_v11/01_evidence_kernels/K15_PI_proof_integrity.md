# K15 — Proof Integrity (PI)

## Claim

Use preregistration, practical significance, non-inferiority, and negative controls to avoid false proof.

## Source support

S24; S25; S27; S28

## Methods that rely on this kernel

Proof ladder; HBF; ROW; CKT; BOP

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Results are not reproducible or only statistically significant without practical value.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
