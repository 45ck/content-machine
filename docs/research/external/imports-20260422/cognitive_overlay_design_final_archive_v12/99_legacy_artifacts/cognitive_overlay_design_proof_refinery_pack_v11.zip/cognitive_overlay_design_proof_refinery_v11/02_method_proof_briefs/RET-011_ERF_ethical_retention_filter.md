# RET-011 / ERF — Ethical Retention Filter

## Definition

Reject overlays that increase watch time by confusion instead of clarity.

## Method family

- Category: Platform / Retention
- Family: Platform Retention
- Class: Retention Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves early hold/completion while preserving comprehension.

## Mechanism bundle

PNF; AR

## Evidence grade

- Existing grade: Speculative / governance
- Proof grade: G-0: speculative
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

standard caption style

## Minimum viable experiment

Qualitative review + retention metrics.

## Primary metrics

gist recall; action recall; perceived effort; 3s hold; completion; saves

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Hard to quantify.

## Source IDs

S25; S30
