# AIA-006 / GSWE — Gaze Simulation Without Eye Tracker

## Definition

Use saliency/meaning maps to simulate likely gaze conflict.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: Adaptive System
- Phase: Explore later
- Priority: P2

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

manual editor baseline

## Minimum viable experiment

Model score vs user gaze subset.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Cannot replace real gaze data.

## Source IDs

S11; S12
