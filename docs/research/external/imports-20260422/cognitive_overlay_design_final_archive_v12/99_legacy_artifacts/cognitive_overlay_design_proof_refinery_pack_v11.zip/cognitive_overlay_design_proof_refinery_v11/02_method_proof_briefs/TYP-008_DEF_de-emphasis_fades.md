# TYP-008 / DEF — De-Emphasis Fades

## Definition

Dull background words and keep key terms high opacity.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Explore later
- Priority: P2

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Opacity fade vs bold highlight.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Low opacity may fail contrast/accessibility.

## Source IDs

S08; S28
