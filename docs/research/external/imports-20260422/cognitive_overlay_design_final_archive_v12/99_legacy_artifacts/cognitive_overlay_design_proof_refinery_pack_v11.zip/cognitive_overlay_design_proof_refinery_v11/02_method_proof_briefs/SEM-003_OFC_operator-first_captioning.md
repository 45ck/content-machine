# SEM-003 / OFC — Operator-First Captioning

## Definition

Begin overlay with logical operator: Not, Stop, Less, First, Then.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Keyword-only vs Not-X/Y microphrases.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Too many operators feel formulaic.

## Source IDs

S06; S07; S09; S10; S27
