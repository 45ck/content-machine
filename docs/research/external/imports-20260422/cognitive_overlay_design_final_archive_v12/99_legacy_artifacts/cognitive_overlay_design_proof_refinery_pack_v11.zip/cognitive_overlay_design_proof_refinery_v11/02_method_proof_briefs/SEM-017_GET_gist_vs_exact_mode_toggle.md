# SEM-017 / GET — Gist vs Exact Mode Toggle

## Definition

Use gist overlay for retention, closed captions for exact speech.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Rule / Mode
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Full captions plus gist overlay vs overlay alone.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Requires platform support or extra production effort.

## Source IDs

S01; S05; S09; S10
