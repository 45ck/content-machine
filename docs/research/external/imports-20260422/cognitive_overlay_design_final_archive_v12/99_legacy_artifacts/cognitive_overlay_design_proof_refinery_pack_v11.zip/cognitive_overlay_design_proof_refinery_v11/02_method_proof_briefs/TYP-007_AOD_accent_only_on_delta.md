# TYP-007 / AOD — Accent Only on Delta

## Definition

Highlight only what changes from old belief to new belief.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Explore later
- Priority: P2

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Full highlight vs delta-only highlight.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Requires accurate detection of old/new model.

## Source IDs

S08; S09; S22; S23; S28
