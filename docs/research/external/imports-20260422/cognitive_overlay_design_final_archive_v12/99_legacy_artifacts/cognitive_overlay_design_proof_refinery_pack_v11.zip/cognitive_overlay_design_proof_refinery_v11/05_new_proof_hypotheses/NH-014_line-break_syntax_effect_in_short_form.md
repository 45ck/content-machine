# NH-014 — Line-Break Syntax Effect in Short Form

## Mechanism

Syntactic line breaks should reduce perceived effort in vertical overlays.

## Minimum test

syntactic vs arbitrary line breaks in BCC/SCC.

## Source IDs

S20

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
