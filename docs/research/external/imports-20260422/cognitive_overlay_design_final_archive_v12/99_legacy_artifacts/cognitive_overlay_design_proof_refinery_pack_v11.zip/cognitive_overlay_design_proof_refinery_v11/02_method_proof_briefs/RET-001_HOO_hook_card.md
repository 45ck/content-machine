# RET-001 / HOO — Hook Card

## Definition

Use first 0.5–1.5 sec as a semantic promise.

## Method family

- Category: Platform / Retention
- Family: Platform Retention
- Class: Retention Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves early hold/completion while preserving comprehension.

## Mechanism bundle

PNF; AR

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

standard caption style

## Minimum viable experiment

Hook card vs no hook card.

## Primary metrics

gist recall; action recall; perceived effort; 3s hold; completion; saves

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Clickbait if promise not delivered.

## Source IDs

S25; S21
