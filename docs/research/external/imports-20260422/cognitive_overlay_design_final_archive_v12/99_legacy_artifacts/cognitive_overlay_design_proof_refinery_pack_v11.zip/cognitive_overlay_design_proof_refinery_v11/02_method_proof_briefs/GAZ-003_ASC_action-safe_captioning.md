# GAZ-003 / ASC — Action-Safe Captioning

## Definition

Avoid hands, products, joints, cursor, and key action path.

## Method family

- Category: Placement / Gaze
- Family: Placement and Gaze
- Class: Placement Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Preserves visual recall and reduces gaze travel/conflict.

## Mechanism bundle

GSPM; CRD; FPA

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

bottom-fixed placement; random safe placement

## Minimum viable experiment

Action-covered vs action-safe.

## Primary metrics

gist recall; action recall; perceived effort; visual recall; text-face/object dwell ratio

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May require dynamic object tracking.

## Source IDs

S10; S14; S15
