# NH-015 — Platform-Native vs Trust-Safe Tradeoff

## Mechanism

TikTok-native styling may improve engagement but reduce trust in serious content.

## Minimum test

standard vs native/nonstandard styles across content domains.

## Source IDs

S21; S25

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
