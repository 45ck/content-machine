# TIM-010 / TMD — Tempo-Matched Density

## Definition

Decrease word count as speech tempo rises.

## Method family

- Category: Timing / Rhythm
- Family: Timing and Rhythm
- Class: Timing Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves immediate gist, smoothness, or effort versus sync/post-cue baseline.

## Mechanism bundle

PT; VWM

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

sync cue; post cue; no cue

## Minimum viable experiment

Fixed density vs tempo-adaptive.

## Primary metrics

gist recall; action recall; perceived effort; smoothness; time-to-gist

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May omit too much at high speed.

## Source IDs

S04; S06
