# NH-009 — Action Mode Minimal Labels

## Mechanism

During demonstrations, object/action labels beat sentence captions.

## Minimum test

sentence vs labels vs arrows+labels in demo clips.

## Source IDs

S11; S10; S12

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
