# AIA-014 / HLE — Human-in-the-Loop Editor

## Definition

AI proposes; editor approves proposition, anchor, placement, timing.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: Adaptive System
- Phase: Pilot first
- Priority: P0

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Strong practical / direct test needed
- Proof grade: G-P: engineering-practical
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

manual editor baseline

## Minimum viable experiment

AI-only vs human-in-loop.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Still requires training/editor time.

## Source IDs

S30
