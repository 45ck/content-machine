# K02 — Structured Signaling (SIG)

## Claim

Explicit cues for role and organization improve retention/transfer and reduce cognitive load.

## Source support

S07; S08; S23

## Methods that rely on this kernel

OFC; PCFB; TBSM; REN; CEP

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Structured overlays fail to improve contrast/action recall versus keyword-only overlays.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
