# K07 — Crowding Avoidance (CRD)

## Claim

Recognition worsens in clutter; captions should avoid UI/text/background conflicts.

## Source support

S10; S11; S29

## Methods that rely on this kernel

CAC; CCD; STB; BBAP; CBU; FLCC

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Clutter-aware overlays do not improve readability/effort versus standard placement.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
