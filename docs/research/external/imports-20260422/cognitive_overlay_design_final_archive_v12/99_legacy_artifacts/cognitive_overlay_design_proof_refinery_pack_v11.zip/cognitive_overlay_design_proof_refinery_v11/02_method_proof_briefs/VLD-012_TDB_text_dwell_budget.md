# VLD-012 / TDB — Text Dwell Budget

## Definition

Limit total seconds of on-screen text per 10 seconds of video.

## Method family

- Category: Visual Load / Clutter
- Family: Visual Load and Clutter
- Class: Rule / Mode
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves readability/effort in busy frames without hurting comprehension.

## Mechanism bundle

CRD; VWM; FPA

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

fixed density overlay

## Minimum viable experiment

Low/medium/high dwell budgets.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Muted viewers may need more text.

## Source IDs

S05; S10; S26
