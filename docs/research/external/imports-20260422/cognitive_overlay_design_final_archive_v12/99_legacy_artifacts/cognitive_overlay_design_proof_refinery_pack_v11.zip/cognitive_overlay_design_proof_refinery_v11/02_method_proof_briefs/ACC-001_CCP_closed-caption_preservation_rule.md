# ACC-001 / CCP — Closed-Caption Preservation Rule

## Definition

Always keep full captions available when using creative overlays.

## Method family

- Category: Personalization / Access
- Family: Accessibility and Personalization
- Class: Rule / Mode
- Phase: Pilot first
- Priority: P0

## Proof claim

Should beat baseline on target metric.

## Mechanism bundle

AR; DLA

## Evidence grade

- Existing grade: Strong requirement
- Proof grade: G-REQ: standard/guardrail
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

current best baseline

## Minimum viable experiment

User tests with overlay only vs dual layer.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Platform support may vary.

## Source IDs

S01; S02
