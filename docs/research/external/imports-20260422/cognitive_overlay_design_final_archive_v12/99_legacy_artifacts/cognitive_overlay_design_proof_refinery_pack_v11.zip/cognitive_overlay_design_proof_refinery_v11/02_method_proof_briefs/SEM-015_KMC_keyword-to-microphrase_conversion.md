# SEM-015 / KMC — Keyword-to-Microphrase Conversion

## Definition

Convert isolated keywords into 2–4 word phrase chunks.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Keywords vs microphrases.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Slightly more text may hurt visual recall.

## Source IDs

S06; S07; S09; S10; S27
