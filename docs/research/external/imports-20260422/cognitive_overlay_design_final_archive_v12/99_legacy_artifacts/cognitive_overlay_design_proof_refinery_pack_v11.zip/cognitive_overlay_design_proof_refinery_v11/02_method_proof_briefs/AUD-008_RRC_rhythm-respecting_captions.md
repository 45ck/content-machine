# AUD-008 / RRC — Rhythm-Respecting Captions

## Definition

Avoid text changes on every music beat unless text is music/lyric content.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Multimodal Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Beat-synced vs semantic-synced.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May reduce platform-native energy.

## Source IDs

S19
