# NH-010 — Meaning-Map Placement Beats Saliency Pop

## Mechanism

Text that explains meaningful regions beats text placed on visually loud regions.

## Minimum test

meaning-map placement vs saliency pop vs bottom fixed.

## Source IDs

S09; S17

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
