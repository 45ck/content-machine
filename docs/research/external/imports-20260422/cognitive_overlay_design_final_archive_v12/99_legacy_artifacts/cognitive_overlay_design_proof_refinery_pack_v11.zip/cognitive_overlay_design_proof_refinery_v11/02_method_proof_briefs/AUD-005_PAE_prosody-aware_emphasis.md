# AUD-005 / PAE — Prosody-Aware Emphasis

## Definition

Map speaker emphasis/intensity to controlled text weight or motion.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Multimodal Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Prosody-aware vs uniform captions.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Over-styling reduces clarity.

## Source IDs

S20; S34
