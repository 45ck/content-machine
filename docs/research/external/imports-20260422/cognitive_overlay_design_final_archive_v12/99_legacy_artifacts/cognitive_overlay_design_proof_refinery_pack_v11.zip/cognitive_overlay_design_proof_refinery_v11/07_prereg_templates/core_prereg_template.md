# Preregistration Template — COD Overlay Trial

## Study title

[Name of overlay experiment]

## Research question

Example: Does BCC outperform SCC on gist/action recall after semantic compression has already been applied?

## Hypotheses

- H1: [Variant] will outperform [baseline] on [primary metric].
- H2: [Variant] will not be inferior to [baseline] on [guardrail metric].

## Conditions

List conditions exactly.

## Participants

Define sample size, inclusion criteria, exclusion criteria, and viewing device.

## Stimuli

List video IDs and topic categories.

## Randomization

Describe assignment and counterbalancing.

## Measures

Primary, secondary, and guardrail metrics.

## Exclusion rules

Define before collecting data.

## Analysis plan

Define contrasts, practical significance thresholds, and correction for multiple comparisons.

## Decision rule

Keep, demote, segment, or reject.
