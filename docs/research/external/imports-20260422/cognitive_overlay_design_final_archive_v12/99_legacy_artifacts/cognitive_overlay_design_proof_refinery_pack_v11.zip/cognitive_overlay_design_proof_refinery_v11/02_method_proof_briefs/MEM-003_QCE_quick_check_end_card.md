# MEM-003 / QCE — Quick Check End Card

## Definition

End with micro quiz: Motivation or structure?

## Method family

- Category: Memory / Learning
- Family: Memory and Learning
- Class: Learning Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves delayed/action recall or save intent.

## Mechanism bundle

SIG; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

no memory prompt; payoff card only

## Minimum viable experiment

Quiz vs memory phrase.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May feel classroom-like.

## Source IDs

S09
