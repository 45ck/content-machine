# Proof Scorecard

Score each method 0–5.

| Dimension | Question |
|---|---|
| Mechanism clarity | Do we know why this should work? |
| Source support | Is there adjacent or direct research? |
| Baseline clarity | Is the comparator obvious? |
| Falsifiability | Can it fail clearly? |
| Metric fit | Are metrics matched to the mechanism? |
| Guardrail safety | Does it preserve accessibility and visual recall? |
| Segment logic | Do we know where it should/should not work? |
| Practical value | Would a win matter in production? |

Minimum score to run in pilot: 24/40.
Minimum score to ship: 32/40 plus a direct test win.
