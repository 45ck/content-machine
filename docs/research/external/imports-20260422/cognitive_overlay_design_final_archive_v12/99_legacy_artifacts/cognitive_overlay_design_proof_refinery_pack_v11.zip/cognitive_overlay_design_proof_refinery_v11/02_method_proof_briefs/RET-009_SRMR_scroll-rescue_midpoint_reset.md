# RET-009 / SRMR — Scroll-Rescue Midpoint Reset

## Definition

At 40–60%, add a new semantic hook or map update.

## Method family

- Category: Platform / Retention
- Family: Platform Retention
- Class: Retention Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves early hold/completion while preserving comprehension.

## Mechanism bundle

PNF; AR

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

standard caption style

## Minimum viable experiment

Midpoint reset vs none.

## Primary metrics

gist recall; action recall; perceived effort; 3s hold; completion; saves

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Feels artificial if not content-driven.

## Source IDs

S25
