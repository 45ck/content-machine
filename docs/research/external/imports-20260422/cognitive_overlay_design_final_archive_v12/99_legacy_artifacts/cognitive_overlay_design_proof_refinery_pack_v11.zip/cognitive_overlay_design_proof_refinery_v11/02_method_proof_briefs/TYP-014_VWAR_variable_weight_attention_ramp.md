# TYP-014 / VWAR — Variable Weight Attention Ramp

## Definition

Gradually increase weight on words as they become relevant.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Explore later
- Priority: P3

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Static bold vs weight ramp.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Animation could distract.

## Source IDs

S19; S28
