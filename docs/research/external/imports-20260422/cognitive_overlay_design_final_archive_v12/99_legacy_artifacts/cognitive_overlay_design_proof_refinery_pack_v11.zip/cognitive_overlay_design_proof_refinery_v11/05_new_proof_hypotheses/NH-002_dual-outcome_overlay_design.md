# NH-002 — Dual-Outcome Overlay Design

## Mechanism

Separate overlays optimized for exact recall from overlays optimized for gist/action recall.

## Minimum test

Exact transcript tasks vs gist/action tasks across FTO, SCC, BCC.

## Source IDs

S04; S05

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
