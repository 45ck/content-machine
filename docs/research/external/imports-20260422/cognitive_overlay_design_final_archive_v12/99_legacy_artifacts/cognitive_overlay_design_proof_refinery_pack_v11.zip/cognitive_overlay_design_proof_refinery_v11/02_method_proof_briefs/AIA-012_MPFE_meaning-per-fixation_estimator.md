# AIA-012 / MPFE — Meaning-Per-Fixation Estimator

## Definition

Combine recall results and gaze/text dwell to estimate efficiency.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: Adaptive System
- Phase: Explore later
- Priority: P3

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Speculative / future
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

manual editor baseline

## Minimum viable experiment

Estimate vs actual recall.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Requires eye/gaze data.

## Source IDs

S30; S11
