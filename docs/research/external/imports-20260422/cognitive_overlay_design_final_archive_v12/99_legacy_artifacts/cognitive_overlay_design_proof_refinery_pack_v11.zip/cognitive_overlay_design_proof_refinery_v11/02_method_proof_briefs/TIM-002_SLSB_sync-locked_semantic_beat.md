# TIM-002 / SLSB — Sync-Locked Semantic Beat

## Definition

Show the overlay exactly when the semantic beat is spoken.

## Method family

- Category: Timing / Rhythm
- Family: Timing and Rhythm
- Class: Timing Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves immediate gist, smoothness, or effort versus sync/post-cue baseline.

## Mechanism bundle

PT; VWM

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

sync cue; post cue; no cue

## Minimum viable experiment

Sync vs pre/post.

## Primary metrics

gist recall; action recall; perceived effort; smoothness; time-to-gist

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May be slightly late for fast comprehension.

## Source IDs

S03; S04; S29
