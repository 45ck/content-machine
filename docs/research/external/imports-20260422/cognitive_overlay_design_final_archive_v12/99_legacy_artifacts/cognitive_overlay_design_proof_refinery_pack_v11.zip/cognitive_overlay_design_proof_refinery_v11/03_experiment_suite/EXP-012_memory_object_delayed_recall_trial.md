# EXP-012 — Memory Object Delayed Recall Trial

## Purpose

Prove that compressed payoff phrases stick.

## Conditions

full transcript; SCC; memory object; question prompt; action checklist

## Primary metric

delayed recall after 24h or next session

## Secondary metrics

save intent; action recall

## Decision rule

Memory object passes if delayed recall improves without immediate comprehension loss.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
