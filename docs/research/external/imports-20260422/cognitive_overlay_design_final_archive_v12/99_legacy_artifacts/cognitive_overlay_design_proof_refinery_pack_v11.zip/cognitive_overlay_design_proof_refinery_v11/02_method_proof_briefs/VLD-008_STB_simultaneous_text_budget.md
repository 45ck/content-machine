# VLD-008 / STB — Simultaneous Text Budget

## Definition

Limit screen to one primary text block plus one micro-label.

## Method family

- Category: Visual Load / Clutter
- Family: Visual Load and Clutter
- Class: Rule / Mode
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves readability/effort in busy frames without hurting comprehension.

## Mechanism bundle

CRD; VWM; FPA

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

fixed density overlay

## Minimum viable experiment

Budgeted vs unbudgeted overlays.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May constrain complex explanations.

## Source IDs

S10; S17
