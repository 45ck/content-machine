# KIN-012 / GST — Gesture-Synced Text

## Definition

Reveal instruction exactly when hand gesture demonstrates it.

## Method family

- Category: Motion / Kinetic
- Family: Motion and Kinetic Text
- Class: Motion Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Adds retention or emphasis without effort/fatigue penalty.

## Mechanism bundle

KR; SIG

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

static overlay; constant kinetic text

## Minimum viable experiment

Gesture-sync vs off-sync.

## Primary metrics

gist recall; action recall; perceived effort; fatigue; rewatch; visual recall

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Mistimed sync harms clarity.

## Source IDs

S09; S29
