# K06 — Gaze-Safe Placement (GSPM)

## Claim

Text should avoid regions needed for face, mouth, hands, product, UI, or action processing.

## Source support

S09; S13; S16; S17

## Methods that rely on this kernel

MSC; ASC; ONL; GSP; SFC; DRAR

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Gaze-safe placement reduces comprehension or does not improve visual recall.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
