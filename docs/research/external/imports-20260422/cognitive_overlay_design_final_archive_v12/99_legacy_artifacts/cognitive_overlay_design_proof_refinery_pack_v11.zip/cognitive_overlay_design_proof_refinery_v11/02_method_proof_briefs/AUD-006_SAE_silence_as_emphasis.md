# AUD-006 / SAE — Silence as Emphasis

## Definition

Use no overlay during silence or facial reaction, then land a short caption.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Multimodal Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Continuous caption vs silence+payoff.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Muted viewers may need context.

## Source IDs

S20; S32
