# ACC-004 / NLM — Novice Label Mode

## Definition

Add labels for unfamiliar concepts before compressing heavily.

## Method family

- Category: Personalization / Access
- Family: Accessibility and Personalization
- Class: Rule / Mode
- Phase: Pilot second
- Priority: P1

## Proof claim

Should beat baseline on target metric.

## Mechanism bundle

AR; DLA

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

current best baseline

## Minimum viable experiment

Labels vs no labels for beginners.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

More text load.

## Source IDs

S09; S10
