# CTL-012 / ENS — Emoji/Nonstandard Subtitle Variant

## Definition

Use platform-native non-standard typography and emoji.

## Method family

- Category: Negative Control
- Family: Controls and Failure Modes
- Class: Control / Baseline
- Phase: Experiment control
- Priority: P2

## Proof claim

Should not beat mechanism-targeted variants except in exact transcript recall.

## Mechanism bundle

PI

## Evidence grade

- Existing grade: Emerging direct evidence
- Proof grade: G-2E: emerging direct evidence
- Proof level needed: P0/P1 pilot only

## Comparator

used as baseline/control

## Minimum viable experiment

Compare with clean captioning by category.

## Primary metrics

gist recall; action recall; perceived effort; negative-control sanity check

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May harm accessibility/professionalism.

## Source IDs

S21; S28
