# AIA-004 / FMHO — Face/Mouth/Hand/Object Detector

## Definition

Detect visual regions that should not be covered.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: System Module
- Phase: Pilot first
- Priority: P0

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Strong practical / direct test needed
- Proof grade: G-P: engineering-practical
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

manual editor baseline

## Minimum viable experiment

Manual vs CV safe-zone detection.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Detection errors in motion/low light.

## Source IDs

S14; S18; S32
