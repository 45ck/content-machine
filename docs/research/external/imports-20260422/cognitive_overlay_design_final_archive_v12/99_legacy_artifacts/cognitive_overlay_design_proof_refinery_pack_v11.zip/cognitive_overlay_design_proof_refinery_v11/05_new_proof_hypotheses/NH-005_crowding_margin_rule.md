# NH-005 — Crowding Margin Rule

## Mechanism

Set minimum spacing between overlay and other text/UI to prevent recognition loss.

## Minimum test

0/4/8/12% screen-distance margin variants.

## Source IDs

S10

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
