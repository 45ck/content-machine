# K10 — Predictive Timing (PT)

## Claim

Pre-cueing or sync-locking semantic beats may reduce prediction load and improve speed of gist formation.

## Source support

S23; S20; S04

## Methods that rely on this kernel

PSP; SLSB; PCC; PWC

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Pre-cue variants distract or lower comprehension compared with sync/post-cue.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
