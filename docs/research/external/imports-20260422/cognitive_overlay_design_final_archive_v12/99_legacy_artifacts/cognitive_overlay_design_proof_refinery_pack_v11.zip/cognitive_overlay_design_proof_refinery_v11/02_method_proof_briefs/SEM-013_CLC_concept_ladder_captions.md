# SEM-013 / CLC — Concept Ladder Captions

## Definition

Move from concrete to abstract: shoes → start → habit.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Beginner viewers: ladder vs direct concept.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Experts may find it slow.

## Source IDs

S06; S07; S09; S10; S27
