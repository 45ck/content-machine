# Proof Thesis

## Core thesis

Short-form viewers are not simply reading captions. They are distributing limited visual attention across a moving scene, a face, gestures, UI clutter, speech, captions, and text overlays.

Therefore the main proof target is not reading speed.

The target is:

> **Meaning per fixation** and **meaning per second watched**.

## Mechanism stack

The strongest proof-supported stack is:

1. **Semantic compression** — reduce required words.
2. **Structured signaling** — make the idea relation visible.
3. **Sparse anchoring** — highlight only the semantic operators and concepts.
4. **Gaze-safe placement** — avoid mouth, eyes, hands, products, UI, and action.
5. **Visual-load adaptation** — use fewer words when the frame is busy.
6. **Muted-first design** — overlays must carry gist when sound is off.
7. **Dual-layer captions** — full captions remain available for accessibility.
8. **Kinetic restraint** — motion only when it encodes logic.

## The specific BCC claim

BCC is not proven by Bionic Reading research. The Bionic Reading evidence is weak/contested.

BCC is proven only if:

> BCC beats SCC after compression alone has already been applied.

That is the decisive comparison.
