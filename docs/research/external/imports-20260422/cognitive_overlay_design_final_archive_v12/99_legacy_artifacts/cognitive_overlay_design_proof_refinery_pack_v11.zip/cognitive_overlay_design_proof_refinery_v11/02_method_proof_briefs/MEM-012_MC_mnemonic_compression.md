# MEM-012 / MC — Mnemonic Compression

## Definition

Turn takeaways into memorable parallel structures or rhymes.

## Method family

- Category: Memory / Learning
- Family: Memory and Learning
- Class: Learning Method
- Phase: Explore later
- Priority: P3

## Proof claim

Improves delayed/action recall or save intent.

## Mechanism bundle

SIG; VWM

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

no memory prompt; payoff card only

## Minimum viable experiment

Mnemonic vs plain takeaway.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Can sound gimmicky.

## Source IDs

S09; S27
