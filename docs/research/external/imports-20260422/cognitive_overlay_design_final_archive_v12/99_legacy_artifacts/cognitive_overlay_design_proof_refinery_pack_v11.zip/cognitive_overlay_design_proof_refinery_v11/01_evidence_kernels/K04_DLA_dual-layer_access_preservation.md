# K04 — Dual-Layer Access Preservation (DLA)

## Claim

Full captions should preserve accessibility while semantic overlays optimize rapid meaning.

## Source support

S01; S03; S29

## Methods that rely on this kernel

DLC; CCP; NSS; BCC+

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Overlay replaces or degrades accessibility; DHH users lose information from missing sound cues.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
