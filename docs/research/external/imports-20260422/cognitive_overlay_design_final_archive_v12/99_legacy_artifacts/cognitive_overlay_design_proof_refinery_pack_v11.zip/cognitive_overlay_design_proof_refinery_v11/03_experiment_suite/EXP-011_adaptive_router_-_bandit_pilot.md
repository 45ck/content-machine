# EXP-011 — Adaptive Router / Bandit Pilot

## Purpose

Prove context routing beats one global winner.

## Conditions

global best; contextual router; random balanced exploration

## Primary metric

meaning-per-second composite by segment

## Secondary metrics

regret; failure rate; drift

## Decision rule

Router wins if it beats global best across segments or meaningfully reduces failures.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
