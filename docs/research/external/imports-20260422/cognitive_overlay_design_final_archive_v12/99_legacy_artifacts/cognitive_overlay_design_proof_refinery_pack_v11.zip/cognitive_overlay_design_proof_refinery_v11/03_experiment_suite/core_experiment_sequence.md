# Core Experiment Sequence

The sequence is designed to prove or demote each mechanism in order.

## Stage 1 — Core overlay test

Compare:

1. Native captions only
2. Full Transcript Overlay (FTO)
3. Keyword Highlight Transcript (KHT)
4. Semantic Compression Captions (SCC)
5. Bionic Compression Captioning (BCC)
6. BCC+
7. Heavy Bionic Formatting (HBF)

Decision logic:

- If SCC beats FTO, compression has support.
- If BCC beats SCC, bionic anchors have support.
- If BCC+ beats BCC, system-level placement/load/timing has support.
- If HBF loses, sparse anchoring has support against over-bionic styling.

## Stage 2 — Mechanism isolation

Run component ablations:

- BCC without bionic anchors
- BCC with full-word anchors only
- BCC with heavy bionic anchors
- BCC+ without gaze-safe placement
- BCC+ without visual-load adaptation
- BCC+ without muted-first wording

## Stage 3 — Segment tests

Repeat by video type:

- talking head
- product demo
- fitness/cooking/tutorial
- screen recording
- emotional story
- dense educational content

## Stage 4 — Platform test

Ship only variants that pass controlled comprehension guardrails.
