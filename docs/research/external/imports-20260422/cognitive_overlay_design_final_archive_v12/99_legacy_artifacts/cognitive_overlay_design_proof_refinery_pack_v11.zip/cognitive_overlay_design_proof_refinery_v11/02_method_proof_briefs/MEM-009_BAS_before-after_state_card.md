# MEM-009 / BAS — Before/After State Card

## Definition

Show old state → new state visually/textually.

## Method family

- Category: Memory / Learning
- Family: Memory and Learning
- Class: Learning Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves delayed/action recall or save intent.

## Mechanism bundle

SIG; VWM

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

no memory prompt; payoff card only

## Minimum viable experiment

Before/after vs regular caption.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Oversimplifies gradual changes.

## Source IDs

S09; S10; S17; S27; S30
