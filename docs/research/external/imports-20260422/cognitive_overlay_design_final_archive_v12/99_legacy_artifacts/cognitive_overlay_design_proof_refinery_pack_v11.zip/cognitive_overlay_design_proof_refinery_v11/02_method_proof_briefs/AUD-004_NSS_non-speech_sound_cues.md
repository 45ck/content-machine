# AUD-004 / NSS — Non-Speech Sound Cues

## Definition

Show [laughter], [music rises], [door slam] only when meaningful.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Multimodal Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Strong requirement
- Proof grade: G-REQ: standard/guardrail
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

audio-on only; native captions only

## Minimum viable experiment

With/without sound cues.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Too many cues distract.

## Source IDs

S01; S03
