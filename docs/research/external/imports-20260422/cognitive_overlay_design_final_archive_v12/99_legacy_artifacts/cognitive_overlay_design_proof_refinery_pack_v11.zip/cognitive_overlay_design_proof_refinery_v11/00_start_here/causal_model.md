# Causal Model

## Core causal chain

Overlay design affects:

1. text density,
2. placement conflict,
3. cue structure,
4. timing alignment,
5. motion load,
6. semantic clarity.

These affect:

1. gaze allocation,
2. fixation count/duration,
3. saccades between regions,
4. perceived effort,
5. working-memory burden,
6. visual scene retention.

Those determine:

1. gist recall,
2. action recall,
3. exact recall,
4. visual recall,
5. completion rate,
6. saves/shares,
7. confusion comments.

## Important confounds

- Video topic
- Speaker charisma
- Audio clarity
- Existing captions
- Background clutter
- Viewer language proficiency
- Prior knowledge
- Platform norms
- Device size
- Sound on/off state

## Causal guard

Every experiment should hold source footage constant and vary only the overlay condition.
