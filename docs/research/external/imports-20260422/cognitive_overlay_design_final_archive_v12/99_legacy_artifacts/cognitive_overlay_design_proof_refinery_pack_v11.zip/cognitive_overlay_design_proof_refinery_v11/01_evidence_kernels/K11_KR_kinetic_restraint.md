# K11 — Kinetic Restraint (KR)

## Claim

Motion helps when it encodes structure, but excessive motion overloads.

## Source support

S18; S07

## Methods that rely on this kernel

LM; PRL; MS; SMP; DKC; MBS

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

High-motion styles improve comprehension/retention without effort penalty across segments.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
