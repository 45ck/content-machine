# GAZ-006 / SAP — Saliency-Avoiding Placement

## Definition

Place text away from predicted high-saliency regions unless it is a label.

## Method family

- Category: Placement / Gaze
- Family: Placement and Gaze
- Class: Placement Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Preserves visual recall and reduces gaze travel/conflict.

## Mechanism bundle

GSPM; CRD; FPA

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

bottom-fixed placement; random safe placement

## Minimum viable experiment

Fixed vs saliency-aware placement.

## Primary metrics

gist recall; action recall; perceived effort; visual recall; text-face/object dwell ratio

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Low-saliency areas may be poor contrast.

## Source IDs

S12; S14
