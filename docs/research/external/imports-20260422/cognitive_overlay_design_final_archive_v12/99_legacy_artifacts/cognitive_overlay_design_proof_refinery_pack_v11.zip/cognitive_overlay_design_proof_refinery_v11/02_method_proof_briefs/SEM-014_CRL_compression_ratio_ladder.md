# SEM-014 / CRL — Compression Ratio Ladder

## Definition

Test 100%, 60%, 30%, 15%, and 5% transcript equivalents.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Same clip at multiple compression ratios.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Too low loses context; too high overloads.

## Source IDs

S06; S07; S09; S10; S27
