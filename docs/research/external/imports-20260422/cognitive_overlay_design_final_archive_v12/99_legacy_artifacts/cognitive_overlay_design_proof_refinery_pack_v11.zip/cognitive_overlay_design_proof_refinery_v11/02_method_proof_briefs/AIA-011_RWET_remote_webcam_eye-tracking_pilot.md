# AIA-011 / RWET — Remote Webcam Eye-Tracking Pilot

## Definition

Use webcam gaze estimation for rough large-sample placement tests.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: Adaptive System
- Phase: Explore later
- Priority: P3

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

manual editor baseline

## Minimum viable experiment

Webcam vs self-report vs subset eye tracker.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Lower accuracy than lab hardware.

## Source IDs

S30
