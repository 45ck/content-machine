# AUD-009 / TI — Tone Icons

## Definition

Use small icons for sarcasm, warning, encouragement only when tone is ambiguous.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Multimodal Method
- Phase: Explore later
- Priority: P3

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Tone icon vs none.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Icons can trivialize serious content.

## Source IDs

S20; S34
