# EXP-006 — Kinetic Restraint Trial

## Purpose

Prove motion should encode logic not decorate.

## Conditions

static; soft scale; logic motion; word pop; karaoke; constant kinetic

## Primary metric

comprehension/effort composite

## Secondary metrics

fatigue; visual recall; completion

## Decision rule

Logic motion wins only if comprehension or retention improves without fatigue penalty.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
