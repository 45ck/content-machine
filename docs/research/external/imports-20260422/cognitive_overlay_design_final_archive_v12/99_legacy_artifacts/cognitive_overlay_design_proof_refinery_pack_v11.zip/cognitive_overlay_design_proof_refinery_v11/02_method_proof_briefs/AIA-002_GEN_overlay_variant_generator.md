# AIA-002 / GEN — Overlay Variant Generator

## Definition

Auto-generates transcript, keyword, compression, BCC, BCC+, and controls.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: System Module
- Phase: Pilot second
- Priority: P1

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Strong practical / direct test needed
- Proof grade: G-P: engineering-practical
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

manual editor baseline

## Minimum viable experiment

Manual vs generated variants.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Quality depends on prompts/rules.

## Source IDs

S11; S12; S14; S30; S31
