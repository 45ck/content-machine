# Metric Dictionary

| Metric | Meaning | Use |
|---|---|---|
| Gist recall | Viewer can state the main point | SCC, BCC, BCC+ proof |
| Action recall | Viewer knows what to do next | Educational/advice clips |
| Contrast recall | Viewer remembers the false belief and correction | OFC, CPC, BCC |
| Exact recall | Viewer remembers wording | FTO and accessibility comparison |
| Visual recall | Viewer remembers visual scene/action | GSP, VLAC, obstruction guardrail |
| Perceived effort | Viewer reports how hard it was to follow | All methods |
| Text dwell time | Amount of gaze spent on overlay | Eye-tracking / webcam proxy |
| Face/object dwell | Whether viewer still sees important visual region | GSP and action-safe captions |
| Meaning per second | Comprehension or recall divided by seconds watched | Platform-friendly efficiency metric |
| Meaning per fixation | Recall/understanding divided by fixation cost | Research-grade efficiency metric |
| Confusion comments | Comments asking what the video means | Platform failure marker |
| Saves/shares | Utility or memorability proxy | Platform outcome |
