# K01 — Compression Load Reduction (CLR)

## Claim

Reducing required text can preserve or improve gist when transcript density is the bottleneck.

## Source support

S02; S04; S05

## Methods that rely on this kernel

SCC; CRL; OIOS; GET; VLAW

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Compressed overlays lose gist/action recall versus full transcript or confuse muted viewers.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
