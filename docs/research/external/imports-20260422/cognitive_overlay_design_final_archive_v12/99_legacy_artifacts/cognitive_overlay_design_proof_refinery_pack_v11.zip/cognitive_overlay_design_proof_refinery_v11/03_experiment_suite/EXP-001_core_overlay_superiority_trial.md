# EXP-001 — Core Overlay Superiority Trial

## Purpose

Prove compression and anchor sequence.

## Conditions

NNO; FTO; KHT; SCC; BCC; BCC+; HBF

## Primary metric

gist recall + action recall composite

## Secondary metrics

perceived effort; visual recall; exact recall

## Decision rule

SCC must beat FTO for compression proof; BCC must beat SCC for bionic-anchor proof; BCC+ must beat BCC for system proof.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
