# AUD-010 / HCV — Haptic Caption Variant

## Definition

For AR/wearables, use vibration patterns for emotion or emphasis.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Multimodal Method
- Phase: Explore later
- Priority: P3

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Speculative / cutting-edge
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Lab prototype with haptic cues.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Not relevant to normal TikTok yet.

## Source IDs

S34; S33
