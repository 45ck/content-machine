# NH-001 — Syntax-At-A-Glance Captions

## Mechanism

Use 2-4 word grammatical microphrases because rapid visual phrase-structure detection may support faster gist.

## Minimum test

Keyword-only vs grammatical microphrase vs full sentence.

## Source IDs

S23; S07

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
