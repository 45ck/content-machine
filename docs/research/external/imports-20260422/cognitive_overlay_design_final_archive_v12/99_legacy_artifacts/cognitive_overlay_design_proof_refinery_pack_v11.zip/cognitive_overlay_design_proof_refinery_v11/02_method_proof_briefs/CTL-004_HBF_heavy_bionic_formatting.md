# CTL-004 / HBF — Heavy Bionic Formatting

## Definition

Apply bionic partial bolding to most words.

## Method family

- Category: Negative Control
- Family: Controls and Failure Modes
- Class: Control / Baseline
- Phase: Experiment control
- Priority: P0

## Proof claim

Should not beat mechanism-targeted variants except in exact transcript recall.

## Mechanism bundle

PI; SAA

## Evidence grade

- Existing grade: Negative control
- Proof grade: G-CTL: control/falsifier
- Proof level needed: Control sanity check

## Comparator

used as baseline/control

## Minimum viable experiment

Compare to BCC and compression.

## Primary metrics

gist recall; action recall; perceived effort; negative-control sanity check

## Pass rule

Control behaves as predicted: exact recall may be strong, but gist/effort/visual efficiency should not dominate targeted variants.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Can look novel but noisy.

## Source IDs

S22; S23
