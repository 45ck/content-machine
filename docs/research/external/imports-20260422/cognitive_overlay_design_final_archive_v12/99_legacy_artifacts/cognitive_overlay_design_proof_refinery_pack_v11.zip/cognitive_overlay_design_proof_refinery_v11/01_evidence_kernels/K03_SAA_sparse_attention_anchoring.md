# K03 — Sparse Attention Anchoring (SAA)

## Claim

Sparse keyword/operator emphasis guides attention without overloading gaze.

## Source support

S06; S07; S14; S15

## Methods that rely on this kernel

SKH; FOA; BCA; BCC; HBF

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Sparse anchors do not beat no-anchor SCC or create more effort/saccades.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
