# K13 — Platform-Native Fit (PNF)

## Claim

Short-form platform norms affect engagement; non-standard styles may help where brand/context permits.

## Source support

S21; S22

## Methods that rely on this kernel

PNT; ENS; HOO; FPR

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Platform-native variants reduce comprehension, trust or accessibility.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
