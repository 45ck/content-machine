# TYP-016 / PAT — Punctuation as Timing Cue

## Definition

Use periods, arrows, colons, and line breaks as rhythm markers.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Explore later
- Priority: P2

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Punctuated vs non-punctuated versions.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

TikTok-native styles may omit punctuation, conflicting with clarity.

## Source IDs

S21; S27
