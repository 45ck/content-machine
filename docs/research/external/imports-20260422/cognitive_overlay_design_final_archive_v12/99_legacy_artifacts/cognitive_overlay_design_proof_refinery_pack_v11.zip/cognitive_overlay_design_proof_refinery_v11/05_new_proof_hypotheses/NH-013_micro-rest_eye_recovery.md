# NH-013 — Micro-Rest Eye Recovery

## Mechanism

Small no-text gaps let gaze return to visual scene and reduce effort.

## Minimum test

continuous captions vs beat-rest-beat rhythm.

## Source IDs

S03; S18; S12

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
