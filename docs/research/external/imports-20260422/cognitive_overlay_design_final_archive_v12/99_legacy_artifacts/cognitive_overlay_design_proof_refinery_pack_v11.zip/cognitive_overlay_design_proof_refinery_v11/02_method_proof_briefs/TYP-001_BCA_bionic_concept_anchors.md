# TYP-001 / BCA — Bionic Concept Anchors

## Definition

Partially bold only key concept words after compression.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Pilot first
- Priority: P0

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Weak / contested
- Proof grade: G-WEAK: direct test required
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Semantic compression vs BCC.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May add noise; bionic evidence weak.

## Source IDs

S08; S22; S23
