# GAZ-017 / ELT — Eye-Line Triangle Rule

## Definition

Place overlay within triangle between speaker’s eyes, hands/object, and center.

## Method family

- Category: Placement / Gaze
- Family: Placement and Gaze
- Class: Rule / Mode
- Phase: Explore later
- Priority: P2

## Proof claim

Preserves visual recall and reduces gaze travel/conflict.

## Mechanism bundle

GSPM; CRD; FPA

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

bottom-fixed placement; random safe placement

## Minimum viable experiment

Triangle placement vs arbitrary.

## Primary metrics

gist recall; action recall; perceived effort; visual recall; text-face/object dwell ratio

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Needs eye-tracking validation.

## Source IDs

S32; S14
