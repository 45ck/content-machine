# Cognitive Overlay Design — Proof Refinery v11

This archive extends the proof program for **Cognitive Overlay Design (COD)**, **Semantic Compression Captions (SCC)**, **Bionic Compression Captioning (BCC)**, and **BCC+**.

The purpose is not to claim universal certainty. The purpose is to build a rigorous proof system where every named method has:

1. a named mechanism,
2. source support,
3. a falsifiable prediction,
4. a baseline,
5. a minimum viable experiment,
6. pass/fail criteria,
7. a demotion rule.

## Core proof thesis

> Short-form overlay performance can be improved by reducing required reading, making semantic structure visible, protecting gaze-critical regions, adapting to visual load, and preserving full accessibility captions.

## Start here

Read these files first:

- `00_start_here/proof_thesis.md`
- `00_start_here/proof_ladder.md`
- `01_evidence_kernels/evidence_kernel_index.md`
- `02_method_proof_briefs/_method_proof_index.md`
- `03_experiment_suite/core_experiment_sequence.md`
- `04_metrics_and_decision_rules/decision_rules.md`

## Key files

- `06_data_assets/method_proof_ledger_v11.xlsx`
- `06_data_assets/method_proof_ledger_v11.csv`
- `06_data_assets/evidence_kernels_v11.csv`
- `06_data_assets/proof_experiments_v11.csv`
- `08_source_index/source_index.md`

## Main unresolved proof question

> Does **BCC** beat **SCC** after semantic compression has already removed most of the reading load?

If no, bionic anchors become optional styling. If yes, BCC earns method status.
