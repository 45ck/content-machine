# VLD-013 / DVG — Density by Viewer Goal

## Definition

Use heavier overlays for learning clips, lighter for entertainment clips.

## Method family

- Category: Visual Load / Clutter
- Family: Visual Load and Clutter
- Class: Load-Control Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves readability/effort in busy frames without hurting comprehension.

## Mechanism bundle

CRD; VWM; FPA

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

fixed density overlay

## Minimum viable experiment

Category-specific vs universal density.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Incorrect classification hurts.

## Source IDs

S10; S25
