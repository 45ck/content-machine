# AIA-005 / VLP — Visual Load Predictor

## Definition

Estimate per-frame visual complexity to choose word count.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: System Module
- Phase: Pilot second
- Priority: P1

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

manual editor baseline

## Minimum viable experiment

Human-coded vs model-coded load.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Metric may not match human load.

## Source IDs

S12; S15
