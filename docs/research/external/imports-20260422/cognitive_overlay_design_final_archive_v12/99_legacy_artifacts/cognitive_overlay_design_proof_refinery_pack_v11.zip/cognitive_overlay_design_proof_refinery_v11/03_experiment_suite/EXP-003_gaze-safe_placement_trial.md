# EXP-003 — Gaze-Safe Placement Trial

## Purpose

Prove placement protects video information.

## Conditions

bottom-fixed; mouth-safe; object-near; saliency-avoiding; meaning-map placement

## Primary metric

visual recall noninferiority + gist superiority

## Secondary metrics

face/object dwell; text dwell; effort

## Decision rule

GSP wins if visual recall is noninferior or superior and gist/effort do not regress.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
