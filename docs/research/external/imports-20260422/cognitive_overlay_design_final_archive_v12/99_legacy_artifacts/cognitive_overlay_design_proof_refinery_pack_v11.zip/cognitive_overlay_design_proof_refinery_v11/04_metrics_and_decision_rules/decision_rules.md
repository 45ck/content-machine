# Decision Rules

## Keep

Keep a method if:

- It beats its comparator on the intended metric.
- It passes accessibility and readability guardrails.
- It has practical significance, not just statistical significance.
- It does not reduce visual recall unless visual content is irrelevant.

## Demote

Demote a method if:

- A simpler method performs as well or better.
- It improves watch time but worsens comprehension.
- It increases perceived effort.
- It blocks mouth, eyes, hands, product, or UI.
- It fails muted comprehension where muted viewing matters.

## Retain as segment-specific

Keep as segment-specific if it wins only in a clearly identifiable context.

Example:

- Affective captions may work for emotional stories but not technical tutorials.
- BCC may work for conceptual advice but not demos.
- Object-near labels may work for product demos but not talking heads.

## Reject

Reject if it fails against negative controls or creates accessibility risk.
