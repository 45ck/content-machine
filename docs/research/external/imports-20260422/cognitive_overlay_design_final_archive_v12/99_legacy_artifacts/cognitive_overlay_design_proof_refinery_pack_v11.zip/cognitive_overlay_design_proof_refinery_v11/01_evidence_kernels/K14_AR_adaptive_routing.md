# K14 — Adaptive Routing (AR)

## Claim

No single overlay style will dominate all contexts; route methods by segment and context.

## Source support

S24; S25; S26

## Methods that rely on this kernel

ASOE; VSA; AR; ABG

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

One global method consistently wins across segments with no routing gain.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
