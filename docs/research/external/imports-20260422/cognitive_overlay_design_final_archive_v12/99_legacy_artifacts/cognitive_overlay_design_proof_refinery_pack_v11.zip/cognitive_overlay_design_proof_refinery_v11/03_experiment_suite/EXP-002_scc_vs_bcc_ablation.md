# EXP-002 — SCC vs BCC Ablation

## Purpose

Isolate bionic concept anchors after semantic compression.

## Conditions

SCC; SCC+full bold keywords; BCC; HBF

## Primary metric

subjective clarity and delayed memory object recall

## Secondary metrics

text dwell; effort; saccades if eye tracking available

## Decision rule

If BCC does not beat SCC, demote bionic anchors to optional styling.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
