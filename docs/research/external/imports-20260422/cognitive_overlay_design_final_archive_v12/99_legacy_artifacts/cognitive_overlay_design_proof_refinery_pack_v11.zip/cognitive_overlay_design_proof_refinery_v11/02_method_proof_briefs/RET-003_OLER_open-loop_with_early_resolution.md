# RET-003 / OLER — Open-Loop With Early Resolution

## Definition

Open a gap, resolve quickly, then deepen.

## Method family

- Category: Platform / Retention
- Family: Platform Retention
- Class: Retention Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves early hold/completion while preserving comprehension.

## Mechanism bundle

PNF; AR

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

standard caption style

## Minimum viable experiment

Delayed open-loop vs early-resolution.

## Primary metrics

gist recall; action recall; perceived effort; 3s hold; completion; saves

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Too much tease lowers trust.

## Source IDs

S25
