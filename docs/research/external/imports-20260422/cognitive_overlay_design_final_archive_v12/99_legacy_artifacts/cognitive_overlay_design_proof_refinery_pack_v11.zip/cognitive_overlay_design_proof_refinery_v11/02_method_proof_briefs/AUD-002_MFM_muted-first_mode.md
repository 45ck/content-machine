# AUD-002 / MFM — Muted-First Mode

## Definition

Overlay carries enough meaning without sound.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Rule / Mode
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Muted-first vs cue-mode.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May be too much text for audio-on viewers.

## Source IDs

S05; S01
