# ACC-006 / LMM — Low-Motion Mode

## Definition

Provide a static/low-animation overlay for viewers sensitive to motion.

## Method family

- Category: Personalization / Access
- Family: Accessibility and Personalization
- Class: Rule / Mode
- Phase: Pilot second
- Priority: P1

## Proof claim

Should beat baseline on target metric.

## Mechanism bundle

AR; DLA

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

current best baseline

## Minimum viable experiment

Static vs kinetic variants.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May reduce platform energy.

## Source IDs

S19; S26
