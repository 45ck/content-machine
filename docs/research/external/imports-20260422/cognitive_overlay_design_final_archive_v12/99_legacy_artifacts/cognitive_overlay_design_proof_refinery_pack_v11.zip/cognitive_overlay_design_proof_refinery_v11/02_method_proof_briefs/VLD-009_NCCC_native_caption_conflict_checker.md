# VLD-009 / NCCC — Native Caption Conflict Checker

## Definition

Avoid overlay collisions with platform auto-captions or imported captions.

## Method family

- Category: Visual Load / Clutter
- Family: Visual Load and Clutter
- Class: Load-Control Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves readability/effort in busy frames without hurting comprehension.

## Mechanism bundle

CRD; VWM; FPA

## Evidence grade

- Existing grade: Strong practical / direct test needed
- Proof grade: G-P: engineering-practical
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

fixed density overlay

## Minimum viable experiment

With/without conflict checking.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Platforms may render differently.

## Source IDs

S01; S02; S15
