# NH-008 — Muted First Compression Floor

## Mechanism

Compressed overlays need enough words to work with no audio.

## Minimum test

5%, 15%, 30%, 45% semantic text under muted mode.

## Source IDs

S03; S05

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
