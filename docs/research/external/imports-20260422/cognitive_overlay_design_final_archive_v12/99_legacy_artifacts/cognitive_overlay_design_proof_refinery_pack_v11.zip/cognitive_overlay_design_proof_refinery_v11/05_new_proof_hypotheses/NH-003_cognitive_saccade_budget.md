# NH-003 — Cognitive Saccade Budget

## Mechanism

Limit number of required gaze shifts between face/object/text per semantic beat.

## Minimum test

Low-shift placement vs high-shift placement with eye tracking.

## Source IDs

S11; S16

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
