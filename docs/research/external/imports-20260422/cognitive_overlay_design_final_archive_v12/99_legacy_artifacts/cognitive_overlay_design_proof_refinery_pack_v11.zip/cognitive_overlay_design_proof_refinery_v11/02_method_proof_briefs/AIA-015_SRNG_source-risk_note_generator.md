# AIA-015 / SRNG — Source/Risk Note Generator

## Definition

For research/health/finance clips, overlay flags if claim is advice, evidence, or speculation.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: System Module
- Phase: Explore later
- Priority: P2

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

manual editor baseline

## Minimum viable experiment

No risk note vs risk-tagged version.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May reduce punchiness.

## Source IDs

S11; S12; S14; S30; S31
