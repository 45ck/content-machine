# EXP-009 — Accessibility Non-Inferiority Trial

## Purpose

Ensure creative overlays do not damage access.

## Conditions

full CC only; CC+BCC; CC+BCC+; BCC only

## Primary metric

DHH comprehension noninferiority vs full captions

## Secondary metrics

preference; sound-cue recall; obstruction

## Decision rule

Any variant without full captions cannot pass accessibility proof; CC+BCC+ must be noninferior within pre-set margin.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
