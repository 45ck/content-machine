# TYP-002 / FOA — Full-Word Operator Anchors

## Definition

Bold full operator words: Not, Stop, First, Less.

## Method family

- Category: Typography / Anchors
- Family: Typography and Anchors
- Class: Anchor / Typography Component
- Phase: Pilot first
- Priority: P0

## Proof claim

Reduces search cost or effort without increasing distraction.

## Mechanism bundle

SAA; CRD; SIG

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

same overlay without styling; SCC

## Minimum viable experiment

Operator-bold vs no bold.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Overuse reduces salience.

## Source IDs

S08; S09; S27; S28
