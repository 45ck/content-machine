# EXP-005 — Predictive Timing Offset Trial

## Purpose

Find best reveal timing.

## Conditions

precue 400ms; precue 200ms; sync; postcue 200ms; postcue 400ms

## Primary metric

time-to-gist + smoothness

## Secondary metrics

comprehension; distraction rating

## Decision rule

PSP wins if pre-cue improves time-to-gist without distraction increase.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
