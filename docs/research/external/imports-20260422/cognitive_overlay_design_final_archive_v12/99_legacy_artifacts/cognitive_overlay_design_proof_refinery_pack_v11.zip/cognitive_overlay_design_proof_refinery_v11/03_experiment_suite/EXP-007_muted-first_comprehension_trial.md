# EXP-007 — Muted-First Comprehension Trial

## Purpose

Prove muted overlays need enough semantic content.

## Conditions

native captions only; SCC; BCC; BCC+; keyword-only; full transcript

## Primary metric

muted gist/action recall

## Secondary metrics

effort; visual recall

## Decision rule

MFM/BCC+ must beat native captions and keyword-only for muted gist.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
