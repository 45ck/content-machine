# K12 — Affective-Semantic Encoding (ASE)

## Claim

Tone/prosody can be encoded with restrained visual modulation when emotion matters.

## Source support

S19

## Methods that rely on this kernel

PAE; TI; Affective variants

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Affective styling damages legibility or does not improve tone recognition.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
