# KIN-003 / KCF — Kinetic Contrast Flip

## Definition

Visually flip from false belief to correction.

## Method family

- Category: Motion / Kinetic
- Family: Motion and Kinetic Text
- Class: Motion Method
- Phase: Explore later
- Priority: P2

## Proof claim

Adds retention or emphasis without effort/fatigue penalty.

## Mechanism bundle

KR; SIG

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0/P1 pilot only

## Comparator

static overlay; constant kinetic text

## Minimum viable experiment

Static contrast vs flip animation.

## Primary metrics

gist recall; action recall; perceived effort; fatigue; rewatch; visual recall

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May distract from speaker.

## Source IDs

S19; S27
