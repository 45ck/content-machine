# AUD-003 / DLC — Dual-Layer Captioning

## Definition

Full closed captions plus separate semantic overlay.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Multimodal Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Closed captions only vs dual-layer.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Can create clutter if poorly placed.

## Source IDs

S01; S02; S05
