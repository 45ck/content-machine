# MEM-006 / WEF — Worked-Example Fade

## Definition

Start with full labels, then fade to minimal cues as viewer learns.

## Method family

- Category: Memory / Learning
- Family: Memory and Learning
- Class: Learning Method
- Phase: Explore later
- Priority: P3

## Proof claim

Improves delayed/action recall or save intent.

## Mechanism bundle

SIG; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0 exploratory + segment analysis

## Comparator

no memory prompt; payoff card only

## Minimum viable experiment

Full labels vs fading labels over series.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Requires sequence of content.

## Source IDs

S09; S10
