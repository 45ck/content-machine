# SEM-006 / REN — Rule–Example–Nonexample Captions

## Definition

Show a rule, a good example, then a wrong example.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Rule / Mode
- Phase: Explore later
- Priority: P2

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Learning clip with rule-only vs rule-example-nonexample.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Too slow for very short clips.

## Source IDs

S06; S07; S09; S10; S27
