# CTL-008 / COM — Color-Only Meaning

## Definition

Use color without labels/icons for semantic roles.

## Method family

- Category: Negative Control
- Family: Controls and Failure Modes
- Class: Control / Baseline
- Phase: Experiment control
- Priority: P1

## Proof claim

Should not beat mechanism-targeted variants except in exact transcript recall.

## Mechanism bundle

PI

## Evidence grade

- Existing grade: Negative control
- Proof grade: G-CTL: control/falsifier
- Proof level needed: Control sanity check

## Comparator

used as baseline/control

## Minimum viable experiment

Compare to color+label.

## Primary metrics

gist recall; action recall; perceived effort; negative-control sanity check

## Pass rule

Control behaves as predicted: exact recall may be strong, but gist/effort/visual efficiency should not dominate targeted variants.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Meaning can be missed.

## Source IDs

S28
