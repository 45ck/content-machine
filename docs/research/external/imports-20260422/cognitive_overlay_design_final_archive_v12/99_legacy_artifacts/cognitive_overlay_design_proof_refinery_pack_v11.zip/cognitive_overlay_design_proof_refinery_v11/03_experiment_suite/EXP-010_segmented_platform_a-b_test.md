# EXP-010 — Segmented Platform A/B Test

## Purpose

Prove practical platform lift by content type.

## Conditions

best baseline vs SCC vs BCC+ routed by segment

## Primary metric

completion + saves composite

## Secondary metrics

3s hold; confusion comments; shares; retention curve

## Decision rule

Ship if practical uplift exceeds threshold and comprehension guardrails pass.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
