# SEM-018 / AFC — Anti-Filler Captioning

## Definition

Remove basically, actually, kind of, really, and redundant phrases.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Auto-filler removal vs verbatim.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Overediting may alter speaker voice.

## Source IDs

S06; S07; S09; S10; S27
