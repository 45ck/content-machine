# KIN-007 / MAS — Motion as Syntax

## Definition

Use motion type to encode grammar: contrast slides apart, cause connects.

## Method family

- Category: Motion / Kinetic
- Family: Motion and Kinetic Text
- Class: Motion Method
- Phase: Explore later
- Priority: P3

## Proof claim

Adds retention or emphasis without effort/fatigue penalty.

## Mechanism bundle

KR; SIG

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

static overlay; constant kinetic text

## Minimum viable experiment

Consistent grammar vs random motion.

## Primary metrics

gist recall; action recall; perceived effort; fatigue; rewatch; visual recall

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Requires audience learning.

## Source IDs

S19; S27
