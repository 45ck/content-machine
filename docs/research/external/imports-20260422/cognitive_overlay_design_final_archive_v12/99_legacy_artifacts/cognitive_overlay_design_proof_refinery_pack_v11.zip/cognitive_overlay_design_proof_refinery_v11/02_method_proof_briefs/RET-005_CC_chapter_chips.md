# RET-005 / CC — Chapter Chips

## Definition

Tiny labels for 30–90s clips: Setup, Mistake, Fix, Rule.

## Method family

- Category: Platform / Retention
- Family: Platform Retention
- Class: Retention Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves early hold/completion while preserving comprehension.

## Mechanism bundle

PNF; AR

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

standard caption style

## Minimum viable experiment

Chapter chips vs none.

## Primary metrics

gist recall; action recall; perceived effort; 3s hold; completion; saves

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Too much structure for comedy.

## Source IDs

S09; S25
