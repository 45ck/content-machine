# TIM-014 / SAC — Speed-Adaptive Captions

## Definition

Detect playback speed or speech rate and adjust overlay density.

## Method family

- Category: Timing / Rhythm
- Family: Timing and Rhythm
- Class: Timing Method
- Phase: Explore later
- Priority: P3

## Proof claim

Improves immediate gist, smoothness, or effort versus sync/post-cue baseline.

## Mechanism bundle

PT; VWM

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

sync cue; post cue; no cue

## Minimum viable experiment

Manual fast/slow variants.

## Primary metrics

gist recall; action recall; perceived effort; smoothness; time-to-gist

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Platform may not expose playback speed.

## Source IDs

S06; S30
