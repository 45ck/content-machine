# AUD-001 / AUD — Audio-On Cue Mode

## Definition

When audio is expected, overlay only cues and structure, not full language.

## Method family

- Category: Sound / Multimodal
- Family: Sound and Multimodal
- Class: Rule / Mode
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves muted comprehension while preserving full accessibility.

## Mechanism bundle

DLA; MFR; ASE

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

audio-on only; native captions only

## Minimum viable experiment

Audio-on cue vs full overlay.

## Primary metrics

gist recall; action recall; perceived effort; muted comprehension; accessibility pass

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Fails if viewer is muted.

## Source IDs

S05; S10
