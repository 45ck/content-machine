# K09 — Visual Working Memory Chunking (VWM)

## Claim

Short semantic beats reduce working-memory burden versus long sentence blocks.

## Source support

S12; S07; S20

## Methods that rely on this kernel

OIOS; PCFB; MRR; TBSM; SLB

## What this kernel proves

It supports a mechanistic reason why the named methods may work. It does not prove the complete method by itself.

## What would falsify it

Long transcript blocks beat chunked semantic beats for target metrics.

## Minimum viable experiment

Create two or more overlay variants that isolate this mechanism while holding source footage, audio, and edit constant. Measure the mechanism-specific metric rather than only watch time.

## Required metrics

- Gist recall
- Action recall
- Perceived effort
- Visual recall where placement is involved
- Text dwell or gaze proxy where available
- Confusion comments for platform tests
