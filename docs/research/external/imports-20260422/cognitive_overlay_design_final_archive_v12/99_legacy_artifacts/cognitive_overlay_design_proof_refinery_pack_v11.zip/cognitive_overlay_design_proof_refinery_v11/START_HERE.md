# Start Here

This v11 pack is a proof refinery. It is designed to move from theory to evidence.

## What we are proving

We are not proving that one caption style works forever. We are proving which **mechanisms** work under which conditions.

The proof sequence is:

1. **FTO vs SCC** — does compression beat full transcript overlays for gist/action recall?
2. **SCC vs BCC** — do bionic concept anchors add value after compression?
3. **BCC vs BCC+** — do placement, visual-load adaptation, and muted-first design add value?
4. **BCC vs HBF** — do sparse anchors beat heavy bionic formatting?
5. **Sync vs PSP** — does predictive semantic priming improve time-to-gist?
6. **Bottom-fixed vs GSP** — does gaze-safe placement preserve visual information?
7. **Fixed density vs VLAC** — should word count adapt to visual load?

## What counts as proof

A method is not proven by looking plausible. It is proven when it beats its comparator on its intended metric without failing guardrails.

Example:

- SCC must improve gist/action recall per second versus FTO.
- BCC must beat SCC on clarity, memory, or attention efficiency.
- BCC+ must beat BCC on visual recall, effort, and muted comprehension.

## What counts as failure

A method fails if it:

- increases effort,
- reduces visual recall,
- damages accessibility,
- creates confusion comments,
- only improves watch time through ambiguity,
- performs worse than a simpler method.
