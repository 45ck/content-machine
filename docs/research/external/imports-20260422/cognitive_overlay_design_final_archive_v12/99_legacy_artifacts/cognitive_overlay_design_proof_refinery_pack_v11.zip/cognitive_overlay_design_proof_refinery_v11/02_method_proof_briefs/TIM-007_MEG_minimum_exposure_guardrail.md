# TIM-007 / MEG — Minimum Exposure Guardrail

## Definition

No caption shorter than 0.8 sec except one-word impact beats.

## Method family

- Category: Timing / Rhythm
- Family: Timing and Rhythm
- Class: Timing Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves immediate gist, smoothness, or effort versus sync/post-cue baseline.

## Mechanism bundle

PT; VWM

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

sync cue; post cue; no cue

## Minimum viable experiment

Min duration on/off variants.

## Primary metrics

gist recall; action recall; perceived effort; smoothness; time-to-gist

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May slow fast content.

## Source IDs

S03; S04; S06
