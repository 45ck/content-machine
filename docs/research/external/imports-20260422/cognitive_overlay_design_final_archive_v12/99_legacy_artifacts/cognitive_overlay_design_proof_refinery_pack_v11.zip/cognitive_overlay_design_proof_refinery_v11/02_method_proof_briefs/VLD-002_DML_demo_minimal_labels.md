# VLD-002 / DML — Demo Minimal Labels

## Definition

During demonstrations, show only verbs or labels: twist, lock, pull.

## Method family

- Category: Visual Load / Clutter
- Family: Visual Load and Clutter
- Class: Load-Control Method
- Phase: Pilot second
- Priority: P1

## Proof claim

Improves readability/effort in busy frames without hurting comprehension.

## Mechanism bundle

CRD; VWM; FPA

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

fixed density overlay

## Minimum viable experiment

Sentence captions vs labels in demo.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Too sparse for novices.

## Source IDs

S10; S15
