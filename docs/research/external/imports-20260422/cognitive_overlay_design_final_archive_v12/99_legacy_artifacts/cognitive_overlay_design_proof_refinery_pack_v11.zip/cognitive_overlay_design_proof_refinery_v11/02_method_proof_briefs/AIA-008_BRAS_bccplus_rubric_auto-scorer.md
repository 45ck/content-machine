# AIA-008 / BRAS — BCC+ Rubric Auto-Scorer

## Definition

Score compression, anchors, placement, load, contrast, muted clarity.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: System Module
- Phase: Pilot second
- Priority: P1

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

manual editor baseline

## Minimum viable experiment

Rubric vs no rubric production.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Scores may reward rules over outcomes.

## Source IDs

S02; S09; S28
