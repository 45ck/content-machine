# SEM-005 / PCFB — Problem–Cause–Fix Beat Cards

## Definition

Display three labels across the clip: Problem, Cause, Fix.

## Method family

- Category: Semantic / Compression
- Family: Semantic Compression
- Class: Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Improves gist/action recall per second vs full transcript overlay.

## Mechanism bundle

CLR; SIG; VWM

## Evidence grade

- Existing grade: Strong adjacent
- Proof grade: G-2: strong adjacent evidence
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

FTO; KHT; NNO

## Minimum viable experiment

Same explainer with/without beat labels.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Can feel like a slide deck if overused.

## Source IDs

S06; S07; S09; S10; S27
