# GAZ-016 / SFC — Speaker-Following Captions

## Definition

Move text near active speaker in multi-speaker clips.

## Method family

- Category: Placement / Gaze
- Family: Placement and Gaze
- Class: Placement Method
- Phase: Explore later
- Priority: P2

## Proof claim

Preserves visual recall and reduces gaze travel/conflict.

## Mechanism bundle

GSPM; CRD; FPA

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

bottom-fixed placement; random safe placement

## Minimum viable experiment

Bottom captions vs speaker-following.

## Primary metrics

gist recall; action recall; perceived effort; visual recall; text-face/object dwell ratio

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Motion may annoy frequent subtitle users.

## Source IDs

S13; S14
