# GAZ-019 / CCD — Caption Collision Detector

## Definition

Detect overlap with native captions, stickers, captions, and UI.

## Method family

- Category: Placement / Gaze
- Family: Placement and Gaze
- Class: Placement Method
- Phase: Pilot first
- Priority: P0

## Proof claim

Preserves visual recall and reduces gaze travel/conflict.

## Mechanism bundle

GSPM; CRD; FPA

## Evidence grade

- Existing grade: Strong practical / direct test needed
- Proof grade: G-P: engineering-practical
- Proof level needed: P1 controlled + P2 gaze/load + P3 platform

## Comparator

bottom-fixed placement; random safe placement

## Minimum viable experiment

Manual vs auto collision check.

## Primary metrics

gist recall; action recall; perceived effort; visual recall; text-face/object dwell ratio

## Pass rule

Keep if primary metric improves >=10 percentage points or d>=0.30 and no guardrail regression.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

False positives could restrict layout.

## Source IDs

S15; S28
