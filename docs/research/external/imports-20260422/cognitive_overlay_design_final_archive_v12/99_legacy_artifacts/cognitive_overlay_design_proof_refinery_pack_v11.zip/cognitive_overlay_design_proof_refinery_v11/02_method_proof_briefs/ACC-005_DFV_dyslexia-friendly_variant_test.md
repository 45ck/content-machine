# ACC-005 / DFV — Dyslexia-Friendly Variant Test

## Definition

Compare bionic, LARF-like annotation, spacing, and plain compression for dyslexic viewers.

## Method family

- Category: Personalization / Access
- Family: Accessibility and Personalization
- Class: Access / Personalization Method
- Phase: Explore later
- Priority: P3

## Proof claim

Should beat baseline on target metric.

## Mechanism bundle

AR; DLA

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P0 exploratory + segment analysis

## Comparator

current best baseline

## Minimum viable experiment

Dyslexic participants by overlay type.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Keep only if segment-specific advantage appears.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

Risk of overclaiming without subgroup testing.

## Source IDs

S22; S23
