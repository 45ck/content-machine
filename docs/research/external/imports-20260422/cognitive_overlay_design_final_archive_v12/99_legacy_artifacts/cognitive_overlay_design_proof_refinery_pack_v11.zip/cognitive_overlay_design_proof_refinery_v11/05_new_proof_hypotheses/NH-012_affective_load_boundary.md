# NH-012 — Affective Load Boundary

## Mechanism

Affective captions help emotion recognition but can harm clarity when overused.

## Minimum test

none vs subtle affective vs high affective styling.

## Source IDs

S19; S18

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
