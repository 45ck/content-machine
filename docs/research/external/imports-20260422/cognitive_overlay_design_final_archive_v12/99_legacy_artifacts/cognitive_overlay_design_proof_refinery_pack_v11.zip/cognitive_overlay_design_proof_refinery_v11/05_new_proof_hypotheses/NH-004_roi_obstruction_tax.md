# NH-004 — ROI Obstruction Tax

## Mechanism

Quantify loss when captions cover mouth, hands, product or important action.

## Minimum test

Covered ROI vs protected ROI variants.

## Source IDs

S13; S16

## Success criterion

Keep if it improves the target metric by a practical margin without increasing effort or failing guardrails.
