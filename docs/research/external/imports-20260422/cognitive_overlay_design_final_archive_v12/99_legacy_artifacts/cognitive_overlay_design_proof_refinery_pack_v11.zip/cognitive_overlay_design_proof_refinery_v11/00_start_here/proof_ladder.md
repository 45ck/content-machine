# Proof Ladder

| Level | Name | Meaning |
|---:|---|---|
| P0 | Mechanistic plausibility | Adjacent research supports the mechanism, but the method has not yet been directly tested. |
| P1 | Controlled superiority | The method beats a baseline in a controlled study on the intended metric. |
| P2 | Mechanistic corroboration | Eye tracking, gaze, workload, or behavioral data support the claimed mechanism. |
| P3 | Platform practical uplift | A/B testing shows useful improvement in real platform metrics without comprehension regressions. |
| P4 | Segment repeatability | The method works in its intended video/user segments, not only globally. |
| P5 | Adaptive proof | A routing engine selects winners by context and avoids known losers. |

## Practical significance gate

A result must be statistically credible and practically useful. A tiny statistically significant difference is not enough.

Default practical thresholds for pilot decisions:

- **Gist/action recall:** +10 percentage points or Cohen's d ≥ 0.30 for primary proof.
- **Perceived effort:** at least -0.5 on a 7-point scale or d ≤ -0.30.
- **Visual recall:** noninferior within a -5 percentage point margin unless visual recall is not relevant.
- **Platform completion:** +5% relative improvement minimum before deployment.
- **Confusion comments:** must not increase.

## Guardrail rule

A method cannot be called a winner if it fails accessibility, contrast, or obstruction guardrails.
