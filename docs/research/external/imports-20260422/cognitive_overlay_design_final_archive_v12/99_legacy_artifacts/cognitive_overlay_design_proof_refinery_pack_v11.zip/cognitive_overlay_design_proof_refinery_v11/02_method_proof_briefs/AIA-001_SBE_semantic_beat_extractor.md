# AIA-001 / SBE — Semantic Beat Extractor

## Definition

LLM extracts proposition, role, and beat boundaries from transcript.

## Method family

- Category: AI / Adaptive
- Family: AI and Adaptive Systems
- Class: System Module
- Phase: Pilot second
- Priority: P1

## Proof claim

Matches or exceeds human editor quality at lower time cost.

## Mechanism bundle

AR; GSPM; CRD

## Evidence grade

- Existing grade: Speculative / direct test needed
- Proof grade: G-0: speculative
- Proof level needed: P1 controlled + P3 platform if promising

## Comparator

manual editor baseline

## Minimum viable experiment

Human vs AI beat extraction.

## Primary metrics

gist recall; action recall; perceived effort; human rating; editing time; failure rate

## Pass rule

Keep if primary metric improves >=5 percentage points or d>=0.20 and qualitative preference is positive.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

LLM may hallucinate or distort meaning.

## Source IDs

S09; S30
