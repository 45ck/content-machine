# Evidence Kernel Index

- `K01_CLR_compression_load_reduction.md` — **CLR / Compression Load Reduction**
- `K02_SIG_structured_signaling.md` — **SIG / Structured Signaling**
- `K03_SAA_sparse_attention_anchoring.md` — **SAA / Sparse Attention Anchoring**
- `K04_DLA_dual-layer_access_preservation.md` — **DLA / Dual-Layer Access Preservation**
- `K05_MFR_muted-first_resilience.md` — **MFR / Muted-First Resilience**
- `K06_GSPM_gaze-safe_placement.md` — **GSPM / Gaze-Safe Placement**
- `K07_CRD_crowding_avoidance.md` — **CRD / Crowding Avoidance**
- `K08_FPA_foveal-peripheral_architecture.md` — **FPA / Foveal-Peripheral Architecture**
- `K09_VWM_visual_working_memory_chunking.md` — **VWM / Visual Working Memory Chunking**
- `K10_PT_predictive_timing.md` — **PT / Predictive Timing**
- `K11_KR_kinetic_restraint.md` — **KR / Kinetic Restraint**
- `K12_ASE_affective-semantic_encoding.md` — **ASE / Affective-Semantic Encoding**
- `K13_PNF_platform-native_fit.md` — **PNF / Platform-Native Fit**
- `K14_AR_adaptive_routing.md` — **AR / Adaptive Routing**
- `K15_PI_proof_integrity.md` — **PI / Proof Integrity**
