# EXP-004 — Visual Load Adaptive Density Trial

## Purpose

Prove busy frames need lower text density.

## Conditions

fixed 6 words; adaptive 1-7 words; labels-only in busy frames; full transcript

## Primary metric

effort reduction in busy scenes

## Secondary metrics

gist/action recall; visual recall

## Decision rule

VLAC wins if busy-scene effort drops and gist remains noninferior.

## Design notes

- Hold source footage and audio constant.
- Randomize presentation order.
- Separate audio-on and muted viewing where relevant.
- Report both statistical and practical significance.
- Include failure mode observations.
