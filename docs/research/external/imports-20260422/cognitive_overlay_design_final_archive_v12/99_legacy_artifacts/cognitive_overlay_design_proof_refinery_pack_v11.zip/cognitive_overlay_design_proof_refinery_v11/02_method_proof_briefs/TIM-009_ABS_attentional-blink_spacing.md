# TIM-009 / ABS — Attentional-Blink Spacing

## Definition

Avoid presenting two critical words within 200–500 ms.

## Method family

- Category: Timing / Rhythm
- Family: Timing and Rhythm
- Class: Timing Method
- Phase: Explore later
- Priority: P2

## Proof claim

Improves immediate gist, smoothness, or effort versus sync/post-cue baseline.

## Mechanism bundle

PT; VWM

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

sync cue; post cue; no cue

## Minimum viable experiment

Critical words close vs spaced.

## Primary metrics

gist recall; action recall; perceived effort; smoothness; time-to-gist

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May slow high-energy edits.

## Source IDs

S24; S29
