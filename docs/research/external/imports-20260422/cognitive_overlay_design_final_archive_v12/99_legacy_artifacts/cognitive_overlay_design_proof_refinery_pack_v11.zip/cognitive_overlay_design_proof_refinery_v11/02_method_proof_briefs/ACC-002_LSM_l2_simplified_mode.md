# ACC-002 / LSM — L2 Simplified Mode

## Definition

Use simpler vocabulary and more context for second-language viewers.

## Method family

- Category: Personalization / Access
- Family: Accessibility and Personalization
- Class: Rule / Mode
- Phase: Explore later
- Priority: P2

## Proof claim

Should beat baseline on target metric.

## Mechanism bundle

AR; DLA

## Evidence grade

- Existing grade: Moderate adjacent
- Proof grade: G-1: moderate adjacent evidence
- Proof level needed: P0/P1 pilot only

## Comparator

current best baseline

## Minimum viable experiment

Native vs L2-tailored captions.

## Primary metrics

gist recall; action recall; perceived effort

## Pass rule

Promote if directional effect appears in pilot and no major failure mode occurs.

## Fail / demote rule

Demote if it fails target metric, increases perceived effort, damages visual recall, or creates accessibility/contrast/obstruction failures.

## Failure mode to watch

May feel too simple for natives.

## Source IDs

S07; S10
