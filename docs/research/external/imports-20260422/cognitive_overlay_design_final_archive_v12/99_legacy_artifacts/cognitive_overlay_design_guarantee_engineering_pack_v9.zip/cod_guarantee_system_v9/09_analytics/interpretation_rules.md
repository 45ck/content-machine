# Interpretation Rules

## Declare winner only if

1. primary metric improves beyond threshold,
2. guardrails pass,
3. result repeats or is large enough to justify more testing,
4. no known confound dominates the result.

## Do not declare winner if

- only one viral post drove the result,
- comprehension dropped,
- accessibility failed,
- confusion comments rose,
- exact wording mattered but was lost,
- visual recall fell because text stole gaze.

## Interpret outcomes

| Result | Decision |
|---|---|
| BCC > SCC | Keep bionic anchors for this segment. |
| SCC >= BCC | Make bionic optional; focus on compression. |
| BCC+ > BCC | Placement/density/timing drive gains. |
| HBC wins engagement but loses comprehension | Reject as manipulation/noise. |
| FTO wins exact recall | Use full captions when precision matters. |
| MFC wins muted | Use muted-first variant for sound-off contexts. |
