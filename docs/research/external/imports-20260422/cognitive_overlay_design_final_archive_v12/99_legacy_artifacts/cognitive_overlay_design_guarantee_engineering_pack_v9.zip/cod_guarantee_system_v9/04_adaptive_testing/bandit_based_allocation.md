# Bandit-Based Allocation — BBA

Bandit-Based Allocation is useful after basic safety and quality have been established.

## Purpose

Instead of splitting traffic evenly forever, BBA explores variants while shifting more exposure toward the current best performers.

## Use BBA when

- variants have passed preflight gates,
- no variant creates accessibility or comprehension risk,
- the platform/context allows repeated comparable tests,
- you want faster learning and less exposure wasted on weak variants.

## Do not use BBA when

- you need clean causal evidence for publication,
- the variants are unsafe or unvalidated,
- a short-term metric may reward confusion,
- the goal is exact comprehension rather than engagement.

## Practical allocation

Start with equal exploration for the first wave. Then reallocate toward variants with better meaning-per-second, completion, and comprehension guardrails.
