# Variant Portfolio

The guarantee comes from having a portfolio, not from forcing one style.

## Core variants

| Code | Name | Use |
|---|---|---|
| NCO | Native Captions Only | Baseline |
| FTO | Full Transcript Overlay | Exact wording baseline |
| KHT | Keyword Highlight Transcript | Highlight baseline |
| SCC | Semantic Compression Captions | Compression baseline |
| BCC | Bionic Compression Captioning | Tests bionic concept anchors |
| BCC+ | Bionic Compression Captioning Plus | Tests adaptive placement/density/timing |
| HBC | Heavy Bionic Control | Negative/noise control |
| WDC | Word-by-Word Dynamic Captions | Common creator-style control |

## Expansion variants

- PSP — Predictive Semantic Priming
- GSP — Gaze-Safe Placement
- VLAC — Visual-Load Adaptive Captioning
- MRR — Micro-Rest Rhythm
- MFC — Muted-First Captioning
- ASC — Action-Safe Captioning
- AFC — Affective-Semantic Captions
- PCM — Problem-Cause-Fix Cards
- OFC — Operator-First Captioning
- SMO — Static Memory Object

## Rule

Every test must include at least one conservative baseline and one negative/noise control when possible.
