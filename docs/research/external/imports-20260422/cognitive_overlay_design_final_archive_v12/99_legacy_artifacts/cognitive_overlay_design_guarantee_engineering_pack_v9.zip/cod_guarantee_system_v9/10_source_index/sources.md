# Source Index

- **S001 — Bionic Reading evidence**: Bionic Reading has weak empirical support as a general reading-speed/comprehension improvement.  
  https://www.sciencedirect.com/science/article/pii/S0001691824001811
- **S002 — Sound-off subtitle viewing**: Watching subtitled videos without sound increased cognitive load and reduced comprehension/immersion/enjoyment in a 2024 eye-tracking study.  
  https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0306251
- **S003 — Subtitle speed**: Subtitle speed affects comprehension, word skipping, and rereading; faster subtitles can reduce comprehension.  
  https://www.cambridge.org/core/journals/applied-psycholinguistics/article/why-subtitle-speed-matters-evidence-from-word-skipping-and-rereading/A7DB0CBF5910353143738CF9C1721317
- **S004 — Partial synchronized captioning**: Partial synchronized captioning achieved similar comprehension to full captions while showing less than 30% of transcript in an L2 context.  
  https://www.cambridge.org/core/journals/recall/article/partial-and-synchronized-captioning-a-new-tool-to-assist-learners-in-developing-second-language-listening-skill/9394E3F0AD25FD5F32895F965F7ECCAD
- **S005 — Signaling in multimedia learning**: Signaling/cueing improves retention/transfer and can reduce cognitive load across multimedia learning studies.  
  https://www.sciencedirect.com/science/article/abs/pii/S1747938X17300581
- **S006 — Meaning maps**: Meaning can explain attention in real-world scenes beyond low-level salience.  
  https://www.nature.com/articles/s41598-018-31894-5
- **S007 — Video saliency prediction**: AViMoS/AIM 2024 provides large-scale video saliency data including vertical videos and observer fixations.  
  https://arxiv.org/abs/2409.14827
- **S008 — Gaze-adaptive captions**: Gaze-adaptive caption placement is a studied direction for video subtitles.  
  https://dl.acm.org/doi/fullHtml/10.1145/3313831.3376266
- **S009 — Always-valid inference**: Always-valid inference supports continuous monitoring of A/B tests without invalidating inference under sequential decisions.  
  https://pubsonline.informs.org/doi/10.1287/opre.2021.2135
- **S010 — Bandit experimental design**: Multi-armed bandit experimental design supports adaptive online decision-making and inference.  
  https://pubsonline.informs.org/doi/10.1287/mnsc.2023.00492
- **S011 — A/B vs multi-armed bandit**: A/B tests and multi-armed bandits serve different roles; bandits adapt allocation toward better-performing options while continuing exploration.  
  https://experienceleague.adobe.com/en/docs/journey-optimizer/using/content-management/content-experiment/technotes/mab-vs-ab
- **S012 — Bayesian optimization experiments**: Bayesian optimization is an adaptive method for selecting successive experimental conditions from observed outcomes.  
  https://www.sciencedirect.com/science/article/pii/S2405844024005152
- **S013 — W3C captions**: Captions are synchronized text alternatives for speech and relevant non-speech audio; closed captions can be toggled and open captions are embedded.  
  https://www.w3.org/WAI/media/av/captions/
- **S014 — Caption speed guidelines**: Accessibility guidance commonly recommends short captions and warns that speech above about 180 wpm can be too fast for captions.  
  https://www.section508.gov/create/captions-transcripts/
- **S015 — Multimedia redundancy**: Redundancy in multimedia can help or harm depending on working memory load and channel competition.  
  https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2023.1148035/full
