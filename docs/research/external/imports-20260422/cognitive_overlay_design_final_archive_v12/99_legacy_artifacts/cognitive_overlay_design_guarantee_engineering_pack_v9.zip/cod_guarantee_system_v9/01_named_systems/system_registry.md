# Named Systems Registry

These names are the missing layer between ideas and execution.

| Code | Name | Purpose |
|---|---|---|
| WGE | Work Guarantee Engine | Master closed-loop system |
| SVL | Success Validation Ladder | Evidence maturity status |
| SDP | Success Definition Protocol | Defines “working” before launch |
| QGF | Quality Gate Framework | Blocks weak overlays preflight |
| ATL | Adaptive Testing Loop | Repeated testing/improvement loop |
| SET | Sequential Evidence Testing | Avoids naive peeking in live tests |
| BBA | Bandit-Based Allocation | Sends more exposure toward winners while exploring |
| BOS | Bayesian Optimization Search | Optimizes continuous design variables |
| FTE | Failure Triage Engine | Converts failures into next actions |
| FPL | Fallback Policy Ladder | Replaces failed variants with safer alternatives |
| BDL | Baseline Defense Layer | Keeps a safe default available |
| CES | Content-Environment Segmentation | Chooses methods by content type |
| VBL | Variant Bank Library | Stores all named variants and results |
| GFE | Guardrail Failover Engine | Prevents harmful or manipulative optimization |
| PWR | Probability-of-Working Rating | Prioritizes test ideas |

See `system_registry.csv` for detailed definitions.
