# Success Thresholds

A method only “works” if it beats the baseline on a declared primary metric without violating guardrails.

## Recommended baseline

Use at least one baseline:

- **NCO** — Native Captions Only
- **FTO** — Full Transcript Overlay
- **SCC** — Semantic Compression Captions

## Default minimum win

For a small pilot:

- **+5 percentage points absolute** or **+10% relative** improvement in the primary metric.

For live platform use:

- use platform variability-aware thresholds,
- avoid declaring victory from one viral outlier,
- use repeated wins across similar content.

## Metrics table

See `success_thresholds.csv`.

## Do not optimize only watch time

Watch time can rise because of confusion, controversy, or rewatching to decode unclear text. The guarantee requires a comprehension guardrail.
