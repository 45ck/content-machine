# Failure Modes

## Over-compression

Symptom: viewer cannot understand the meaning without prior context.

Fix: add one clarifying word or use a structured beat card.

## Over-anchoring

Symptom: text looks busy; every word competes for attention.

Fix: reduce anchors to operators and concept words only.

## Visual theft

Symptom: viewer remembers text but not the demonstration, face, or product.

Fix: use gaze-safe placement, visual-load adaptive density, and micro-rests.

## Redundancy overload

Symptom: audio, full captions, and overlay all say the same thing.

Fix: make the overlay structural rather than verbatim.

## Platform mismatch

Symptom: overlay looks clean in editor but fails on TikTok/Reels due to UI and small display.

Fix: mobile preview, UI-safe zones, and platform-specific templates.

## False-positive retention

Symptom: high rewatch rate but confused comments.

Fix: prioritize comprehension metrics over raw retention.

## Unsupported scientific claim

Symptom: claiming Bionic Reading makes people read faster.

Fix: say bionic anchors are sparse visual cues; compression and signaling are the core mechanisms.
