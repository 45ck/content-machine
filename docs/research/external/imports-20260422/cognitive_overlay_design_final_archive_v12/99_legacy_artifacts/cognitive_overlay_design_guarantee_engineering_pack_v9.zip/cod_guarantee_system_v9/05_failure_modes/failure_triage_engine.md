# Failure Triage Engine — FTE

The FTE is how the system keeps finding ways until a variant works.

## Principle

A failed metric is not a dead end. It is a diagnostic signal.

## Example

If BCC gets higher watch time but lower gist recall, do not call it successful. Diagnose it as possible confusion-driven retention and switch to simpler SCC or Problem-Cause-Fix Cards.

## Triage matrix

See `failure_triage_matrix.csv`.

## Critical rule

Do not optimize one metric in isolation. Every win needs a guardrail.
