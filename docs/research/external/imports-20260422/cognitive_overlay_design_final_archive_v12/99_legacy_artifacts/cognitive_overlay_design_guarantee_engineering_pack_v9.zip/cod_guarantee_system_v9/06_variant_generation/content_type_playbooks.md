# Content-Type Playbooks

Do not apply BCC+ blindly. Match the overlay to the viewing task.

See `content_type_playbooks.csv`.

## Examples

### Talking head / conceptual

Use: SCC, BCC, BCC+, PSP, MRR.

### Product demo

Use: Action-Safe Captioning, Object-near Labels, VLAC. Avoid covering the product or hands.

### Emotional story

Use: Low-motion, face-safe, affective-semantic captions. Avoid blocking the eyes.

### Education/explainer

Use: Problem-Cause-Fix Cards, Progress Maps, SCC/BCC+.
