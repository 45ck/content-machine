# Guarantee Position

## What cannot be guaranteed

No one can honestly guarantee that BCC, BCC+, or any short-form overlay style will universally increase views, watch time, comprehension, or retention on every TikTok/Reel/Short.

Reasons:

- platforms distribute content unpredictably;
- audiences differ by niche, age, language, ability, and viewing state;
- content type matters more than styling in many cases;
- novelty decays;
- heavy overlays can harm some videos;
- bionic-style text has weak evidence as a general speed-reading method.

## What can be guaranteed

We can guarantee the process:

1. Every method has a name and code.
2. Every method has a hypothesis.
3. Every method is tested against a baseline.
4. No method becomes default unless it beats the baseline by a practical margin.
5. Failed methods are routed to fallback variants.
6. The system continuously explores alternatives.
7. Accessibility captions remain available.
8. Visual overload is actively controlled.

## The correct guarantee

> We do not guarantee that one overlay style always works. We guarantee that the system will identify, deploy, or fall back to the best verified overlay for each content context.

That is the defensible guarantee.

## Operating principle

> Do not make viewers read faster. Engineer the video so they need fewer fixations to understand more.
