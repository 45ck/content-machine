# Ways to Make It Work

This is the practical intervention list. Use these before declaring the concept failed.

## Meaning interventions

1. Replace transcript with semantic compression.
2. Add explicit operator words: Not, Stop, First, Then, Less, More.
3. Convert vague text into relation patterns: Not X → Y; Problem → Cause → Fix.
4. Add one clarifying context word if muted comprehension fails.
5. Use memory-object captions for the final line.
6. Use action captions when the video gives advice.
7. Use beat cards when the argument has multiple parts.
8. Use retrieval-prompt captions for educational content.
9. Remove any word that does not change the meaning.
10. Keep one idea per screen.

## Visual interventions

11. Move text away from the mouth.
12. Move text away from the eyes during emotional content.
13. Move text away from hands/products during demos.
14. Avoid the platform UI safe zones.
15. Add a clean background plate behind text if the scene is busy.
16. Increase text size on mobile.
17. Use high contrast.
18. Avoid placing overlay on top of native captions.
19. Use peripheral cues instead of peripheral sentences.
20. Use arrows/icons for demos instead of word blocks.

## Timing interventions

21. Show semantic text 200–400 ms before the spoken beat.
22. Sync text with visual cuts when cuts mark idea changes.
23. Use micro-rests between captions.
24. Delay the memory stamp until the final beat.
25. Avoid changing captions during fast hand/object motion.
26. Keep one-word impacts short but readable.
27. Keep 4–7 word beats on screen longer.
28. Remove text during critical visual actions.
29. Use pause captions during natural speech pauses.
30. Avoid rapid one-word RSVP for dense concepts.

## Emphasis interventions

31. Bold operators fully.
32. Use bionic partial emphasis only on concept words.
33. Highlight no more than 1–3 items per screen.
34. Remove highlight from filler words.
35. Test no-bionic SCC against BCC.
36. Ban heavy bionic if it increases effort.
37. Use color coding only with redundant shape/weight cues.
38. Use consistent operator syntax across videos.
39. Use static text as the signal in a motion-heavy feed.
40. Use motion only for logic transitions.

## Adaptation interventions

41. Use different overlay modes for audio-on and muted viewing.
42. Use simpler captions for beginners.
43. Use compressed shorthand for experts.
44. Use L2 simplified mode for second-language audiences.
45. Use low-motion mode for accessibility/fatigue contexts.
46. Use gaze-safe placement for talking heads.
47. Use object-near labels for demos.
48. Use screen-recording safe zones for tutorials.
49. Route by content type rather than by global winner.
50. Keep exploration allocation for new variants.

## Validation interventions

51. Define “works” before posting.
52. Pair platform metrics with comprehension metrics.
53. Require practical significance, not only statistical significance.
54. Use a negative control such as HBC.
55. Keep baseline variants in every test.
56. Do not ship a variant that improves watch time but reduces understanding.
57. Repeat winning tests across multiple topics.
58. Segment results by video type.
59. Track confusion comments.
60. Re-run tests when platform norms change.

## Strategic principle

> Make the system impossible to fail by making failure informative and by never shipping unverified variants as defaults.
