# First Tests to Run

## Batch 1 — isolate the engine

1. SCC vs BCC vs BCC+
2. SCC vs BCC vs Heavy Bionic Control
3. Full Transcript vs SCC
4. Keyword Highlight Transcript vs SCC
5. Word-by-Word Dynamic Captions vs SCC

## Batch 2 — placement and visual load

6. Bottom-Fixed vs Gaze-Safe Placement
7. Mouth-Safe vs Mouth-Covering
8. Action-Safe vs Action-Covering
9. Fixed density vs Visual-Load Adaptive Captioning
10. Plain background vs busy background with same overlay

## Batch 3 — timing

11. Predictive Semantic Priming -400 ms
12. Predictive Semantic Priming -200 ms
13. Sync cue
14. Post-cue +200 ms
15. Post-cue +400 ms

## Batch 4 — motion and rhythm

16. Static BCC
17. Subtle fade/scale
18. Logic motion
19. Word pop
20. Constant kinetic text
21. Micro-rest rhythm vs continuous text

## Batch 5 — viewer/context adaptation

22. Audio-on cue mode
23. Muted-first mode
24. Beginner mode
25. Expert mode
26. L2 simplified mode
27. Low-motion accessibility mode

## Batch 6 — platform validation

28. Top controlled winner vs baseline live A/B
29. Top two variants with bandit allocation
30. Segment-specific default test

See `experiment_backlog.csv` for decision rules.
