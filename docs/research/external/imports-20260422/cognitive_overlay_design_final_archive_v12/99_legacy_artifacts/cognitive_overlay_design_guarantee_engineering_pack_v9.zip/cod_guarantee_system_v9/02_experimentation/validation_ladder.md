# Validation Ladder

## Stage 1 — Technical QA

Gate:

- caption files export correctly;
- text is readable on a phone;
- overlays stay inside platform safe zones;
- closed captions exist separately;
- no text covers mouth, eyes, hands, product, or UI unless intentional.

## Stage 2 — Comprehension pilot

Test 20–50 people or a small internal review panel.

Required comparisons:

1. FTO vs SCC
2. SCC vs BCC
3. BCC vs BCC+
4. BCC vs HBC

Pass if:

- gist recall improves;
- action recall improves;
- perceived effort does not increase;
- visual recall does not collapse.

## Stage 3 — Platform A/B test

Post matched variants or use ad/organic split tests.

Track:

- 1s hold;
- 3s hold;
- completion;
- average watch time;
- saves;
- shares;
- confusion comments.

Pass if the variant improves one primary metric without damaging guardrail metrics.

## Stage 4 — Segment routing

Once a variant works for one context, do not assume it works for all.

Route by:

- content type;
- visual load;
- audio-on vs muted;
- language ability;
- audience expertise;
- platform;
- video length;
- speaker vs demo.

## Stage 5 — Adaptive system

Use sequential testing or bandit-style allocation to keep discovering winners while reducing exposure to weak variants.
