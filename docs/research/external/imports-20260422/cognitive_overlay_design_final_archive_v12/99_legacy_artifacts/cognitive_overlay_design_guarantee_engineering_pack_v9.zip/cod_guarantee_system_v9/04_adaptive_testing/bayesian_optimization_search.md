# Bayesian Optimization Search — BOS

BOS is for continuous design parameters.

## Parameters to optimize

- caption lead time: -400 ms to +400 ms
- words per beat: 1-8
- line count: 1-2
- placement x/y zone
- motion dose: static to active
- bionic anchor density: 0-3 anchors
- micro-rest duration
- plate opacity / background contrast

## Objective function

Default objective:

> maximize meaning-per-second while preserving comprehension, accessibility, and visual recall guardrails.

## Why useful

Manual testing can compare named methods. BOS can tune the exact numbers inside a winning method.
