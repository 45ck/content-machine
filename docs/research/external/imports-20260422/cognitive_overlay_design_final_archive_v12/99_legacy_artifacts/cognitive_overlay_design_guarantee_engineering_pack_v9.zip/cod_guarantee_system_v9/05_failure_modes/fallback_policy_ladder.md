# Fallback Policy Ladder — FPL

The Fallback Policy Ladder makes the system robust.

## Default ladder

1. Try **BCC+** for dense conceptual short-form.
2. If BCC+ is too visually busy, switch to **BCC**.
3. If bionic anchors add noise, switch to **SCC**.
4. If SCC is too compressed, switch to **SCC+ Context Beat**.
5. If muted comprehension fails, use **MFC** or **DLC**.
6. If exact wording matters, use **FTO** plus sparse highlight.
7. If accessibility is priority, use **DLC** and keep overlay minimal.
8. If all creative overlays fail, use **NCO/FTO baseline**.

## The guarantee

The system never has to defend a failing style. It changes method.
