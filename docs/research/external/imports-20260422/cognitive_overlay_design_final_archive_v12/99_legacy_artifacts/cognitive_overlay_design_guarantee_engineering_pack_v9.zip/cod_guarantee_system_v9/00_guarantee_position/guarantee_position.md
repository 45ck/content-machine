# Guarantee Position

## The wrong guarantee

> “BCC will always outperform normal captions.”

This is not defensible. It would fail across audience types, languages, content formats, emotional clips, accessibility needs, and platform contexts.

## The right guarantee

> **A closed-loop overlay system can guarantee that unproven variants are not treated as winners. It can keep testing, diagnosing, and switching until a variant clears the selected success threshold.**

This turns the guarantee from a claim into a system.

## What can be guaranteed

| Guarantee | Meaning |
|---|---|
| Process guarantee | Every variant goes through quality gates before testing. |
| Evidence guarantee | No variant is promoted without beating a baseline. |
| Fallback guarantee | Failed variants trigger a named fallback. |
| Accessibility guarantee | Full captions are preserved separately from creative overlays. |
| Measurement guarantee | “Works” is defined before launch. |
| Adaptation guarantee | The system keeps changing the overlay until a threshold is met or the content is classified unsupported. |

## What cannot be guaranteed honestly

| Non-guarantee | Why |
|---|---|
| One style wins for every viewer | Audiences differ. |
| One style wins for every content type | Talking heads, demos, stories, and comedy have different bottlenecks. |
| Bionic styling itself improves reading speed | Existing evidence is weak. |
| A/B results are reliable without correct testing | Peeking and small samples can create false winners. |
| Engagement gains equal comprehension gains | Watch time can rise from confusion, controversy, or manipulation. |

## Final standard

A method **works** only when it clears a declared metric against a relevant baseline in the intended content/audience context.
