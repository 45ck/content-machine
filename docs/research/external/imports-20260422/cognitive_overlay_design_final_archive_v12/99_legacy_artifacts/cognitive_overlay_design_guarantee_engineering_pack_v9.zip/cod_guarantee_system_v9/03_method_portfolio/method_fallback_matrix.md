# Method Fallback Matrix

Use this when a variant fails.

| Failure observed | Likely cause | Switch to |
|---|---|---|
| Viewers cannot explain main idea | Over-compressed / unclear | SCC with one extra context word |
| Viewers miss the action visually | Overlay stealing gaze | GSP + VLAC + MRR |
| Text feels noisy | Too many anchors/motion | SCC or sparse BCC |
| BCC no better than SCC | Bionic anchors not adding value | SCC default |
| Heavy bionic performs worse | Whole-text styling overload | Ban HBC except as negative control |
| Muted viewers fail | Overlay not self-contained | MFC + SCC/BCC+ + DLC |
| Audio-on viewers find text redundant | Too much duplicate transcript | SCC or keyword-only cue mode |
| Product/demo clarity drops | Text covering hands/object | Action-Safe Captioning + object labels |
| Emotional tone lost | Compression too cold | Affective-Semantic Captions |
| Completion low in first 3 sec | weak hook/payoff | Hook Card + Resolution-Payoff Captioning |
| Saves low despite watch time | Content memorable but not actionable | Action Checklist Overlay |
| Rewatch high but comments confused | Ambiguous or too dense | simplify semantic beats |

## Rescue order

1. Reduce words.
2. Move text away from critical visual regions.
3. Add structure labels.
4. Remove excess motion.
5. Make muted meaning clear.
6. Add full captions if absent.
7. Re-test.
