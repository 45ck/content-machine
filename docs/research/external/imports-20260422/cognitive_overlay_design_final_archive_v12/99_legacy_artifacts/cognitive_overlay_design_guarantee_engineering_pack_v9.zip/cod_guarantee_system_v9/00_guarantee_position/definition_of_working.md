# Definition of “Working”

The word **working** must be defined per video. A caption system can optimize different outcomes, and those outcomes can conflict.

## Possible targets

| Target | Best metric |
|---|---|
| Faster gist | Gist recall after one viewing |
| Viewer action | Action recall / correct next step |
| Platform retention | 3-second hold, average watch time, completion rate |
| Muted comprehension | Main point understood with audio off |
| Visual preservation | Recall of what happened visually |
| Accessibility | Full captions available, readable, non-obstructive |
| Memorability | Delayed recall of phrase or concept |
| Reduced effort | Perceived effort and cognitive-load proxy |

## Primary metric by content type

| Content type | Primary metric | Secondary metric |
|---|---|---|
| Productivity/advice | Action recall | Saves/completion |
| Education/explainer | Gist recall | Transfer question |
| Product demo | Visual recall | Conversion/click/saves |
| Fitness/tutorial | Step recall | Form/action recall |
| Story/emotional | Immersion | Tone recall |
| Comedy | Completion | Rewatch/share |
| Accessibility-first | Full comprehension | Caption preference |

## Minimum winning rule

A variant wins only if it beats the baseline on the primary metric **without violating guardrails**.

Guardrails:

- no accessibility regression,
- no major visual obstruction,
- no excessive text load,
- no false or distorted meaning,
- no improvement caused only by confusion.
