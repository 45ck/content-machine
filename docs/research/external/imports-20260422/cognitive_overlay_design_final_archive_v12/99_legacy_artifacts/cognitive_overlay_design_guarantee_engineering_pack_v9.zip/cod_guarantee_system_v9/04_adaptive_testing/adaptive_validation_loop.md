# Adaptive Testing Loop — ATL

The Adaptive Testing Loop is the practical way to “make it work.”

## Loop

1. Diagnose content type.
2. Select baseline and 3-5 variants.
3. Pass preflight gates.
4. Publish controlled variants.
5. Measure primary metric + guardrails.
6. Diagnose failure.
7. Select fallback or mutation.
8. Retest.
9. Promote only segment-proven winners.

## Why adaptive testing is necessary

Short-form content has large variance: creator trust, hook strength, topic, trend timing, platform distribution, thumbnail frame, audience segment, sound state, and caption design all interact. One fixed method will not dominate every context.

## Recommended flow

### Stage 1 — Controlled pilot

Use fixed variants:

- NCO
- FTO
- SCC
- BCC
- BCC+
- HBC

### Stage 2 — Live A/B

Test the top two or three variants per content category.

### Stage 3 — Bandit optimization

Once safe variants exist, use adaptive allocation to send more exposure to likely winners while retaining exploration.

### Stage 4 — Segment default

Declare a default for each content segment only after repeated wins.
