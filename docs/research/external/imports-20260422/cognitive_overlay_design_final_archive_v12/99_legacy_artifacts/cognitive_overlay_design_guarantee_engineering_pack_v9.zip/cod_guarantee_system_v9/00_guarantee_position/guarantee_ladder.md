# Success Validation Ladder — SVL

The Success Validation Ladder prevents premature certainty.

| Level | Name | Status | Requirement |
|---:|---|---|---|
| SVL-0 | Idea | Not validated | Named concept only |
| SVL-1 | Theory-fit | Plausible | Mechanism maps to research |
| SVL-2 | Preflight-pass | Production ready | Passes quality gates |
| SVL-3 | Lab-signal | Early evidence | Beats baseline in controlled recall/effort test |
| SVL-4 | Platform-signal | Live evidence | Beats baseline in platform A/B test |
| SVL-5 | Segment-proven | Context evidence | Wins for a named content/audience segment |
| SVL-6 | Adaptive-proven | System evidence | Bandit/optimization loop repeatedly selects it under similar conditions |
| SVL-7 | Standard method | Operational default | Becomes default for that segment unless displaced |

## Rule

Do not call a method “proven” unless it reaches at least **SVL-4**.

Do not make it a default unless it reaches **SVL-5** for the target segment.
