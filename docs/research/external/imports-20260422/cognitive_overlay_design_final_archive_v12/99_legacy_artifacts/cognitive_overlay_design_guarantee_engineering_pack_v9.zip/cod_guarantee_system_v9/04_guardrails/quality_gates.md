# Quality Gates

A variant cannot ship unless it passes these gates.

## Accessibility gate

- Full captions exist separately from the creative overlay.
- Captions include meaningful non-speech audio where needed.
- Overlay does not obstruct critical video information.
- Color is not the only cue.
- Contrast is sufficient for mobile viewing.

## Readability gate

- 2–7 words per semantic beat.
- No more than 1–3 emphasized items per screen.
- No long full-sentence overlay unless the goal is exact transcript access.
- Text remains readable on a phone.
- No critical text sits under platform UI.

## Visual gate

- Do not cover mouth in speech-heavy clips.
- Do not cover eyes in emotional clips.
- Do not cover hands/products in demos.
- Do not cover joints/body lines in fitness clips.
- Avoid cluttered backgrounds unless text has a plate.

## Timing gate

- Captions land on semantic beats.
- No high-density text during critical visual action.
- No continuous text with no visual rest in dense content.
- Predictive text is not so early that it feels disconnected.

## Ethics gate

- Do not optimize for confusion-driven rewatch.
- Do not use misleading hooks.
- Do not claim unsupported speed-reading effects.
- Do not reduce accessibility for retention.
