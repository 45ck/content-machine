# Guaranteed Portfolio Strategy

A single method can fail. A portfolio can adapt.

## Core portfolio

| Code | Role |
|---|---|
| NCO | Minimum baseline |
| FTO | Exact transcript baseline |
| KHT | Transcript with sparse emphasis |
| SCC | Compression-only challenger |
| BCC | Tests bionic anchor value |
| BCC+ | Tests adaptive placement and load control |
| HBC | Negative control for over-bionic styling |
| VLAC | Fixes busy visual scenes |
| GSP | Fixes gaze conflict |
| MRR | Fixes continuous reading pressure |
| PSP | Tests predictive timing |

## Portfolio guarantee

If the portfolio includes the current baseline and rejects variants that fail, then the production system can avoid adopting a worse default.

The goal is not to prove one style universal. The goal is to always have:

1. a safe baseline;
2. a challenger;
3. a negative control;
4. a fallback;
5. an adaptation path.

## Practical deployment rule

For each content type, maintain a current best default:

| Content type | Default to test first |
|---|---|
| talking-head advice | SCC/BCC/BCC+ |
| dense explainer | SCC + Beat Cards |
| product demo | GSP + VLAC + labels |
| emotional story | low-density ASC + DLC |
| screen recording | cursor-safe labels + step cards |
| fitness/cooking | Action-Safe Labels + MRR |
| muted-heavy content | MFC + DLC + SCC/BCC+ |
