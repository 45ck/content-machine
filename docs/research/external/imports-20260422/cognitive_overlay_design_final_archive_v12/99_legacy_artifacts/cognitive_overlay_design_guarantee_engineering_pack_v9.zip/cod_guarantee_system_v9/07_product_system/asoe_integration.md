# ASOE Integration

The Adaptive Semantic Overlay Engine should use the Work Guarantee Engine as its control layer.

## ASOE generates

- semantic beats,
- SCC/BCC/BCC+ variants,
- placement suggestions,
- timing offsets,
- motion options,
- export assets.

## WGE decides

- what counts as success,
- which variants are safe to test,
- which variant wins,
- what to change if it fails.

## Mature system

A mature system does not merely generate captions. It builds and tests a hypothesis for each overlay.
