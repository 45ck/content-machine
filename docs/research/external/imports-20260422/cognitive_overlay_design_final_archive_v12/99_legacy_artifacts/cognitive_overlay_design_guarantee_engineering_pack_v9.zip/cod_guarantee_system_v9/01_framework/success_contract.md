# Success Contract

Before claiming that a method “works,” define the success target.

## Primary success metrics

Use at least one comprehension metric and one platform metric.

### Comprehension metrics

- **Gist recall**: viewer can state the main idea.
- **Action recall**: viewer can state what to do next.
- **Contrast recall**: viewer remembers the reframe, such as “not motivation, structure.”
- **Muted comprehension**: viewer understands without sound.
- **Perceived effort**: viewer reports the content was easy to follow.

### Platform metrics

- 1-second hold
- 3-second hold
- average watch time
- completion rate
- rewatch rate
- saves
- shares
- comments indicating confusion

## Practical significance thresholds

A method passes only if the result is meaningfully useful, not merely statistically detectable.

Suggested pilot thresholds:

- Gist recall: +10 percentage points over baseline, or at least 75% correct.
- Action recall: +10 percentage points over baseline, or at least 65% correct.
- Perceived effort: no worse than baseline and ideally 10% lower.
- Completion rate: +5–10% over baseline.
- No significant drop in visual recall.
- No increase in confusion comments.

## Shipping rule

A method ships only if:

1. It improves the primary metric.
2. It does not damage the safety/accessibility metric.
3. The improvement is practically meaningful.
4. It is replicable across at least two videos or one clear content segment.

## If nothing beats baseline

Then the system still succeeds by preventing a bad rollout. The default remains the best verified baseline, usually NCO, FTO, SCC, or DLC depending on context.
