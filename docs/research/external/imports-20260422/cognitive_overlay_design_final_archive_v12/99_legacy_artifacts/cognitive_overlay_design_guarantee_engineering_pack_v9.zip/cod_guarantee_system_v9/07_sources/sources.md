# Sources Used for This Guarantee Strategy

This pack relies on the project’s existing evidence base plus these validation and optimization references.

## Experimentation and testing

- Nielsen Norman Group, “A/B Testing 101” — A/B testing compares design variations against predetermined success metrics and has limitations, especially low traffic, multiple simultaneous changes, and lack of causal “why” explanation.  
  https://www.nngroup.com/articles/ab-testing/

- Nielsen Norman Group, “Statistical Significance Isn’t the Same as Practical Significance” — statistical reliability is not enough; practical effect size matters for real-world decisions.  
  https://www.nngroup.com/articles/practical-significance/

- Optimizely, “What is a multi-armed bandit?” — explains exploration, exploitation, multi-armed bandits, and contextual bandits for adaptive allocation.  
  https://www.optimizely.com/optimization-glossary/multi-armed-bandit/

## Platform production constraints

- TikTok Business Help Center, “Creative best practices for performance ads” — recommends continuous testing/learning, vertical 9:16, UI safe zones, and TikTok-native creative.  
  https://ads.tiktok.com/help/article/creative-best-practices

## Metrics framework

- Google Research, “Measuring the User Experience on a Large Scale” — HEART framework: Happiness, Engagement, Adoption, Retention, and Task Success.  
  https://research.google.com/pubs/archive/36299.pdf

## Existing COD/BCC project sources

See the previous master archive for sources on:

- subtitle speed;
- partial synchronized captions;
- keyword highlighting;
- multimedia signaling;
- redundancy and cognitive load;
- foveal/peripheral vision;
- visual crowding;
- meaning maps;
- video saliency prediction;
- Bionic Reading limitations;
- caption accessibility guidelines.
