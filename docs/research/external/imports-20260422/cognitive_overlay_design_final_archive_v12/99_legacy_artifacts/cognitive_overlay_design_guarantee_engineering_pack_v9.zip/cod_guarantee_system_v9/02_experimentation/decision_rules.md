# Decision Rules

## Rule 1 — Do not adopt BCC unless it beats SCC

If:

> BCC ≤ SCC on gist recall, action recall, and perceived effort

Then:

> Bionic anchors are optional styling, not a core method.

## Rule 2 — If BCC+ beats BCC, prioritize placement/adaptation

If:

> BCC+ > BCC

Then:

> the advantage is likely gaze-safe placement, visual-load adaptation, muted-first design, or timing — not the bionic component alone.

## Rule 3 — If HBC performs poorly, ban heavy bionic styling

If:

> Heavy Bionic Control increases effort, reduces recall, or lowers completion

Then:

> do not use whole-sentence bionic formatting.

## Rule 4 — If muted comprehension fails, add semantic context

If viewers cannot understand muted:

- add one clarifying word;
- use SCC instead of keyword-only;
- add DLC full captions;
- use Hook → Problem → Fix structure.

## Rule 5 — If visual recall drops, reduce overlay demand

If viewers miss the action, face, product, or demo:

- use GSP;
- reduce word count;
- switch to object labels;
- add micro-rest rhythm;
- move text away from action zones.

## Rule 6 — If platform retention improves but comprehension drops, do not call it success

Retention alone can reward confusion, suspense, or manipulation. COD success requires comprehension, not just watch time.
