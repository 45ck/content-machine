# Quality Gate Framework — QGF

The Quality Gate Framework prevents bad variants from entering tests.

## Gate order

1. **SQG** — Semantic Quality Gate
2. **RLG** — Readability Load Gate
3. **GCG** — Gaze Conflict Gate
4. **VLG** — Visual Load Gate
5. **MFG** — Muted-First Gate
6. **ACG** — Accessibility Caption Gate
7. **CTG** — Contrast Gate
8. **MTG** — Motion Tolerance Gate
9. **ETH** — Ethical Retention Gate

## No-ship rule

A variant that fails semantic, accessibility, or gaze-conflict gates cannot be published as a test candidate.

## Key rule

Do not test garbage. Testing weak overlays wastes traffic and produces noisy conclusions.

See `quality_gates.csv` for pass/fail conditions.
