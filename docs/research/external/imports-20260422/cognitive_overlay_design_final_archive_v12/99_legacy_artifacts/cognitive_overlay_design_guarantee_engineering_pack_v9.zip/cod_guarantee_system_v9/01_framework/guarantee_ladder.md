# Guarantee Ladder

Use this ladder to state exactly what level of guarantee is being claimed.

| Level | Name | Meaning | Claim allowed |
|---:|---|---|---|
| G0 | Impossible Guarantee | Universal performance across every video and audience | Do not claim |
| G1 | Technical Guarantee | Captions render, are readable, export correctly | Safe after QA |
| G2 | Accessibility Guarantee | Full captions exist; overlay does not replace access layer | Safe after audit |
| G3 | Local Comprehension Guarantee | Pilot viewers pass gist/action thresholds | Safe for tested content |
| G4 | Comparative Performance Guarantee | Variant beats baseline by practical margin | Safe for tested segment |
| G5 | Deployment Non-Regress Guarantee | Only verified winners ship; fallback used otherwise | Safe if gates are enforced |
| G6 | Adaptive Optimization Guarantee | System keeps exploring and routing variants by context | Safe as process claim |

## Correct phrasing

Use:

> This system is guaranteed not to make BCC the default unless BCC beats the baseline.

Do not use:

> BCC is guaranteed to make every video perform better.
