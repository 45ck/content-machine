# Contextual Routing

The system should choose methods by context.

## Routing table

| Context signal | Use | Avoid |
|---|---|---|
| clean talking head | SCC, BCC, PSP | excessive motion |
| dense educational content | SCC, Beat Cards, MRR | keyword-only captions |
| busy product demo | VLAC, object labels, GSP | full transcript overlay |
| cooking/fitness action | action labels, micro-rests | mouth/hand obstruction |
| emotional story | low-density captions, ASC | heavy bionic styling |
| muted viewing | MFC, DLC, SCC/BCC+ | keyword-only cryptic labels |
| L2 audience | simplified SCC, full captions | over-compressed shorthand |
| expert audience | compact SCC/BCC | over-explained captions |
| fast cuts | stable text zones | captions changing every cut |
| high UI conflict | safe-zone templates | bottom-fixed captions |

## Decision tree

```text
If the viewer must understand without sound:
    Use MFC + DLC + SCC/BCC+.
Else if the frame is visually busy:
    Use VLAC + GSP + object/action labels.
Else if the content is conceptual:
    Use SCC, BCC, or BCC+.
Else if the content is emotional:
    Use low-density ASC and protect the face.
Else:
    Use SCC baseline and test.
```
