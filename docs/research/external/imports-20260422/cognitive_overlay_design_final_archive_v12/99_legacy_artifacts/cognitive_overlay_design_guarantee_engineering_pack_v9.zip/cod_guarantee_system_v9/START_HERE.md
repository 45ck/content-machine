# Start Here

The next phase is not more loose brainstorming. It is building a system that makes failure productive.

## The guarantee model

The system does not guarantee that BCC, BCC+, or any single style wins every time.

It guarantees that:

1. every overlay has a defined purpose,
2. every overlay is compared to a baseline,
3. failure is diagnosed into a named failure mode,
4. a replacement method is selected from the fallback ladder,
5. only validated variants are promoted.

## Use this order

1. Define the target metric for the video.
2. Choose the baseline.
3. Generate SCC, BCC, and BCC+ variants.
4. Run the preflight gates.
5. Publish only variants that pass quality gates.
6. Test with sequential or fixed-horizon design.
7. Use bandit allocation after the first validation round.
8. Archive each result into the method registry.

## The central rule

> We cannot force a viewer to respond. We can engineer a system that refuses to keep bad variants alive.
