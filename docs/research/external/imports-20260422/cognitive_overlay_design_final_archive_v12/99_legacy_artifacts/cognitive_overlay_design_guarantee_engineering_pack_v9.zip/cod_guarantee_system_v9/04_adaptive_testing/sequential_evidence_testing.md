# Sequential Evidence Testing — SET

Sequential testing exists because creators will be tempted to check results early.

Naive peeking can produce false winners. The safer approach is to predefine either:

1. a fixed-horizon test, or
2. a sequential/always-valid testing method.

## SET rule

If you check results during the test and make decisions before the planned end, use a sequential method or treat results as directional only.

## Minimum rules

- Predeclare primary metric.
- Predeclare minimum exposure or sample size.
- Predeclare stop rules.
- Do not stop only because the current favorite looks good.
- Preserve guardrails.
- Archive negative results.

## Interpretation

SET supports the guarantee by preventing false certainty.
