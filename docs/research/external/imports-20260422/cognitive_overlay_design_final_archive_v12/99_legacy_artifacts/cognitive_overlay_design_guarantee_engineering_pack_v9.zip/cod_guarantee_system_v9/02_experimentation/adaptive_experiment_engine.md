# Adaptive Experiment Engine

The way to make this robust is to stop choosing one “best” caption system globally.

Instead, use adaptive allocation.

## Fixed A/B testing

Best for clean causal answers:

- Does SCC beat FTO?
- Does BCC beat SCC?
- Does BCC+ beat BCC?

Weakness: fixed A/B tests spend traffic on weak variants until the test ends.

## Multi-armed bandit testing

Best for continuous optimization:

- many variants;
- short content life cycles;
- changing audience behavior;
- rapid creative iteration.

Bandits balance exploration and exploitation. They keep trying alternatives while moving more traffic toward better performers.

## Contextual bandit routing

Use context to select overlay styles:

| Context | Likely route |
|---|---|
| Talking head, clean frame | SCC, BCC, PSP |
| Busy demo | VLAC, object labels, GSP |
| Muted viewing likely | DLC + MFC + SCC/BCC+ |
| Emotional story | ASC + low-density captions |
| Screen recording | cursor-safe labels + step cards |
| High visual load | MRR + one-word labels |
| Educational content | SCC/BCC+ + beat cards |

## Core algorithm

```text
For each video:
  Generate candidate overlays.
  Score each for readability, accessibility, placement, and load.
  Reject variants that fail guardrails.
  Publish/test top variants.
  Measure comprehension and platform metrics.
  Route future videos by context to the best verified variant.
  Continue small exploration allocation to detect better variants.
```

## Key rule

> The system is guaranteed to keep learning. Individual variants are not guaranteed to win.
