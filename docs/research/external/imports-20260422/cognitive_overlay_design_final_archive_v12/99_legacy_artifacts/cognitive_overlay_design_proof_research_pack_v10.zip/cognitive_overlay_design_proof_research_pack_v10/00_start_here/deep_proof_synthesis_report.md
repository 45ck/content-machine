# Deep Proof Synthesis Report

## 1. The proof cannot rest on Bionic Reading

Bionic Reading is not the foundation. The strongest available Bionic Reading studies do not show reliable reading-speed or comprehension improvements. Therefore, BCC should be tested as a sparse cueing variant of semantic compression, not as a speed-reading method.

## 2. The proof should rest on constraints

The short-form overlay system is constrained by:

- caption speed limits,
- visual-channel overload,
- foveal/peripheral reading limits,
- visual crowding,
- small visual working memory,
- gaze attraction of subtitles,
- semantic attention,
- screen fatigue,
- muted viewing,
- platform UI clutter,
- accessibility requirements.

A method works when it respects more of these constraints than the baseline.

## 3. The theoretical proof chain

1. Short-form viewing has high visual load.
2. Sound-off viewing increases reliance on subtitles and raises cognitive load.
3. Faster subtitles can reduce complete reading and comprehension.
4. Partial captioning can preserve comprehension with less text in some contexts.
5. Signaling improves retention/transfer and can reduce cognitive load.
6. Meaning guides attention beyond low-level salience.
7. Crowding and working-memory limits punish dense/cluttered overlays.
8. Therefore, compressed semantic overlays with sparse cues, safe placement, and adaptive density should outperform full transcript or noisy overlays for gist/action recall in dense short-form content.

This is not yet universal empirical proof. It is a strong mechanistic prediction.

## 4. The empirical proof chain

To prove each method:

1. Define baseline.
2. Define exact outcome.
3. Randomize exposure.
4. Measure comprehension, effort, and visual recall.
5. Add eye/gaze metrics if possible.
6. Segment by content type and viewing mode.
7. Reject methods that improve watch time but reduce comprehension.

## 5. The most important proof sequence

1. **FTO vs SCC** — proves compression.
2. **SCC vs BCC** — proves or rejects bionic anchors.
3. **BCC vs BCC+** — proves placement/load adaptation.
4. **BCC vs HBC** — proves sparse anchors over heavy bionics.
5. **Sync vs PSP** — proves timing advantage.
6. **Fixed vs VLAC** — proves adaptive density.
7. **Bottom vs GSP** — proves gaze-safe placement.

## 6. Expected result

The likely winner is not BCC alone. The likely winner is:

> Semantic Compression + Signaling + Gaze-Safe Placement + Visual-Load Adaptation + Muted-First Dual Layer Captions.

In registry language:

> **SCC + OFC/PCF + GSP + VLAC + MFC + DLC**

BCC may be retained if sparse concept anchors add measurable value beyond SCC.

## 7. Boundary conditions

BCC/BCC+ is likely strongest for:

- productivity/advice,
- educational explainers,
- finance/business,
- study/learning,
- tutorials with clear steps,
- mental models.

It is likely weaker for:

- music lyrics,
- comedy punchlines where pre-cueing spoils surprise,
- emotional storytelling where compression removes nuance,
- legal/medical content requiring exact wording,
- DHH accessibility if used without full captions.

## 8. Conclusion

The proof strategy is not to guarantee one style. The proof strategy is to build an adaptive method portfolio and prove each component under the condition where its mechanism should operate.

That is stronger than a guarantee. It becomes a falsifiable, measurable, improving system.
