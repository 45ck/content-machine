# Field 4 — Attention, Saliency, Meaning Maps, and Gaze

## Core finding
Attention is not driven only by brightness, contrast, and motion. Semantic meaning guides gaze in real-world scenes, and modern video-saliency prediction can estimate where viewers are likely to look.

## Proof implication
Overlay placement should optimize semantic usefulness and avoid conflict with meaningful visual regions.

## Derived methods
- **GSP** — Gaze-Safe Placement
- **MGO** — Meaning-Guided Overlaying
- **SSA** — Semantic-Saliency Alignment
- **SAOP** — Saliency-Aware Overlay Placement

## Design rule
Do not ask “where can the text fit?” Ask “where can the text add meaning without stealing critical gaze?”

## Failure mode
Visually loud overlays may increase watch time while reducing visual recall and comprehension.

## Sources
S06, S12, S13, S17
