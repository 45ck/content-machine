# Measurement and Analysis Plan

## Primary outcomes

1. **Gist recall** — Did the viewer understand the main point?
2. **Action recall** — Does the viewer know what to do next?
3. **Contrast recall** — Did the viewer remember the reframe, e.g., Not X → Y?
4. **Visual recall** — Did the overlay steal too much attention from the scene?
5. **Perceived effort** — Did the video feel easy or hard to follow?
6. **Completion / 3-second hold** — Did the viewer stay long enough?

## Secondary outcomes

- Exact recall
- Delayed recall
- Saves/shares/comments
- Confusion comments
- Accessibility pass/fail
- Tone recognition for emotional clips

## Mechanistic outcomes

- Text dwell time
- Face/object dwell time
- Number of fixations on text
- Saccades between text and face/object
- Caption skipping
- Regressions/revisits
- Pupil dilation if available

## Practical proof threshold

A method should be called “proven for a segment” only if it:

1. Beats the baseline on the primary target outcome.
2. Does not fail accessibility.
3. Does not reduce gist/action recall.
4. Clears a practical effect threshold, not just statistical significance.
5. Has a known boundary condition.

## Recommended statistical structure

- Within-subject randomized design for controlled study.
- Mixed-effects model with participant and video as random effects.
- Pre-registered primary comparisons.
- Report effect sizes and confidence/credible intervals.
- Segment analysis by content type and viewing mode.

## Decision rules

| Result | Decision |
|---|---|
| SCC beats FTO | Keep semantic compression as core. |
| BCC beats SCC | Keep bionic anchors as a core component. |
| BCC does not beat SCC | Treat bionic anchors as optional style. |
| BCC+ beats BCC | Prioritize placement/load/timing system. |
| HBC underperforms BCC | Reject heavy bionics. |
| VLAC wins only in busy frames | Route by frame complexity. |
| PSP wins in education but fails jokes | Segment by content genre. |
