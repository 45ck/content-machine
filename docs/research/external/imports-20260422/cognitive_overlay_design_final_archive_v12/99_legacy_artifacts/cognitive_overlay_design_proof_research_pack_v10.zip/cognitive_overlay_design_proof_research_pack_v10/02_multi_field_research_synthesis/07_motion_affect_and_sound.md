# Field 7 — Motion, Kinetic Typography, Affective Captions, and Sound

## Core finding
Motion can guide attention but can also overload. Affective captions can encode emotion and tone via typography, color, size, and animation.

## Proof implication
Motion should encode logic, transition, or emotional force—not every word.

## Derived methods
- **LMO** — Logic Motion
- **KCF** — Kinetic Contrast Flip
- **MSL** — Motion Silence
- **ASC** — Affective-Semantic Captions
- **PWE** — Prosody-Weighted Emphasis

## Design rule
If all text moves, movement stops being meaningful.

## Failure mode
Karaoke, bouncing, flashing, and constant word pops can increase visual load and harm accessibility.

## Sources
S14, S15, S27
