# Field 5 — Multimedia Learning, Signaling, Redundancy, Segmenting

## Core finding
Signaling can improve retention and transfer and reduce cognitive load. Redundant text can help or harm depending on whether it reduces or increases load.

## Proof implication
BCC/BCC+ should signal structure, not decorate transcript words.

## Derived methods
- **OFC** — Operator-First Captioning
- **PCF** — Problem-Cause-Fix Cards
- **SMC** — Semantic Map Captions
- **RDM** — Redundancy Discipline Mode

## Design rule
Every overlay must answer one of these: What is the problem? Cause? Contrast? Mechanism? Action? Payoff?

## Failure mode
Full transcript overlays often duplicate audio rather than transforming it into a useful visual model.

## Sources
S10, S11
