# Field 3 — Visual Physiology, Reading, Fovea, Crowding, Working Memory

## Core finding
Text is read with foveal and parafoveal resources; peripheral detail recognition is limited, visual crowding impairs recognition, and visual working memory is small.

## Proof implication
Short-form overlays must minimize long text, avoid clutter, avoid peripheral sentences, and chunk ideas into semantic beats.

## Derived methods
- **FPA** — Foveal Phrase Anchoring
- **PCC** — Peripheral Cue Coding
- **CAC** — Crowding-Aware Captioning
- **VWM-Beat** — Visual Working Memory Beat Cards

## Design rule
Readable phrases belong in foveal zones. Peripheral areas should use arrows, icons, progress markers, or one-word labels—not sentence captions.

## Failure mode
Dense caption blocks near UI/stickers/background motion increase crowding and split attention.

## Sources
S07, S08, S09, S19, S20
