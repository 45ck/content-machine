# Field 2 — Subtitle Speed, Reduction, and Partial Captions

## Core finding
Subtitle speed affects word skipping, rereading, and comprehension. Partial synchronized captioning demonstrates that comprehension can sometimes be preserved with far less than the full transcript.

## Proof implication
The fundamental proof target is not faster reading. It is lower required reading.

## Derived methods
- **SCC** — Semantic Compression Captions
- **PSC-like overlays** — Partial transcript overlays
- **KWC** — Keyword-only captions
- **FTO** — Full Transcript Overlay baseline

## Testable theorem
If a full transcript exceeds viewer processing capacity, then an accurately compressed semantic caption should improve gist/action recall while reducing perceived effort.

## Failure mode
Compression can destroy nuance, especially for legal, medical, emotional, or second-language contexts.

## Sources
S01, S02, S03, S25
