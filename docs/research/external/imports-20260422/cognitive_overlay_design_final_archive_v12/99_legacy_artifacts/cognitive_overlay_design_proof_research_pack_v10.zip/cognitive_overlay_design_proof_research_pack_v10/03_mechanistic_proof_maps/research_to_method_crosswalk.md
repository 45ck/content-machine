# Research-to-Method Crosswalk

| Source IDs | Research field | Method implications |
|---|---|---|
| S01 | Sound-off viewing | MFC, DLC, SCC/BCC+ for muted comprehension |
| S02,S03 | Subtitle speed / partial captions | SCC, reduced word load, avoid full transcripts when overloaded |
| S04,S05 | Bionic Reading | Test BCC against SCC; avoid heavy bionics |
| S06,S17 | Meaning maps / video saliency | MGO, SAOP, GSP, ASOE placement |
| S07,S08 | Visual crowding | CAC, UI-safe zones, plates, lower density |
| S09 | Visual working memory | Semantic beats, PCF cards, 3-7 word rule |
| S10,S11 | Signaling / redundancy | OFC, PCF, RDM, structure-first captions |
| S12,S13 | Dynamic subtitles | GSP, dynamic/object-near placement |
| S14,S15 | Motion / affective captions | LMO, ASC, low-motion controls |
| S16 | Rapid phrase structure | At-a-glance phrase design, PSP, OFC |
| S18 | Visual speech | MSC, mouth-safe routing |
| S19,S20 | Eye strain / mobile viewing | MRR, sparse large text, mobile-safe previews |
| S21-S23 | Short-form attention environment | HCR, FPR, ERF, adaptive routing |
| S24-S27 | Accessibility standards | DLC, accessibility gate, contrast and readable timing |
