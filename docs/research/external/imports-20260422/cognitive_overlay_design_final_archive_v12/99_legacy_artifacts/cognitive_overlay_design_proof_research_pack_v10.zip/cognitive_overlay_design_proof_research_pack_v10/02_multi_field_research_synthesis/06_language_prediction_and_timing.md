# Field 6 — Language Prediction and Timing

## Core finding
Visual language can be processed rapidly at the phrase-structure level. Captions can be timed as pre-cues, synchronous cues, or post-cues.

## Proof implication
A semantic overlay may work best when it appears slightly before the relevant spoken idea, allowing viewers to process the sentence as confirmation.

## Derived methods
- **PSP** — Predictive Semantic Priming
- **SBO** — Semantic Beat Onset
- **PCC-T** — Pre-Cue / Confirm Timing
- **LMS** — Last-frame Memory Stamp

## Timing test
Compare captions at -400 ms, -200 ms, 0 ms, +200 ms, +400 ms from the semantic beat.

## Failure mode
Pre-cues that appear too early can feel like spoilers or mismatch the audio.

## Sources
S16, S02
