# Mechanistic Proof Map

This map connects research fields to concrete proof targets.

| Mechanism | Research basis | Method family | Expected outcome | Main metric |
|---|---|---|---|---|
| Lower reading load | Subtitle speed, PSC | SCC, BCC | Higher gist/action recall, lower effort | Gist recall, effort |
| Sparse semantic cueing | Signaling, keyword highlighting | BCC, OFC, PCF | Higher contrast/action recall | Contrast recall |
| Gaze conflict reduction | Dynamic subtitles, saliency, mouth cues | BCC+, GSP, MSC | Better visual recall, lower split attention | Visual recall, text dwell |
| Crowding reduction | Visual crowding | CAC, VLAC | Improved readability in busy frames | Reading accuracy, effort |
| Adaptive density | Redundancy/working memory | VLAC | Better performance across mixed scenes | Visual recall + gist |
| Predictive priming | Phrase structure / timing | PSP | Faster orientation, better 3-sec hold | Early comprehension |
| Motion as logic | Kinetic typography | LMO, KCF | Better sequence recall | Sequence recall |
| Emotional encoding | Affective captions | ASC | Better tone recognition | Tone recall/ratings |
| Muted-first support | Sound-off subtitle research | MFC, DLC | Better muted comprehension | Muted gist/action recall |
| Accessibility preservation | W3C/Section 508/WCAG | DLC, A11Y-Gate | No access regression | Accessibility pass/fail |

## Mechanistic proof pattern

For each method, prove three things:

1. **Causal effect:** Does the method beat the baseline?
2. **Mechanism:** Do eye/load metrics move in the predicted direction?
3. **Boundary:** Where does it fail?

Example for BCC+:

- Causal: BCC+ beats BCC in gist/action recall or visual recall.
- Mechanistic: lower text dwell, fewer text-face saccades, less perceived effort.
- Boundary: BCC+ may fail on emotional storytelling if compression removes nuance.
