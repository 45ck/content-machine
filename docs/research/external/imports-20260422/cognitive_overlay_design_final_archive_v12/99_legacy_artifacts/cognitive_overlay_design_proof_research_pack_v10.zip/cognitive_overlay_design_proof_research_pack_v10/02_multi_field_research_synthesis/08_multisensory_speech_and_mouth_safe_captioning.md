# Field 8 — Multisensory Speech Perception

## Core finding
Seeing a speaker’s articulatory movements can improve speech understanding, especially in noisy environments.

## Proof implication
Text overlays should avoid covering the mouth in speech-heavy content and avoid eyes in emotional content.

## Derived methods
- **MSC** — Mouth-Safe Captioning
- **ESC** — Eye-Safe Captioning
- **ASC2** — Action-Safe Captioning

## Design rule
Protect the region that carries the information: mouth for speech, eyes for emotion, hands/object for demos.

## Failure mode
Overlay text can block the very cues viewers need to understand the audio or emotion.

## Sources
S18
