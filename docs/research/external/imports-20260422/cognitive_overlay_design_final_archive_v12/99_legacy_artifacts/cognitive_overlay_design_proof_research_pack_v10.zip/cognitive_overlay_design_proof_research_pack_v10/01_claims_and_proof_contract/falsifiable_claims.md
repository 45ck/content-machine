# Falsifiable Claims

## Claim A — Compression beats transcript for gist

**Hypothesis:** SCC improves gist and action recall compared with full transcript overlays in dense short-form advice/education videos.

**Mechanism:** Lower word count reduces subtitle-speed pressure and visual-channel load.

**Baselines:** FTO, KHT, NCO.

**Fails if:** FTO performs equal or better on gist/action recall while having no higher perceived effort.

---

## Claim B — BCC beats SCC only if bionic anchors add measurable value

**Hypothesis:** BCC improves memory, subjective clarity, or first-fixation orientation compared with SCC.

**Mechanism:** Sparse partial-word concept anchors create visual cueing without heavy bionic noise.

**Fails if:** BCC is not better than SCC, or if it increases saccades/perceived effort.

---

## Claim C — BCC+ beats BCC by reducing gaze conflict

**Hypothesis:** BCC+ improves visual recall and perceived ease compared with BCC by avoiding mouth, eyes, hands, product, UI, and cluttered zones.

**Mechanism:** Placement and adaptive density reduce split attention and crowding.

**Fails if:** BCC+ does not improve visual recall/text dwell/effort versus BCC.

---

## Claim D — Predictive Semantic Priming improves early comprehension

**Hypothesis:** Showing a semantic beat 200–400 ms before the speech lands improves orientation and gist recall versus post-cue overlays.

**Mechanism:** The viewer receives a semantic frame before processing speech, reducing prediction load.

**Fails if:** Pre-cueing increases perceived mismatch or lowers comprehension.

---

## Claim E — Visual-load adaptation beats fixed captions

**Hypothesis:** VLAC improves comprehension and visual recall when frame complexity varies.

**Mechanism:** Busy frames need labels/icons; simple frames can support more text.

**Fails if:** fixed-density overlays perform equally or better across high-load frames.
