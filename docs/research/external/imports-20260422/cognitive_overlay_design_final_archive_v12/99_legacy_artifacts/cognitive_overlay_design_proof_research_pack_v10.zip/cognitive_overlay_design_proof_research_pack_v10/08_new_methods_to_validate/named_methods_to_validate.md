# New Methods to Validate

These are named methods or method components that can be added to the registry.

## Semantic / Structure

- **SCC** — Semantic Compression Captions: speech rewritten as compact meaning.
- **OFC** — Operator-First Captioning: logic operators first, e.g., Not X → Y.
- **PCF** — Problem-Cause-Fix Cards: structure the clip as problem, cause, fix.
- **MOS** — Memory Object Stamp: final memorable phrase designed for recall.
- **QRC** — Quick Retrieval Caption: prompt the viewer to retrieve the rule or action.

## Typography / Anchors

- **BCC** — Bionic Compression Captioning: SCC + partial concept anchors.
- **FWOA** — Full-Word Operator Anchors: bold full logic words, not partial words.
- **SAD** — Sparse Anchor Density: 1-3 anchors per beat.
- **SBR** — Semantic Break Rendering: line breaks by phrase structure.

## Placement / Gaze

- **GSP** — Gaze-Safe Placement: avoid mouth, eyes, hands, product, UI.
- **MSC** — Mouth-Safe Captioning: keep mouth clear in speech-heavy videos.
- **ASC2** — Action-Safe Captioning: keep hands/body/product action clear.
- **SAOP** — Saliency-Aware Overlay Placement: place text using saliency/conflict prediction.
- **CAC** — Crowding-Aware Captioning: avoid clutter or add plates.

## Timing / Rhythm

- **PSP** — Predictive Semantic Priming: show semantic beat slightly before speech.
- **SBO** — Semantic Beat Onset: captions timed to idea transitions, not every word.
- **MRR** — Micro-Rest Rhythm: no-text gaps between text beats.
- **LMS** — Last-frame Memory Stamp: short final recall phrase.

## Motion / Emotion

- **LMO** — Logic Motion: motion reflects argument structure.
- **KCF** — Kinetic Contrast Flip: motion reveals Not X → Y contrast.
- **MSL** — Motion Silence: important captions stay static amid noisy visuals.
- **ASC** — Affective-Semantic Captions: encode tone plus meaning.
- **PWE** — Prosody-Weighted Emphasis: visual emphasis follows speech emphasis.

## Adaptive / Systems

- **BCC+** — Bionic Compression Captioning Plus: BCC + placement/load/timing/muted-first controls.
- **VLAC** — Visual-Load Adaptive Captioning: word count changes with frame complexity.
- **DLC** — Dual-Layer Captioning: full captions + semantic overlay.
- **MFC** — Muted-First Captioning: overlay works without audio.
- **ASOE** — Adaptive Semantic Overlay Engine: automated system that routes methods by context.
- **ERF** — Ethical Retention Filter: rejects variants that increase watch time by reducing comprehension.
