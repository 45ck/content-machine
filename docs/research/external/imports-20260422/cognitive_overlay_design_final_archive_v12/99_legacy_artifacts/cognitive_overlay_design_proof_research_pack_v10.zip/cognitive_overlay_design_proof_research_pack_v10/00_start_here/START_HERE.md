# Cognitive Overlay Design — Proof Research Pack v10

This pack reframes “proof” correctly:

- **Not** a universal promise that one caption style wins on every video.
- **Yes** a multi-field proof program that can demonstrate which named method works, for which context, against which baseline, under which metric.

The central proof target is:

> A method works if it causally improves a predefined outcome over the relevant baseline without failing accessibility, comprehension, or visual-load guardrails.

Core methods:

- **SCC** — Semantic Compression Captions
- **BCC** — Bionic Compression Captioning
- **BCC+** — BCC plus gaze-safe placement, adaptive density, muted-first design, and full captions
- **GSP** — Gaze-Safe Placement
- **VLAC** — Visual-Load Adaptive Captioning
- **PSP** — Predictive Semantic Priming
- **MRR** — Micro-Rest Rhythm
- **DLC** — Dual-Layer Captioning
- **ASOE** — Adaptive Semantic Overlay Engine

The proof thesis:

> Short-form overlay performance can be improved by reducing required reading, making semantic structure visible, protecting gaze-critical regions, adapting to visual load, and preserving full accessibility captions.

The weakest component is pure Bionic Reading. The strongest components are semantic compression, signaling, placement, visual-load adaptation, and timing.
