# Source Index

## S01 — Sound-off subtitled viewing
- **Source:** Szarkowska et al. 2024, PLOS ONE
- **Finding used:** Sound-off viewing increased cognitive load and reduced comprehension/immersion/enjoyment; gaze showed viewers processed subtitles more heavily.
- **URL:** https://journals.plos.org/plosone/article?id=10.1371%2Fjournal.pone.0306251

## S02 — Subtitle speed and word skipping
- **Source:** Kruger et al. 2022, Applied Psycholinguistics
- **Finding used:** Subtitle speed affects word skipping/rereading; faster subtitles can reduce comprehension and complete reading.
- **URL:** https://www.cambridge.org/core/journals/applied-psycholinguistics/article/why-subtitle-speed-matters-evidence-from-word-skipping-and-rereading/A7DB0CBF5910353143738CF9C1721317

## S03 — Partial and Synchronized Captioning
- **Source:** Mirzaei et al. 2017, ReCALL
- **Finding used:** PSC preserved comprehension while showing less than 30% of the transcript in an L2 listening context.
- **URL:** https://www.cambridge.org/core/journals/recall/article/partial-and-synchronized-captioning-a-new-tool-to-assist-learners-in-developing-second-language-listening-skill/9394E3F0AD25FD5F32895F965F7ECCAD

## S04 — Bionic Reading null result
- **Source:** Snell 2024, Acta Psychologica
- **Finding used:** No significant reading-time advantage for Bionic Reading over normal text.
- **URL:** https://www.sciencedirect.com/science/article/pii/S0001691824001811

## S05 — Bionic Reading eye tracking/usability
- **Source:** Sage Open 2025
- **Finding used:** No clear speed/comprehension advantage; bionic formatting produced more saccades in reported analyses.
- **URL:** https://journals.sagepub.com/doi/10.1177/21582440251376158

## S06 — Meaning maps and attention
- **Source:** Henderson et al. 2018, Scientific Reports
- **Finding used:** Meaning maps and semantic relevance guide attention in real-world scenes beyond low-level salience.
- **URL:** https://www.nature.com/articles/s41598-018-31894-5

## S07 — Visual crowding review
- **Source:** Annual Review of Vision Science / crowding literature
- **Finding used:** Crowding impairs perception when objects/letters are surrounded by clutter; relevant to UI/text placement.
- **URL:** https://www.annualreviews.org/content/journals/10.1146/annurev-vision-110423-024409

## S08 — Rapid crowding assessment
- **Source:** Tanriverdi et al. 2024, Frontiers in Neuroscience
- **Finding used:** Human vision is constrained by crowding across recognition, reading, driving, and visual search.
- **URL:** https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2024.1332701/full

## S09 — Visual working memory capacity
- **Source:** Luck & Vogel / Luck 2013
- **Finding used:** Typical simple-object visual working memory capacity is about 3-4 objects.
- **URL:** https://pmc.ncbi.nlm.nih.gov/articles/PMC3729738/

## S10 — Multimedia signaling meta-analysis
- **Source:** Schneider et al. 2018
- **Finding used:** Signaling improves retention/transfer and can reduce cognitive load; affects eye fixations and learning time.
- **URL:** https://www.sciencedirect.com/science/article/abs/pii/S1747938X17300581

## S11 — Redundancy in multimedia learning
- **Source:** Frontiers 2023 review
- **Finding used:** Redundancy can help or harm depending on whether it overloads working memory/channel processing.
- **URL:** https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2023.1148035/full

## S12 — Dynamic subtitles user experience
- **Source:** Brown et al. 2015, ACM TVX
- **Finding used:** Dynamic subtitles can make gaze patterns closer to no-subtitle baselines than traditional subtitles in tested contexts.
- **URL:** https://dl.acm.org/doi/10.1145/2745197.2745204

## S13 — Dynamic subtitle placement / ROI
- **Source:** Akahori et al. 2017
- **Finding used:** Subtitle placement can reduce unnecessary eye movement and avoid overlapping regions of interest.
- **URL:** https://www.scitepress.org/papers/2017/62622/62622.pdf

## S14 — Kinetic typography theory
- **Source:** Lee & Park 2023, Humanities and Social Sciences Communications
- **Finding used:** Moving text may support learning when aligned with logical flow; excessive motion risks fatigue/overload.
- **URL:** https://www.nature.com/articles/s41599-023-01646-6

## S15 — Affective captions
- **Source:** Caption Royale 2024, CHI
- **Finding used:** Affective captions use visual typographic modulation to convey emotion for DHH viewers.
- **URL:** https://dl.acm.org/doi/10.1145/3613904.3642258

## S16 — At-a-glance phrase structure
- **Source:** Fallon et al. 2024, Science Advances
- **Finding used:** Brain responses show rapid detection of basic phrase structure from briefly presented visual language.
- **URL:** https://www.science.org/doi/10.1126/sciadv.adr9951

## S17 — Video saliency prediction / AViMoS
- **Source:** AIM 2024 Challenge / AViMoS
- **Finding used:** Dataset includes 1,500 videos, vertical-video content, audio, and >5,000 observer mouse fixations.
- **URL:** https://github.com/msu-video-group/ECCVW24_Saliency_Prediction

## S18 — Visible speech articulation
- **Source:** Ross et al. 2007, Cerebral Cortex
- **Finding used:** Seeing articulatory movements improves spoken-word understanding, especially in noisy conditions.
- **URL:** https://academic.oup.com/cercor/article/17/5/1147/343892

## S19 — Digital eye strain review
- **Source:** Kaur et al. 2022 review
- **Finding used:** Continuous screen staring reduces blink rate and contributes to dry-eye-related symptoms.
- **URL:** https://pmc.ncbi.nlm.nih.gov/articles/PMC9434525/

## S20 — Smartphone viewing distance/font size
- **Source:** Naipal et al. 2024
- **Finding used:** Non-presbyopic smartphone users often used viewing distances under 40 cm and small font sizes under 1.45 mm.
- **URL:** https://pmc.ncbi.nlm.nih.gov/articles/PMC11629835/

## S21 — Short-form video and attention/cognitive fatigue
- **Source:** Alruwaili 2025, Acta Psychologica
- **Finding used:** Short-form video use and scroll immersion were associated with attention difficulty, working-memory disruption, and cognitive fatigue.
- **URL:** https://www.sciencedirect.com/science/article/pii/S0001691825009874

## S22 — Short-video use and executive control
- **Source:** Yan et al. 2024, Frontiers in Human Neuroscience
- **Finding used:** Higher short-video addiction tendency was associated with reduced self-control/executive control markers.
- **URL:** https://www.frontiersin.org/journals/human-neuroscience/articles/10.3389/fnhum.2024.1383913/full

## S23 — Short-video cues and risk decisions
- **Source:** Zhang et al. 2025, Frontiers in Human Neuroscience
- **Finding used:** Short-video addiction group showed higher risk-taking and heightened sensitivity to short-video cues.
- **URL:** https://www.frontiersin.org/journals/human-neuroscience/articles/10.3389/fnhum.2025.1542271/full

## S24 — W3C captions guide
- **Source:** W3C WAI
- **Finding used:** Captions are synchronized text versions of speech and relevant non-speech audio.
- **URL:** https://www.w3.org/WAI/media/av/captions/

## S25 — Section 508 caption guidance
- **Source:** Section508.gov
- **Finding used:** Guidance includes two-line captions, 45 characters per line, and warning that over 180 wpm may be too fast.
- **URL:** https://www.section508.gov/create/captions-transcripts/

## S26 — WCAG 2.2 contrast
- **Source:** W3C WCAG 2.2
- **Finding used:** Text contrast thresholds including 4.5:1 for normal text and 3:1 for large text under AA.
- **URL:** https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html

## S27 — Accessible social captions
- **Source:** Accessible Social
- **Finding used:** Recommends readable captions, adequate time, avoiding excessive animation/rushing.
- **URL:** https://www.accessible-social.com/audio-and-video/captions
