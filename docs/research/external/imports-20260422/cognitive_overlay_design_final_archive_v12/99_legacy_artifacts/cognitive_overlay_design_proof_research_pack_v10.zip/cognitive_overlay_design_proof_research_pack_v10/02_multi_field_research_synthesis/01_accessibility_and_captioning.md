# Field 1 — Accessibility and Captioning

## Core finding
Captions are not decorative text. They are synchronized text versions of speech and meaningful non-speech audio, especially for Deaf and hard-of-hearing viewers. This means BCC/BCC+ cannot replace full captions.

## Proof implication
Any proof claim must use **Dual-Layer Captioning (DLC)**:

1. Full caption layer for access.
2. Semantic overlay layer for retention/gist.

## Derived methods
- **DLC** — Dual-Layer Captioning
- **MFC** — Muted-First Captions
- **A11Y-Gate** — Accessibility gate before publishing

## Failure mode
If BCC is used as the only caption layer, it can improve style while reducing accessibility. That is a failed method, even if watch time improves.

## Sources
S24, S25, S26, S27
