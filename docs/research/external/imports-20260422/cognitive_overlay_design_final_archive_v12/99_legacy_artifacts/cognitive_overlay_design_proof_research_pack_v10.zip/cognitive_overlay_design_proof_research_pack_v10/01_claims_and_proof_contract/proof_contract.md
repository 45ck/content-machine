# Proof Contract

## What can be proven

We can prove bounded claims such as:

1. **SCC improves gist recall over full transcript overlays** for dense short-form educational/advice videos.
2. **BCC improves memory or subjective clarity over SCC** only if bionic concept anchors add measurable value after compression.
3. **BCC+ improves visual efficiency over BCC** when placement and visual-load adaptation reduce gaze conflict.
4. **PSP improves comprehension** if pre-cueing semantic beats reduces prediction load without causing mismatch.
5. **VLAC improves performance** when busy frames receive fewer words and simple frames receive richer semantic captions.

## What cannot be honestly proven

- That one visual style works for every creator, viewer, language, and platform context.
- That Bionic Reading alone reliably makes captions faster to read.
- That retention gains are always ethical or comprehension-preserving.

## Required proof levels

| Level | Name | Requirement |
|---:|---|---|
| P0 | Plausibility | Mechanism is supported by adjacent research. |
| P1 | Component proof | Component beats baseline in controlled study. |
| P2 | Mechanistic proof | Eye/gaze/load data supports the proposed mechanism. |
| P3 | Field proof | Platform A/B test shows practical uplift. |
| P4 | Segment proof | Method works by content type/viewer mode, not just globally. |
| P5 | Adaptive proof | System selects the winning method by context and avoids losers. |

## Primary proof metric

> **Meaning retained per second watched.**

Secondary research-grade metric:

> **Meaning retained per fixation.**

## Falsification rule

If a method improves watch time but reduces gist recall, action recall, or accessibility, it is not considered proven. It is attention capture, not comprehension enhancement.
