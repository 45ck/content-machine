# Experiment Blueprints

## Experiment 1 — Core Isolation

**Purpose:** Prove or reject the core method stack.

| Condition | Code | Isolates |
|---|---|---|
| Native captions only | NCO | baseline access mode |
| Full transcript overlay | FTO | transcript duplication |
| Keyword highlight transcript | KHT | sparse transcript emphasis |
| Semantic compression | SCC | compression |
| Bionic compression | BCC | compression + bionic anchors |
| BCC plus | BCC+ | BCC + placement/load/muted-first |
| Heavy bionic | HBC | negative control for over-bionics |

**Primary comparisons:**

1. SCC vs FTO — Does compression beat transcript?
2. BCC vs SCC — Do bionic anchors add value?
3. BCC+ vs BCC — Do placement/load controls add value?
4. BCC vs HBC — Does sparse anchoring beat heavy bionics?

**Primary metrics:** gist recall, action recall, perceived effort, completion.

**Mechanistic metrics:** text dwell time, face/object dwell time, saccades between text and region of interest, skipped captions.

---

## Experiment 2 — Timing Proof

**Purpose:** Prove whether Predictive Semantic Priming works.

Conditions: -400 ms, -200 ms, 0 ms, +200 ms, +400 ms relative to semantic beat.

Metrics: early comprehension, 3-second hold, mismatch rating, gist recall.

Decision rule: keep PSP only if pre-cue improves comprehension without increasing mismatch.

---

## Experiment 3 — Placement Proof

**Purpose:** Prove gaze-safe placement.

Conditions: bottom-fixed, top-center, mouth-safe, object-near, saliency-safe, UI-safe.

Metrics: visual recall, face/object dwell, effort, caption readability.

Decision rule: keep GSP if it improves visual recall or reduces gaze conflict without reducing gist.

---

## Experiment 4 — Visual Load Proof

**Purpose:** Prove adaptive word count.

Conditions: fixed 5-7 words vs adaptive 1-3 words in busy frames / 4-7 words in simple frames.

Metrics: gist, task/action recall, visual recall, effort.

Decision rule: keep VLAC if it wins in busy scenes and does not lose in simple scenes.

---

## Experiment 5 — Motion Proof

**Purpose:** Prove motion-as-logic vs decorative motion.

Conditions: static, soft fade, logic motion, word pop, karaoke, high motion.

Metrics: sequence recall, effort, comfort, completion.

Decision rule: keep motion only when it improves recall or engagement without increasing effort/discomfort.

---

## Experiment 6 — Segment Routing Proof

**Purpose:** Prove no single method should be global default.

Segments: talking head, tutorial/demo, fitness/cooking, emotional story, finance/education, comedy.

Methods: SCC, BCC, BCC+, ASC, VLAC, GSP.

Decision rule: use per-segment winners, not one global winner.
