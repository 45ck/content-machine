# Field 9 — Short-Form Attention and Reward Environment

## Core finding
Short-form video is a rapid selection environment. Research links heavy short-form use and scroll immersion with attention difficulty, working-memory disruption, fatigue, and executive-control concerns.

## Proof implication
The overlay must reduce uncertainty quickly and deliver fast semantic payoff, but it must not optimize for confusion-driven retention.

## Derived methods
- **HCR** — Hook-Clarity Rule
- **RPF** — Resolution-Payoff Framing
- **ERF** — Ethical Retention Filter
- **FPR** — Fast Payoff Rule

## Design rule
First orient, then reward. Do not delay the core meaning for empty suspense.

## Failure mode
A method can increase watch time by confusing viewers; that is not proof of comprehension.

## Sources
S21, S22, S23
