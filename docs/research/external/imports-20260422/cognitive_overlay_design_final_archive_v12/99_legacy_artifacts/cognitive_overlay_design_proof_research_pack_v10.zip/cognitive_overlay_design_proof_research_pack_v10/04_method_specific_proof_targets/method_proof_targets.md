# Method-Specific Proof Targets

## SCC — Semantic Compression Captions
- **Isolates:** Compression only
- **Baseline:** FTO/KHT
- **Metrics:** Gist recall, action recall, effort
- **Proof rule:** If SCC beats FTO on gist/action with lower effort, compression is proven for that content class.

## BCC — Bionic Compression Captioning
- **Isolates:** SCC + bionic concept anchors
- **Baseline:** SCC
- **Metrics:** Recall, subjective clarity, fixation efficiency
- **Proof rule:** If BCC beats SCC without increasing effort/saccades, bionic anchors add value.

## BCC+ — Bionic Compression Captioning Plus
- **Isolates:** BCC + placement/load/muted-first
- **Baseline:** BCC
- **Metrics:** Visual recall, muted comprehension, effort
- **Proof rule:** If BCC+ beats BCC, adaptive placement/density is proven.

## DLC — Dual-Layer Captioning
- **Isolates:** Full captions + semantic overlay
- **Baseline:** Overlay-only
- **Metrics:** Accessibility pass + comprehension
- **Proof rule:** If DLC preserves accessibility while improving retention, dual-layer architecture is validated.

## GSP — Gaze-Safe Placement
- **Isolates:** Avoid face/mouth/hands/object/UI
- **Baseline:** Bottom-fixed placement
- **Metrics:** Visual recall, text dwell, object/face dwell
- **Proof rule:** If GSP improves visual recall or lowers split attention, placement matters.

## VLAC — Visual-Load Adaptive Captioning
- **Isolates:** Fewer words in busy frames
- **Baseline:** Fixed density
- **Metrics:** Gist + visual recall by frame complexity
- **Proof rule:** If VLAC wins on high-load scenes, adaptive density is validated.

## PSP — Predictive Semantic Priming
- **Isolates:** Pre-cue semantic beat
- **Baseline:** Sync/post cue
- **Metrics:** Early orientation, 3-sec hold, gist
- **Proof rule:** If pre-cue improves early comprehension without mismatch, PSP is validated.

## MRR — Micro-Rest Rhythm
- **Isolates:** Brief no-text gaps
- **Baseline:** Continuous text
- **Metrics:** Effort, visual recall, completion
- **Proof rule:** If MRR lowers effort while preserving recall, text-rest cadence works.

## OFC — Operator-First Captioning
- **Isolates:** Not/Stop/Less/First operators first
- **Baseline:** Keyword-only
- **Metrics:** Contrast recall, action recall
- **Proof rule:** If OFC beats keyword-only for reframes, logic-first design works.

## PCF — Problem-Cause-Fix Cards
- **Isolates:** Structured three-beat framework
- **Baseline:** Unstructured captions
- **Metrics:** Sequence recall, action recall
- **Proof rule:** If PCF improves sequence recall, structural signaling works.

## MSC — Mouth-Safe Captioning
- **Isolates:** Avoid covering mouth
- **Baseline:** Mouth-covered captions
- **Metrics:** Speech clarity, face dwell, effort
- **Proof rule:** If MSC improves speech understanding or lowers effort, mouth-safe placement is proven.

## ASC — Affective-Semantic Captions
- **Isolates:** Meaning + tone encoding
- **Baseline:** Neutral captions
- **Metrics:** Tone recognition, engagement, effort
- **Proof rule:** If ASC improves tone recognition without harming gist, affective styling is validated.

## LMO — Logic Motion
- **Isolates:** Motion only for structure
- **Baseline:** Static and decorative motion
- **Metrics:** Sequence recall, effort
- **Proof rule:** If LMO beats decorative motion with lower effort, motion-as-logic is proven.

## CAC — Crowding-Aware Captioning
- **Isolates:** Avoid clutter; add plates/safe zones
- **Baseline:** Cluttered placement
- **Metrics:** Readability, effort, visual recall
- **Proof rule:** If CAC improves readability in cluttered frames, crowding avoidance is validated.

## MFC — Muted-First Captions
- **Isolates:** Overlay communicates without audio
- **Baseline:** Audio-dependent overlay
- **Metrics:** Muted gist/action recall
- **Proof rule:** If MFC beats standard overlays muted, dual-mode design is proven.
