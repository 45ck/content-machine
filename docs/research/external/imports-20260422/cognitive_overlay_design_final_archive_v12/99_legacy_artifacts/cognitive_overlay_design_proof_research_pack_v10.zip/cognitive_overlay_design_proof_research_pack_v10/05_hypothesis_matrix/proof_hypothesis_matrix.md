# Proof Hypothesis Matrix

This file lists 60 hypotheses to prove, reject, or segment.

## H001 — SCC beats FTO for gist
- **Family:** Semantic Compression
- **Claim:** Compressed meaning beats verbatim transcript for gist/action recall in dense videos.
- **Baseline:** FTO
- **Minimum experiment:** Same script, FTO vs SCC, audio-on and muted.
- **Metrics:** gist recall; action recall; effort
- **Evidence grade:** Strong adjacent
- **Sources:** S02,S03,S10
- **Priority:** Critical

## H002 — BCC beats SCC only when anchors help
- **Family:** Typography/Anchors
- **Claim:** Partial concept anchors improve recall or clarity beyond compression.
- **Baseline:** SCC
- **Minimum experiment:** SCC vs BCC.
- **Metrics:** contrast recall; subjective clarity; saccades
- **Evidence grade:** Weak/direct test needed
- **Sources:** S04,S05,S10
- **Priority:** Critical

## H003 — BCC beats heavy bionic
- **Family:** Typography/Anchors
- **Claim:** Sparse anchors outperform heavy bionic formatting.
- **Baseline:** HBC
- **Minimum experiment:** BCC vs HBC.
- **Metrics:** effort; recall; readability
- **Evidence grade:** Moderate adjacent
- **Sources:** S04,S05,S07
- **Priority:** Critical

## H004 — BCC+ beats BCC
- **Family:** Adaptive System
- **Claim:** Placement and density improve performance beyond caption wording.
- **Baseline:** BCC
- **Minimum experiment:** BCC vs BCC+.
- **Metrics:** visual recall; text dwell; effort
- **Evidence grade:** Strong adjacent
- **Sources:** S06,S07,S12,S17
- **Priority:** Critical

## H005 — GSP beats bottom-fixed
- **Family:** Placement/Gaze
- **Claim:** Gaze-safe placement reduces visual conflict.
- **Baseline:** BFP
- **Minimum experiment:** Bottom vs gaze-safe placement.
- **Metrics:** visual recall; face/object dwell
- **Evidence grade:** Moderate
- **Sources:** S12,S13,S17,S18
- **Priority:** High

## H006 — VLAC beats fixed density
- **Family:** Visual Load
- **Claim:** Adaptive density wins across varied visual complexity.
- **Baseline:** Fixed density
- **Minimum experiment:** High/low visual-load videos, fixed vs adaptive.
- **Metrics:** gist; visual recall; effort
- **Evidence grade:** Strong adjacent
- **Sources:** S07,S09,S11
- **Priority:** High

## H007 — PSP beats post-cue
- **Family:** Timing
- **Claim:** Pre-cueing semantic beats improves early orientation.
- **Baseline:** Post-cue
- **Minimum experiment:** Timing offset study -400/-200/0/+200/+400 ms.
- **Metrics:** 3-sec comprehension; gist; mismatch rating
- **Evidence grade:** Moderate/speculative
- **Sources:** S16,S02
- **Priority:** High

## H008 — MRR reduces fatigue
- **Family:** Timing/Rhythm
- **Claim:** No-text micro-rests lower effort without reducing recall.
- **Baseline:** Continuous text
- **Minimum experiment:** Continuous vs micro-rest cadence.
- **Metrics:** effort; visual recall; completion
- **Evidence grade:** Moderate/speculative
- **Sources:** S09,S19,S20
- **Priority:** High

## H009 — OFC beats keyword-only
- **Family:** Semantic Structure
- **Claim:** Operator-first captions improve contrast recall.
- **Baseline:** Keyword-only
- **Minimum experiment:** Not X→Y vs keywords.
- **Metrics:** contrast recall; gist
- **Evidence grade:** Strong adjacent
- **Sources:** S10,S16
- **Priority:** High

## H010 — PCF improves sequence recall
- **Family:** Semantic Structure
- **Claim:** Problem-Cause-Fix cards improve memory of argument structure.
- **Baseline:** Unstructured SCC
- **Minimum experiment:** PCF vs unstructured compressed beats.
- **Metrics:** sequence recall; action recall
- **Evidence grade:** Strong adjacent
- **Sources:** S10,S11
- **Priority:** High

## H011 — MFC improves muted comprehension
- **Family:** Muted Mode
- **Claim:** Muted-first overlays beat audio-dependent overlays when sound is off.
- **Baseline:** Audio-on cue overlay
- **Minimum experiment:** Audio-on vs muted condition.
- **Metrics:** muted gist/action recall
- **Evidence grade:** Strong
- **Sources:** S01,S24
- **Priority:** High

## H012 — DLC preserves accessibility while improving retention
- **Family:** Accessibility
- **Claim:** Full captions plus overlay beats overlay-only and preserves access.
- **Baseline:** Overlay-only
- **Minimum experiment:** DLC vs overlay-only.
- **Metrics:** accessibility pass; comprehension
- **Evidence grade:** Strong
- **Sources:** S24,S25,S26
- **Priority:** High

## H013 — MSC improves speech clarity
- **Family:** Placement/Gaze
- **Claim:** Avoiding mouth improves speech understanding/effort.
- **Baseline:** Mouth-covered captions
- **Minimum experiment:** Mouth-safe vs mouth-covered.
- **Metrics:** speech comprehension; face dwell
- **Evidence grade:** Strong adjacent
- **Sources:** S18
- **Priority:** High

## H014 — ESC improves emotional interpretation
- **Family:** Placement/Gaze
- **Claim:** Avoiding eyes improves emotion/tone perception.
- **Baseline:** Eye-covered captions
- **Minimum experiment:** Eye-safe vs eye-covered in emotional clips.
- **Metrics:** tone recognition; emotion rating
- **Evidence grade:** Moderate adjacent
- **Sources:** S18,S15
- **Priority:** Medium

## H015 — CAC improves readability in clutter
- **Family:** Visual Load
- **Claim:** Crowding-aware placement/plates improve readability.
- **Baseline:** Cluttered placement
- **Minimum experiment:** Plain vs cluttered/background plates.
- **Metrics:** readability; effort; completion
- **Evidence grade:** Strong adjacent
- **Sources:** S07,S08
- **Priority:** High

## H016 — MGO beats salience-only pop
- **Family:** Meaning/Saliency
- **Claim:** Meaning-guided overlays outperform visually loud but shallow overlays.
- **Baseline:** Salience-only pop
- **Minimum experiment:** Meaning-first vs pop-only overlays.
- **Metrics:** gist recall; effort
- **Evidence grade:** Strong adjacent
- **Sources:** S06,S10
- **Priority:** High

## H017 — SSA improves placement
- **Family:** AI/Saliency
- **Claim:** Combining meaning maps and saliency maps improves placement decisions.
- **Baseline:** Saliency-only
- **Minimum experiment:** Human-coded meaning+saliency vs saliency-only placement.
- **Metrics:** visual recall; comprehension
- **Evidence grade:** Moderate/speculative
- **Sources:** S06,S17
- **Priority:** Medium

## H018 — PCC peripheral cues beat peripheral text
- **Family:** Visual Physiology
- **Claim:** Icons/arrows in periphery outperform peripheral sentences.
- **Baseline:** Peripheral text
- **Minimum experiment:** Peripheral text vs peripheral cues.
- **Metrics:** orientation; visual recall
- **Evidence grade:** Strong adjacent
- **Sources:** S07,S08
- **Priority:** Medium

## H019 — FPA improves phrase recognition
- **Family:** Visual Physiology
- **Claim:** Short foveal phrases beat split-word/one-word streams.
- **Baseline:** WDC/RSVP-like
- **Minimum experiment:** Phrase vs word-by-word.
- **Metrics:** gist; effort; exact recall
- **Evidence grade:** Strong adjacent
- **Sources:** S02,S09,S16
- **Priority:** High

## H020 — RDM prevents redundancy overload
- **Family:** Multimedia Learning
- **Claim:** Non-duplicative overlays beat transcript duplication when audio is on.
- **Baseline:** Transcript overlay
- **Minimum experiment:** Audio-on duplicate vs semantic overlay.
- **Metrics:** effort; gist
- **Evidence grade:** Strong adjacent
- **Sources:** S11,S10
- **Priority:** High

## H021 — LMO beats decorative motion
- **Family:** Motion
- **Claim:** Motion tied to logic beats random/decorative motion.
- **Baseline:** Decorative motion
- **Minimum experiment:** Logic motion vs decorative motion.
- **Metrics:** sequence recall; effort
- **Evidence grade:** Moderate
- **Sources:** S14,S27
- **Priority:** Medium

## H022 — MSL improves salience in high-motion feeds
- **Family:** Motion
- **Claim:** Static important text can be more salient than constantly moving text.
- **Baseline:** Constant kinetic
- **Minimum experiment:** Motion silence vs constant motion.
- **Metrics:** recall; effort
- **Evidence grade:** Speculative but plausible
- **Sources:** S14,S27
- **Priority:** Medium

## H023 — ASC improves tone recall
- **Family:** Affective
- **Claim:** Affective-semantic captions improve tone recognition.
- **Baseline:** Neutral SCC
- **Minimum experiment:** Emotional clips with neutral vs affective overlay.
- **Metrics:** tone recognition; engagement
- **Evidence grade:** Moderate
- **Sources:** S15
- **Priority:** Medium

## H024 — PWE improves emphasis match
- **Family:** Sound/Prosody
- **Claim:** Prosody-aware visual emphasis improves perceived naturalness.
- **Baseline:** Uniform emphasis
- **Minimum experiment:** Prosody-aligned vs arbitrary emphasis.
- **Metrics:** naturalness; recall
- **Evidence grade:** Moderate/speculative
- **Sources:** S15,S14
- **Priority:** Medium

## H025 — Fast Payoff Rule improves early hold
- **Family:** Retention
- **Claim:** Show semantic payoff within first 1-2 seconds to improve hold.
- **Baseline:** Delayed payoff
- **Minimum experiment:** Early payoff vs delayed payoff.
- **Metrics:** 1-sec/3-sec hold; gist
- **Evidence grade:** Moderate adjacent
- **Sources:** S21,S22,S10
- **Priority:** Medium

## H026 — Ethical Retention Filter improves quality
- **Family:** Ethics
- **Claim:** Rejecting confusion-driven retention improves long-term value metrics.
- **Baseline:** Watch-time-only optimization
- **Minimum experiment:** Confusion-retention vs clarity-retention variants.
- **Metrics:** comments; saves; comprehension
- **Evidence grade:** Speculative
- **Sources:** S21,S22,S23
- **Priority:** Medium

## H027 — L2 simplified SCC improves L2 viewers
- **Family:** Personalization
- **Claim:** Simplified compression beats expert shorthand for L2 viewers.
- **Baseline:** Standard SCC
- **Minimum experiment:** L2 audience, simplified vs standard.
- **Metrics:** gist; effort
- **Evidence grade:** Moderate
- **Sources:** S03,S11
- **Priority:** Medium

## H028 — Expert shorthand improves expert viewers
- **Family:** Personalization
- **Claim:** Expert viewers prefer denser shorthand; novices need explicit labels.
- **Baseline:** Generic SCC
- **Minimum experiment:** Novice/expert segmented test.
- **Metrics:** gist; effort; preference
- **Evidence grade:** Moderate adjacent
- **Sources:** S11,S10
- **Priority:** Medium

## H029 — Progress marker reduces uncertainty
- **Family:** Structure
- **Claim:** Showing 1/3, 2/3, 3/3 improves completion for mini-lessons.
- **Baseline:** No marker
- **Minimum experiment:** Progress marker vs none.
- **Metrics:** completion; sequence recall
- **Evidence grade:** Moderate/speculative
- **Sources:** S10,S21
- **Priority:** Medium

## H030 — Memory-object captions improve recall
- **Family:** Memory
- **Claim:** A punchy final sentence improves delayed recall.
- **Baseline:** No final stamp
- **Minimum experiment:** Final memory stamp vs none.
- **Metrics:** delayed recall; shares/saves
- **Evidence grade:** Moderate/speculative
- **Sources:** S10,S16
- **Priority:** High

## H031 — Question-prompt captions improve engagement
- **Family:** Retrieval
- **Claim:** A brief retrieval prompt improves learning over passive ending.
- **Baseline:** Passive ending
- **Minimum experiment:** Prompt vs no prompt.
- **Metrics:** delayed recall; saves
- **Evidence grade:** Strong adjacent
- **Sources:** S10
- **Priority:** Medium

## H032 — No-text action windows improve demos
- **Family:** Visual Load
- **Claim:** During hand/product action, no text or labels beat sentences.
- **Baseline:** Sentences during action
- **Minimum experiment:** Action window: text vs no text/label.
- **Metrics:** task recall; visual recall
- **Evidence grade:** Strong adjacent
- **Sources:** S07,S09,S18
- **Priority:** High

## H033 — Object-near labels beat bottom captions in demos
- **Family:** Placement
- **Claim:** Labels near objects reduce eye travel.
- **Baseline:** Bottom captions
- **Minimum experiment:** Object-near labels vs bottom text.
- **Metrics:** task recall; eye travel
- **Evidence grade:** Moderate
- **Sources:** S12,S13,S17
- **Priority:** High

## H034 — UI-safe zones improve mobile readability
- **Family:** Platform UX
- **Claim:** Avoiding platform UI improves readability and reduces missed text.
- **Baseline:** UI-overlap
- **Minimum experiment:** Safe zone vs UI conflict.
- **Metrics:** readability; completion
- **Evidence grade:** Strong practical
- **Sources:** S07,S25,S26
- **Priority:** High

## H035 — High contrast plates improve cluttered backgrounds
- **Family:** Accessibility/Visual
- **Claim:** Text plates improve readability over moving/busy backgrounds.
- **Baseline:** No plate
- **Minimum experiment:** Plate vs no plate.
- **Metrics:** readability; effort
- **Evidence grade:** Strong
- **Sources:** S07,S26
- **Priority:** High

## H036 — Reduced color coding improves accessibility
- **Family:** Accessibility
- **Claim:** Meaning should not rely on color alone.
- **Baseline:** Color-only cues
- **Minimum experiment:** Color-only vs color+shape/text.
- **Metrics:** comprehension; accessibility pass
- **Evidence grade:** Strong
- **Sources:** S26
- **Priority:** High

## H037 — Low-motion mode improves accessibility
- **Family:** Accessibility/Motion
- **Claim:** Low-motion variants improve comfort for sensitive viewers.
- **Baseline:** High motion
- **Minimum experiment:** Low vs high motion.
- **Metrics:** comfort; effort; recall
- **Evidence grade:** Moderate
- **Sources:** S27,S14
- **Priority:** Medium

## H038 — 3-7 word beats outperform 10+ word blocks
- **Family:** Caption Density
- **Claim:** Short semantic beats outperform long blocks.
- **Baseline:** Long block
- **Minimum experiment:** 3-7 words vs 10+ words.
- **Metrics:** gist; effort
- **Evidence grade:** Strong adjacent
- **Sources:** S02,S25,S09
- **Priority:** High

## H039 — Semantic line breaks improve parsing
- **Family:** Typography
- **Claim:** Line breaks by phrase structure improve comprehension.
- **Baseline:** Arbitrary breaks
- **Minimum experiment:** Semantic vs arbitrary line breaks.
- **Metrics:** gist; effort
- **Evidence grade:** Moderate
- **Sources:** S16,S25
- **Priority:** Medium

## H040 — Anchor density sweet spot exists
- **Family:** Typography
- **Claim:** 1-3 anchors per beat outperform no anchors and dense anchors.
- **Baseline:** No anchors/dense
- **Minimum experiment:** 0 vs 1 vs 3 vs dense anchors.
- **Metrics:** recall; effort
- **Evidence grade:** Moderate/speculative
- **Sources:** S10,S05
- **Priority:** Critical

## H041 — Non-speech sound cues improve muted mode
- **Family:** Muted/A11Y
- **Claim:** Short sound cue labels improve understanding when sound off.
- **Baseline:** No sound labels
- **Minimum experiment:** Muted videos with/without sound cues.
- **Metrics:** muted comprehension
- **Evidence grade:** Strong
- **Sources:** S24,S25
- **Priority:** Medium

## H042 — Speaker ID matters in multi-speaker clips
- **Family:** A11Y
- **Claim:** Speaker labels improve comprehension in dialogue clips.
- **Baseline:** No speaker label
- **Minimum experiment:** Speaker labels vs none.
- **Metrics:** speaker/action recall
- **Evidence grade:** Strong
- **Sources:** S24,S25
- **Priority:** Medium

## H043 — Visual saliency conflict predicts lower recall
- **Family:** Prediction
- **Claim:** High overlap between text and salient regions predicts worse visual recall.
- **Baseline:** No prediction
- **Minimum experiment:** Correlate saliency overlap with recall.
- **Metrics:** visual recall; dwell
- **Evidence grade:** Moderate
- **Sources:** S17,S06
- **Priority:** High

## H044 — Meaning overlap predicts usefulness
- **Family:** Prediction
- **Claim:** Text that matches the semantic beat improves recall more than decorative text.
- **Baseline:** Decorative text
- **Minimum experiment:** Semantic relevance scoring vs outcomes.
- **Metrics:** gist; saves
- **Evidence grade:** Strong adjacent
- **Sources:** S06,S10
- **Priority:** High

## H045 — Adaptive routing beats one global winner
- **Family:** Systems
- **Claim:** Contextual routing outperforms one style across mixed content.
- **Baseline:** Global best
- **Minimum experiment:** Bandit/routing simulation or live test.
- **Metrics:** uplift by segment
- **Evidence grade:** Moderate/speculative
- **Sources:** S21,S17
- **Priority:** Medium

## H046 — Caption conflict detector reduces failures
- **Family:** Systems
- **Claim:** Automated detection of mouth/UI/clutter conflicts improves quality.
- **Baseline:** Manual fixed placement
- **Minimum experiment:** Auto conflict screening vs manual baseline.
- **Metrics:** rubric score; errors
- **Evidence grade:** Moderate/speculative
- **Sources:** S07,S17,S18
- **Priority:** Medium

## H047 — Pre-cue fails on jokes/spoilers
- **Family:** Boundary
- **Claim:** PSP may hurt comedy/surprise by spoiling payoff.
- **Baseline:** Sync captions
- **Minimum experiment:** Comedy pre-cue vs sync.
- **Metrics:** humor rating; completion
- **Evidence grade:** Speculative
- **Sources:** S16
- **Priority:** Medium

## H048 — Over-compression harms nuance
- **Family:** Boundary
- **Claim:** SCC can underperform FTO for nuance-heavy content.
- **Baseline:** FTO
- **Minimum experiment:** Nuance clips with FTO vs SCC.
- **Metrics:** exact/nuance recall
- **Evidence grade:** Strong logical
- **Sources:** S24,S11
- **Priority:** High

## H049 — Full captions win for exact recall
- **Family:** Boundary
- **Claim:** FTO/full captions outperform SCC/BCC on exact wording.
- **Baseline:** SCC/BCC
- **Minimum experiment:** Exact quote recall.
- **Metrics:** exact recall
- **Evidence grade:** Strong logical
- **Sources:** S24,S02
- **Priority:** High

## H050 — BCC+ best for busy educational clips
- **Family:** Segment
- **Claim:** BCC+ advantage is strongest in dense educational/advice clips.
- **Baseline:** BCC/SCC
- **Minimum experiment:** Segmented tests by genre.
- **Metrics:** gist; completion
- **Evidence grade:** Moderate
- **Sources:** S10,S11,S17
- **Priority:** High

## H051 — SCC/BCC weak for music lyrics
- **Family:** Boundary
- **Claim:** Karaoke/lyric captions may outperform semantic compression for lyrics.
- **Baseline:** BCC
- **Minimum experiment:** Music/lyric clips.
- **Metrics:** lyric tracking; enjoyment
- **Evidence grade:** Strong logical
- **Sources:** S24
- **Priority:** Low

## H052 — Affective captions best for emotional story
- **Family:** Segment
- **Claim:** ASC more useful than BCC for emotional/story content.
- **Baseline:** BCC
- **Minimum experiment:** Emotional clips: ASC vs BCC.
- **Metrics:** tone recall; engagement
- **Evidence grade:** Moderate
- **Sources:** S15,S18
- **Priority:** Medium

## H053 — Mouth-safe more important in noisy audio
- **Family:** Segment
- **Claim:** MSC effect grows when audio is degraded.
- **Baseline:** Mouth-covered
- **Minimum experiment:** Clean vs noisy audio.
- **Metrics:** speech comprehension
- **Evidence grade:** Strong
- **Sources:** S18
- **Priority:** Medium

## H054 — Caption rest improves face dwell
- **Family:** Eye movement
- **Claim:** MRR increases gaze return to face/object.
- **Baseline:** Continuous text
- **Minimum experiment:** Eye tracking, continuous vs micro-rest.
- **Metrics:** face/object dwell
- **Evidence grade:** Moderate/speculative
- **Sources:** S01,S19
- **Priority:** High

## H055 — Bionic anchors may increase saccades
- **Family:** Risk
- **Claim:** Bionic anchors can increase saccades/effort if overused.
- **Baseline:** SCC
- **Minimum experiment:** Eye tracking SCC vs BCC vs HBC.
- **Metrics:** saccades; effort
- **Evidence grade:** Strong risk
- **Sources:** S05,S04
- **Priority:** Critical

## H056 — Semantic compression improves accessibility for non-DHH muted users but not as replacement
- **Family:** Boundary
- **Claim:** SCC helps muted gist but is not full accessible captioning.
- **Baseline:** DLC/FTO
- **Minimum experiment:** DHH/accessibility test.
- **Metrics:** accessibility; exact recall
- **Evidence grade:** Strong
- **Sources:** S24,S25
- **Priority:** High

## H057 — Safe-zoned captions reduce missed text on mobile
- **Family:** Mobile UX
- **Claim:** Text away from UI and in readable zones improves comprehension.
- **Baseline:** Unsafe zones
- **Minimum experiment:** Mobile-only A/B.
- **Metrics:** readability; missed-caption reports
- **Evidence grade:** Strong practical
- **Sources:** S20,S25,S26
- **Priority:** High

## H058 — Larger sparse text lowers effort
- **Family:** Mobile UX
- **Claim:** Large sparse text works better on close smartphone viewing.
- **Baseline:** Small dense text
- **Minimum experiment:** Large/sparse vs small/dense.
- **Metrics:** readability; effort
- **Evidence grade:** Strong
- **Sources:** S20,S19,S26
- **Priority:** High

## H059 — Anchor words should be nouns/verbs/operators
- **Family:** Typography
- **Claim:** Anchoring filler words is noise; anchors should carry meaning or logic.
- **Baseline:** Random anchors
- **Minimum experiment:** Meaning anchors vs random anchors.
- **Metrics:** gist; effort
- **Evidence grade:** Strong adjacent
- **Sources:** S10,S16
- **Priority:** High

## H060 — Delayed memory stamp improves saves/shares
- **Family:** Retention/Memory
- **Claim:** A clear final memory object increases saves/shares.
- **Baseline:** No stamp
- **Minimum experiment:** Field A/B.
- **Metrics:** saves; shares; delayed recall
- **Evidence grade:** Moderate/speculative
- **Sources:** S10,S21
- **Priority:** Medium
