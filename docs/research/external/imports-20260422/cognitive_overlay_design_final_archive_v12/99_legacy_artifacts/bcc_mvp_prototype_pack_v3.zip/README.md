# BCC+ MVP Prototype Pack

This pack moves the project from research planning into usable production/testing assets.

## Core field structure

- **Cognitive Overlay Design**: broad field.
- **Physiological Retention Typography**: short-form/mobile branch.
- **Semantic Compression Captions**: method family.
- **Bionic Compression Captioning (BCC)**: semantic compression + operator anchors + bionic concept anchors + beat timing.
- **BCC+**: BCC + gaze-safe placement + visual-load adaptation + muted-first testing + full accessibility captions.

## Working law

> Do not make viewers read faster. Engineer the video so viewers need fewer fixations to understand more.

## What this pack contains

- `inputs/sample_beat_sheet.csv`: human-reviewed semantic beats for 12 test videos.
- `developer/bcc_overlay_generator.py`: CLI prototype that generates SRT, VTT, ASS, JSON overlay plans, and editor CSVs.
- `outputs/`: generated caption/overlay files for each video and variant.
- `study_materials/`: pilot survey, consent text, randomization plan, and data templates.
- `analysis/analysis_template.py`: simple analysis script for pilot results.
- `docs/`: production guide, scoring rubric, implementation spec, and research agenda.

## Quick start

From inside this folder:

```bash
python developer/bcc_overlay_generator.py --input inputs/sample_beat_sheet.csv --outdir outputs
```

Generated variants:

1. `full_transcript`
2. `keyword_highlight`
3. `semantic_compression`
4. `bcc`
5. `bcc_plus`
6. `heavy_bionic`

## First decisive test

Compare:

- **Semantic Compression**: `Not motivation. / Structure.`
- **BCC**: `<b>Not</b> <b>moti</b>vation. / <b>Struc</b>ture.`
- **BCC+**: BCC plus placement and visual-load rules.

The main question:

> Does BCC add value beyond semantic compression alone?

If no, the bionic element becomes optional styling. If yes, BCC remains a core method.
