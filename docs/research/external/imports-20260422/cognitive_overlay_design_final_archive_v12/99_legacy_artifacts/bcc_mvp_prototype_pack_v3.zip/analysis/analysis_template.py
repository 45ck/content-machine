#!/usr/bin/env python3
"""
Pilot analysis template for BCC/BCC+ validation.

Usage:
  python analysis/analysis_template.py study_materials/pilot_data_entry_template.csv

Fill the CSV first. Blank rows are ignored.
"""

from __future__ import annotations
import csv
import sys
from collections import defaultdict
from statistics import mean

NUMERIC_FIELDS = [
    "watch_time_sec","video_length_sec","gist_recall_score_0_2","action_recall_score_0_2",
    "contrast_recall_score_0_2","exact_recall_score_0_2","visual_recall_score_0_2","effort_1_5"
]

def as_float(x):
    try:
        if x is None or str(x).strip() == "":
            return None
        return float(x)
    except ValueError:
        return None

def summarize(path):
    rows = []
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            # Ignore rows with no actual response data.
            if as_float(row.get("gist_recall_score_0_2")) is None:
                continue
            rows.append(row)

    groups = defaultdict(list)
    for r in rows:
        groups[r["variant"]].append(r)

    print("Variant summary")
    print("===============")
    header = ["variant","n","completion_rate","avg_watch_time","gist","action","contrast","exact","visual","effort","meaning_per_sec"]
    print(",".join(header))
    for variant, rs in sorted(groups.items()):
        n = len(rs)
        watch = [as_float(r["watch_time_sec"]) for r in rs if as_float(r["watch_time_sec"]) is not None]
        lengths = [as_float(r["video_length_sec"]) for r in rs if as_float(r["video_length_sec"]) is not None]
        completed = []
        for r in rs:
            w = as_float(r["watch_time_sec"]); L = as_float(r["video_length_sec"])
            if w is not None and L:
                completed.append(1 if w >= L * 0.95 else 0)
        gist = [as_float(r["gist_recall_score_0_2"]) for r in rs if as_float(r["gist_recall_score_0_2"]) is not None]
        action = [as_float(r["action_recall_score_0_2"]) for r in rs if as_float(r["action_recall_score_0_2"]) is not None]
        contrast = [as_float(r["contrast_recall_score_0_2"]) for r in rs if as_float(r["contrast_recall_score_0_2"]) is not None]
        exact = [as_float(r["exact_recall_score_0_2"]) for r in rs if as_float(r["exact_recall_score_0_2"]) is not None]
        visual = [as_float(r["visual_recall_score_0_2"]) for r in rs if as_float(r["visual_recall_score_0_2"]) is not None]
        effort = [as_float(r["effort_1_5"]) for r in rs if as_float(r["effort_1_5"]) is not None]

        # Meaning score emphasizes gist/action/contrast and normalizes by watched seconds.
        meaning_scores = []
        for r in rs:
            w = as_float(r["watch_time_sec"])
            g = as_float(r["gist_recall_score_0_2"])
            a = as_float(r["action_recall_score_0_2"])
            c = as_float(r["contrast_recall_score_0_2"])
            if w and g is not None and a is not None and c is not None:
                meaning_scores.append((g + a + c) / w)

        values = [
            variant,
            str(n),
            f"{mean(completed):.3f}" if completed else "",
            f"{mean(watch):.2f}" if watch else "",
            f"{mean(gist):.2f}" if gist else "",
            f"{mean(action):.2f}" if action else "",
            f"{mean(contrast):.2f}" if contrast else "",
            f"{mean(exact):.2f}" if exact else "",
            f"{mean(visual):.2f}" if visual else "",
            f"{mean(effort):.2f}" if effort else "",
            f"{mean(meaning_scores):.3f}" if meaning_scores else "",
        ]
        print(",".join(values))

    print("\nCritical contrasts to inspect:")
    print("- semantic_compression vs bcc")
    print("- bcc vs bcc_plus")
    print("- bcc vs heavy_bionic")
    print("- full_transcript vs semantic_compression")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Pass a filled pilot_data_entry_template.csv path.")
        sys.exit(1)
    summarize(sys.argv[1])
