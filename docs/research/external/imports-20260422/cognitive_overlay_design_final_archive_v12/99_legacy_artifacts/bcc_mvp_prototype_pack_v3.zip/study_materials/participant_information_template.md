# Participant Information Sheet — Pilot Study

Purpose: test how different short-form video text overlay styles affect comprehension, recall, and perceived effort.

Task:
- Watch short videos on a phone or phone-sized screen.
- Some videos may be watched with audio, some muted.
- Answer brief questions after each video.

Data collected:
- Overlay condition
- Recall responses
- Perceived effort ratings
- Optional platform-style engagement ratings

No sensitive personal information is required for the pilot template.

This is a template for internal testing and should be reviewed before formal research use.
