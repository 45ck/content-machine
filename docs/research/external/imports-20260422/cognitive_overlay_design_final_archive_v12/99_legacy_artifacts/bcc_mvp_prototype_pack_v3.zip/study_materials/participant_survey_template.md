# Pilot Survey Template

## After each video

1. What was the main point?  
2. What action should the viewer take?  
3. What contrast or correction did the video make?  
4. What visual detail do you remember from the video?  
5. How hard was it to follow?  
   - 1 = very easy
   - 5 = very hard
6. Did the text help or distract?
   - helped
   - neutral
   - distracted
7. Would you keep watching this style?
   - yes
   - no
   - unsure

## End of session

1. Which text style felt easiest?
2. Which style felt most memorable?
3. Which style felt most distracting?
4. Which style would you prefer for educational videos?
5. Any comments?
