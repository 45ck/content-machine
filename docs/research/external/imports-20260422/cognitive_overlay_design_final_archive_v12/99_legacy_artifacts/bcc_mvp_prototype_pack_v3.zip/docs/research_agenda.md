# Research Agenda: Cognitive Overlay Design and BCC+

## Primary question

Does Bionic Compression Captioning add measurable value beyond semantic compression alone?

## Core comparison

1. Full transcript
2. Keyword-highlight transcript
3. Semantic compression
4. BCC
5. BCC+
6. Heavy bionic control

## Primary hypotheses

| ID | Hypothesis | Prediction |
|---|---|---|
| H1 | Semantic compression beats full transcript overlays for gist recall | Higher gist/action recall per second |
| H2 | BCC beats semantic compression | Small improvement in recall or subjective clarity |
| H3 | BCC+ beats BCC | Better muted comprehension and lower visual interference |
| H4 | Heavy bionic underperforms sparse BCC | Lower clarity, higher effort |
| H5 | Keyword highlight beats full transcript but loses to semantic compression | Moderate improvement only |
| H6 | BCC+ works best on conceptual/explanatory content | Stronger effect in productivity, study, finance, business |

## Unknowns to resolve

1. Does partial-word anchoring matter after semantic compression?
2. What is the minimum text needed to preserve gist?
3. What is the best placement zone for vertical video by content type?
4. How much motion helps before it overloads?
5. Should semantic cues appear before, during, or after speech?
6. Which viewers benefit most: muted, novice, L2, ADHD, expert, DHH?
7. Does BCC+ preserve visual recall better than transcript captions?
8. Can saliency/meaning maps automate placement?

## Target metrics

- Gist recall
- Action recall
- Contrast recall
- Exact wording recall
- Visual recall
- Perceived effort
- Muted comprehension
- Average watch time
- Completion rate
- Rewatch rate
- Saves/shares
- Text dwell time if eye tracking is available

## Master metric

> Meaning retained per second watched.

Advanced metric:

> Meaning retained per fixation.
