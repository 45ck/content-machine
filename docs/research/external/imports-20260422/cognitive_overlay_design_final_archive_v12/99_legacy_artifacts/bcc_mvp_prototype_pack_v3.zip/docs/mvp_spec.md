# Semantic Overlay Generator MVP Spec

## Product gap

Current creator tools mostly do:

> transcript → auto captions → keyword highlight → animation

BCC+ requires:

> transcript → proposition extraction → semantic beat compression → anchor selection → gaze-safe placement → timing → full captions + semantic overlay

## MVP scope

The current prototype is human-in-the-loop.

It assumes a person supplies:

- spoken text
- semantic caption
- keywords
- role
- placement zone
- visual load

The generator produces:

- SRT
- WebVTT
- ASS
- JSON overlay plans
- editor CSVs

## Future automation modules

| Module | Function |
|---|---|
| Transcript parser | Split speech into candidate beats |
| Proposition extractor | Identify claim, contrast, action, payoff |
| Semantic compressor | Rewrite speech into compact visual meaning |
| Operator detector | Detect not/no/stop/start/less/more/first/then |
| Concept detector | Identify key nouns/verbs to anchor |
| Saliency detector | Predict likely gaze zones |
| Face/mouth detector | Protect speech and emotional cues |
| Object/hand detector | Protect demos/tutorials |
| Visual-load estimator | Reduce density in busy frames |
| Timing optimizer | Align overlays with semantic beats |
| Exporter | Generate SRT/VTT/ASS/JSON/editor CSV |
| Experiment logger | Track variant, metrics, and outcomes |

## Decision rules

If BCC does not beat Semantic Compression:

> treat bionic anchors as optional styling.

If BCC+ beats BCC:

> prioritize placement, timing, and visual-load adaptation.

If heavy bionic underperforms:

> explicitly prohibit whole-caption bionic formatting in the method guide.
