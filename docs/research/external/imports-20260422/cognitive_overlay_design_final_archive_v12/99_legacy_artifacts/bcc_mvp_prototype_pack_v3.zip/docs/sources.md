# Source URLs

- W3C Captions: https://www.w3.org/WAI/media/av/captions/
- Section 508 Captioning guidance: https://www.section508.gov/create/captions-transcripts/
- Kruger et al. subtitle speed: https://www.cambridge.org/core/journals/applied-psycholinguistics/article/why-subtitle-speed-matters-evidence-from-word-skipping-and-rereading/A7DB0CBF5910353143738CF9C1721317
- Partial and Synchronized Captioning: https://www.cambridge.org/core/journals/recall/article/partial-and-synchronized-captioning-a-new-tool-to-assist-learners-in-developing-second-language-listening-skill/9394E3F0AD25FD5F32895F965F7ECCAD
- Signaling meta-analysis: https://www.sciencedirect.com/science/article/abs/pii/S1747938X17300581
- Meaning maps and attention: https://www.nature.com/articles/s41598-018-31894-5
- Bionic Reading 2024 Acta Psychologica: https://www.sciencedirect.com/science/article/pii/S0001691824001811
- Sound-off viewing / subtitles cognitive load: https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0306251
- Video saliency prediction challenge / AViMoS: https://github.com/msu-video-group/ECCVW24_Saliency_Prediction
- Kinetic typography review: https://www.nature.com/articles/s41599-023-01646-6