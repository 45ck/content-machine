# BCC+ Scoring Rubric

Score each dimension 1–5.

| Dimension | 1 | 3 | 5 |
|---|---|---|---|
| Compression | Transcript dump | Some reduction | Minimal wording with clear meaning |
| Semantic clarity | Cryptic | Understandable with audio | Understandable muted |
| Operator strength | Logic hidden | Some logic visible | Relation is instantly visible |
| Concept anchoring | Random emphasis | Some good anchors | Only key concepts emphasized |
| Placement | Blocks key visual | Minor interference | Protects face/object/action/UI |
| Timing | Late or early | Mostly aligned | Lands on semantic beat |
| Muted comprehension | Fails muted | Partial muted gist | Full gist/action clear muted |
| Visual load | Busy/noisy | Acceptable | Clean and low-effort |
| Accessibility | No full captions | Captions incomplete | Full captions available |
| Memorability | No phrase sticks | Some recall | Strong memory object |

## Minimum publish standard

- Average score: **4.0+**
- No dimension below **3**
- Full captions available
- No critical visual obstruction
