# Sample Stimulus Scripts

## V01_productivity_friction — productivity

Most people do not fail because they lack motivation. They fail because their day has no structure. If you want to change the habit, reduce the friction around the first step.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | Most people do not fail because they lack motivation. | Not motivation. | false_belief | motivation | center_upper | low |

| 2 | They fail because their day has no structure. | Structure. | correction | structure | center_upper | low |

| 3 | If you want to change the habit, reduce the friction around the first step. | Reduce friction. | mechanism | friction | left_mid | medium |

| 4 | Make the first step smaller than your resistance. | Shrink the start. | action | start | left_mid | medium |



## V02_study_recall — study

Rereading feels productive because it is familiar. But recall is the test that exposes what you actually know. Close the notes, retrieve the answer, then check.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | Rereading feels productive because it is familiar. | Rereading feels safe. | false_belief | rereading | center_upper | low |

| 2 | But recall is the test that exposes what you actually know. | Recall proves it. | correction | recall | center_upper | low |

| 3 | Close the notes, retrieve the answer, then check. | Close notes. Retrieve. Check. | action | retrieve | center_upper | medium |



## V03_fitness_setup — fitness

The problem is not discipline. The problem is that your environment makes the good choice harder than the bad choice. Put the shoes near the door before motivation is needed.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | The problem is not discipline. | Not discipline. | false_belief | discipline | center_upper | low |

| 2 | The problem is that your environment makes the good choice harder than the bad choice. | Bad setup. | diagnosis | setup | center_upper | low |

| 3 | Put the shoes near the door before motivation is needed. | Make good easy. | action | easy | left_mid | medium |



## V04_money_visibility — finance

You do not have a budgeting problem yet. You have a visibility problem. Track where the money goes before you try to control it.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | You do not have a budgeting problem yet. | Not budgeting. | false_belief | budgeting | center_upper | low |

| 2 | You have a visibility problem. | Visibility. | correction | visibility | center_upper | low |

| 3 | Track where the money goes before you try to control it. | Track first. | action | track | center_upper | medium |



## V05_coding_assumptions — software

Most debugging stalls because you are chasing symptoms. Log the assumption, isolate the input, and make the failure reproducible.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | Most debugging stalls because you are chasing symptoms. | Not symptoms. | false_belief | symptoms | center_upper | medium |

| 2 | Log the assumption, isolate the input, and make the failure reproducible. | Log assumptions. | action | assumptions | right_mid | high |

| 3 | Then isolate the input and make the failure reproducible. | Make failure repeat. | action | repeat | right_mid | high |



## V06_overload_open_loops — attention

When everything feels urgent, moving faster is not the answer. You need fewer open loops. Close one loop before you open another.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | When everything feels urgent, moving faster is not the answer. | Not faster. | false_belief | faster | center_upper | low |

| 2 | You need fewer open loops. | Fewer loops. | correction | loops | center_upper | low |

| 3 | Close one loop before you open another. | Close one first. | action | close | center_upper | medium |



## V07_business_clarity — business

If people are not buying, the first issue is often not price. It is clarity. They need to know what changes after they say yes.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | If people are not buying, the first issue is often not price. | Not price. | false_belief | price | center_upper | low |

| 2 | It is clarity. | Clarity. | correction | clarity | center_upper | low |

| 3 | They need to know what changes after they say yes. | Show the change. | action | change | left_mid | medium |



## V08_calendar_system — time_management

A to-do list tells you what exists. A calendar tells you when it will happen. If it matters, give it a time block.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | A to-do list tells you what exists. | To-do lists store. | diagnosis | store | center_upper | low |

| 2 | A calendar tells you when it will happen. | Calendars execute. | correction | execute | center_upper | low |

| 3 | If it matters, give it a time block. | Block it. | action | block | center_upper | medium |



## V09_nutrition_satiety — nutrition

If you are hungry an hour after eating, it might not be willpower. It might be low satiety. Add protein, fiber, or volume first.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | If you are hungry an hour after eating, it might not be willpower. | Not willpower. | false_belief | willpower | center_upper | low |

| 2 | It might be low satiety. | Low satiety. | diagnosis | satiety | center_upper | low |

| 3 | Add protein, fiber, or volume first. | Protein. Fiber. Volume. | action | protein;fiber;volume | left_mid | medium |



## V10_tutorial_ui — tutorial

Do not search every menu. Open settings, choose notifications, then turn off non-essential alerts. Keep only the alerts that cause action.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | Do not search every menu. | Stop searching. | warning | searching | right_mid | high |

| 2 | Open settings, choose notifications, then turn off non-essential alerts. | Settings. Notifications. | sequence | settings;notifications | right_mid | high |

| 3 | Keep only the alerts that cause action. | Keep action alerts. | action | alerts | right_mid | high |



## V11_story_burnout — story

Burnout often hides inside tiny decisions. Not one big task, but a hundred unresolved choices. Reduce the decisions before you reduce the ambition.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | Burnout often hides inside tiny decisions. | Tiny decisions. | diagnosis | decisions | center_upper | low |

| 2 | Not one big task, but a hundred unresolved choices. | Not one task. | false_belief | task | center_upper | low |

| 3 | Reduce the decisions before you reduce the ambition. | Reduce decisions. | action | decisions | center_upper | medium |



## V12_creativity_constraints — creativity

Creativity does not need infinite freedom. It needs useful constraints. Choose a format, set a deadline, and make one version.

| Beat | Spoken text | Semantic caption | Role | Keywords | Placement | Visual load |
|---:|---|---|---|---|---|---|

| 1 | Creativity does not need infinite freedom. | Not freedom. | false_belief | freedom | center_upper | low |

| 2 | It needs useful constraints. | Useful constraints. | correction | constraints | center_upper | low |

| 3 | Choose a format, set a deadline, and make one version. | Format. Deadline. Version. | action | format;deadline;version | center_upper | medium |


