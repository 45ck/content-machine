# MEM-013 / ACO — Action Checklist Overlay

## Reference label

MEM-013 / ACO — Action Checklist Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H128 |
| Method code | MEM-013 |
| Short code | ACO |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Convert advice into 2–3 checklist items at end.

## Mechanism

Supports implementation.

## Expected direction

Higher action recall.

## Failure mode

Too much text at end.

## Minimum viable experiment

Checklist vs memory phrase.

## Primary metrics

Action recall; saves

## Source IDs

S09; S17
