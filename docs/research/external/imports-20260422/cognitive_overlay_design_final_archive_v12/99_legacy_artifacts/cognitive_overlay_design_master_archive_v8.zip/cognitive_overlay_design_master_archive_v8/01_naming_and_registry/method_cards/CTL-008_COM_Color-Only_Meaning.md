# CTL-008 / COM — Color-Only Meaning

## Reference label

CTL-008 / COM — Color-Only Meaning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H174 |
| Method code | CTL-008 |
| Short code | COM |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P1 |
| Evidence grade | Negative control |
| Status | Backlog |

## Definition / what to try

Use color without labels/icons for semantic roles.

## Mechanism

Accessibility negative control.

## Expected direction

Likely failure for color-blind/low contrast contexts.

## Failure mode

Meaning can be missed.

## Minimum viable experiment

Compare to color+label.

## Primary metrics

Role ID; access rating

## Source IDs

S28
