# GAZ-004 / ONL — Object-Near Labels

## Reference label

GAZ-004 / ONL — Object-Near Labels

## Classification

| Field | Value |
|---|---|
| Backlog ID | H059 |
| Method code | GAZ-004 |
| Short code | ONL |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Place short labels next to the relevant object instead of bottom captions.

## Mechanism

Reduces split attention and search.

## Expected direction

Better tutorial comprehension.

## Failure mode

Labels may crowd the object.

## Minimum viable experiment

Bottom caption vs object-near labels.

## Primary metrics

Task recall; gaze travel

## Source IDs

S13; S14
