# MEM-010 / ARP — Active Recall Pause

## Reference label

MEM-010 / ARP — Active Recall Pause

## Classification

| Field | Value |
|---|---|
| Backlog ID | H125 |
| Method code | MEM-010 |
| Short code | ARP |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Pause briefly after an instruction before giving answer/example.

## Mechanism

Creates retrieval opportunity.

## Expected direction

Improved memory.

## Failure mode

May lower retention if too slow.

## Minimum viable experiment

Pause vs no pause.

## Primary metrics

Delayed recall; completion

## Source IDs

S09; S29
