# TIM-013 / LCC — Loop Callback Caption

## Reference label

TIM-013 / LCC — Loop Callback Caption

## Classification

| Field | Value |
|---|---|
| Backlog ID | H053 |
| Method code | TIM-013 |
| Short code | LCC |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

End with a phrase that reinterprets the opening hook.

## Mechanism

Improves narrative closure and rewatch.

## Expected direction

Higher completion and rewatch.

## Failure mode

Can become manipulative if hook was weak.

## Minimum viable experiment

Callback vs generic ending.

## Primary metrics

Completion; rewatch

## Source IDs

S25
