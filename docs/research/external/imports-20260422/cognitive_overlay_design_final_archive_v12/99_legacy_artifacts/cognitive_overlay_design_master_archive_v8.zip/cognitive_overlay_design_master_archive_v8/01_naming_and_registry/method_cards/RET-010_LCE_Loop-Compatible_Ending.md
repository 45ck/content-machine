# RET-010 / LCE — Loop-Compatible Ending

## Reference label

RET-010 / LCE — Loop-Compatible Ending

## Classification

| Field | Value |
|---|---|
| Backlog ID | H165 |
| Method code | RET-010 |
| Short code | LCE |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

End with text that connects to first frame without hiding final meaning.

## Mechanism

Encourages rewatch while preserving clarity.

## Expected direction

Higher rewatch.

## Failure mode

May annoy if obvious.

## Minimum viable experiment

Loop ending vs hard stop.

## Primary metrics

Rewatch; recall

## Source IDs

S25
