# SEM-003 / OFC — Operator-First Captioning

## Reference label

SEM-003 / OFC — Operator-First Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H003 |
| Method code | SEM-003 |
| Short code | OFC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Begin overlay with logical operator: Not, Stop, Less, First, Then.

## Mechanism

Reveals relation before content; supports phrase structure.

## Expected direction

Better contrast recall than keyword-only captions.

## Failure mode

Too many operators feel formulaic.

## Minimum viable experiment

Keyword-only vs Not-X/Y microphrases.

## Primary metrics

Contrast recall; completion rate

## Source IDs

S06; S07; S09; S10; S27
