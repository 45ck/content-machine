# AUD — Sound and Multimodal

This family contains 10 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AUD-001 | AUD | Audio-On Cue Mode | Rule / Mode | Pilot second | P1 | Strong adjacent | When audio is expected, overlay only cues and structure, not full language. | Audio-on cue vs full overlay. | Visual recall; gist |
| AUD-002 | MFM | Muted-First Mode | Rule / Mode | Pilot first | P0 | Strong adjacent | Overlay carries enough meaning without sound. | Muted-first vs cue-mode. | Muted gist; effort |
| AUD-003 | DLC | Dual-Layer Captioning | Multimodal Method | Pilot first | P0 | Strong adjacent | Full closed captions plus separate semantic overlay. | Closed captions only vs dual-layer. | Access rating; gist; clutter |
| AUD-004 | NSS | Non-Speech Sound Cues | Multimodal Method | Pilot first | P0 | Strong requirement | Show [laughter], [music rises], [door slam] only when meaningful. | With/without sound cues. | Comprehension; access rating |
| AUD-005 | PAE | Prosody-Aware Emphasis | Multimodal Method | Explore later | P2 | Moderate adjacent | Map speaker emphasis/intensity to controlled text weight or motion. | Prosody-aware vs uniform captions. | Tone recognition; effort |
| AUD-006 | SAE | Silence as Emphasis | Multimodal Method | Explore later | P2 | Speculative / direct test needed | Use no overlay during silence or facial reaction, then land a short caption. | Continuous caption vs silence+payoff. | Engagement; tone recall |
| AUD-007 | ACT | Audio Clarity Trigger | Multimodal Method | Pilot second | P1 | Moderate adjacent | If background music/noise is high, increase caption completeness. | Clean vs noisy audio variants. | Comprehension; effort |
| AUD-008 | RRC | Rhythm-Respecting Captions | Multimodal Method | Explore later | P2 | Speculative / direct test needed | Avoid text changes on every music beat unless text is music/lyric content. | Beat-synced vs semantic-synced. | Effort; recall |
| AUD-009 | TI | Tone Icons | Multimodal Method | Explore later | P3 | Speculative / direct test needed | Use small icons for sarcasm, warning, encouragement only when tone is ambiguous. | Tone icon vs none. | Tone accuracy; preference |
| AUD-010 | HCV | Haptic Caption Variant | Multimodal Method | Explore later | P3 | Speculative / cutting-edge | For AR/wearables, use vibration patterns for emotion or emphasis. | Lab prototype with haptic cues. | Tone recognition; workload |
