# KIN-003 / KCF — Kinetic Contrast Flip

## Reference label

KIN-003 / KCF — Kinetic Contrast Flip

## Classification

| Field | Value |
|---|---|
| Backlog ID | H078 |
| Method code | KIN-003 |
| Short code | KCF |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Visually flip from false belief to correction.

## Mechanism

Makes reframe memorable.

## Expected direction

Better contrast recall.

## Failure mode

May distract from speaker.

## Minimum viable experiment

Static contrast vs flip animation.

## Primary metrics

Contrast recall; distraction

## Source IDs

S19; S27
