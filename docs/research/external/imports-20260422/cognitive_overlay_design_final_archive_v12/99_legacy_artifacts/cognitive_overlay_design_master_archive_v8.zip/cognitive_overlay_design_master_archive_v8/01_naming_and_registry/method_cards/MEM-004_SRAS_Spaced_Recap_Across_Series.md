# MEM-004 / SRAS — Spaced Recap Across Series

## Reference label

MEM-004 / SRAS — Spaced Recap Across Series

## Classification

| Field | Value |
|---|---|
| Backlog ID | H119 |
| Method code | MEM-004 |
| Short code | SRAS |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Repeat same memory phrase across multiple videos with variation.

## Mechanism

Spaced exposure strengthens schema.

## Expected direction

Better long-term recognition.

## Failure mode

May feel repetitive.

## Minimum viable experiment

Series with/without recurring phrase.

## Primary metrics

Delayed recognition; follower retention

## Source IDs

S09
