# TIM-007 / MEG — Minimum Exposure Guardrail

## Reference label

TIM-007 / MEG — Minimum Exposure Guardrail

## Classification

| Field | Value |
|---|---|
| Backlog ID | H047 |
| Method code | TIM-007 |
| Short code | MEG |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

No caption shorter than 0.8 sec except one-word impact beats.

## Mechanism

Respects reading timing constraints.

## Expected direction

Lower missed captions.

## Failure mode

May slow fast content.

## Minimum viable experiment

Min duration on/off variants.

## Primary metrics

Missed caption rate; effort

## Source IDs

S03; S04; S06
