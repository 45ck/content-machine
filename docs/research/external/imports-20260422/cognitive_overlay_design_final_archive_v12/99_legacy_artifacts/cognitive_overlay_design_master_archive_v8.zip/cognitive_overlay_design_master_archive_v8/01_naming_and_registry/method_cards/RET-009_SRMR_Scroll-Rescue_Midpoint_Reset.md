# RET-009 / SRMR — Scroll-Rescue Midpoint Reset

## Reference label

RET-009 / SRMR — Scroll-Rescue Midpoint Reset

## Classification

| Field | Value |
|---|---|
| Backlog ID | H164 |
| Method code | RET-009 |
| Short code | SRMR |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

At 40–60%, add a new semantic hook or map update.

## Mechanism

Prevents attention decay.

## Expected direction

Higher completion.

## Failure mode

Feels artificial if not content-driven.

## Minimum viable experiment

Midpoint reset vs none.

## Primary metrics

Completion curve; rewatch

## Source IDs

S25
