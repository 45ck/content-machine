# MEM-008 / MCM — Mini Concept Map

## Reference label

MEM-008 / MCM — Mini Concept Map

## Classification

| Field | Value |
|---|---|
| Backlog ID | H123 |
| Method code | MEM-008 |
| Short code | MCM |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Show 2–4 nodes connected during complex explanations.

## Mechanism

Externalizes relations.

## Expected direction

Better comprehension of multi-part ideas.

## Failure mode

May crowd small screen.

## Minimum viable experiment

Concept map vs captions.

## Primary metrics

Relation recall; effort

## Source IDs

S09; S15
