# TYP-005 / SLB — Semantic Line Breaks

## Reference label

TYP-005 / SLB — Semantic Line Breaks

## Classification

| Field | Value |
|---|---|
| Backlog ID | H025 |
| Method code | TYP-005 |
| Short code | SLB |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Break lines by meaning, not by width alone.

## Mechanism

Line breaks become parsing cues.

## Expected direction

Better readability and lower effort.

## Failure mode

Poor breaks hurt grammar comprehension.

## Minimum viable experiment

Natural vs arbitrary line breaks.

## Primary metrics

Effort; reading completion

## Source IDs

S02; S04; S09
