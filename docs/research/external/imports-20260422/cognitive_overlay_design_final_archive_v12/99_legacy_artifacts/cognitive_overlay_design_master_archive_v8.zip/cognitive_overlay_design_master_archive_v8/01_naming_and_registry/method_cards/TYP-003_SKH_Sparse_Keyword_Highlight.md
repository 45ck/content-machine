# TYP-003 / SKH — Sparse Keyword Highlight

## Reference label

TYP-003 / SKH — Sparse Keyword Highlight

## Classification

| Field | Value |
|---|---|
| Backlog ID | H023 |
| Method code | TYP-003 |
| Short code | SKH |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Highlight only 5–15% of displayed words.

## Mechanism

Reduces search cost without turning everything salient.

## Expected direction

Lower perceived effort.

## Failure mode

Wrong keyword selection misguides attention.

## Minimum viable experiment

Sparse vs dense highlight.

## Primary metrics

Effort; recall; gaze distribution

## Source IDs

S08; S09
