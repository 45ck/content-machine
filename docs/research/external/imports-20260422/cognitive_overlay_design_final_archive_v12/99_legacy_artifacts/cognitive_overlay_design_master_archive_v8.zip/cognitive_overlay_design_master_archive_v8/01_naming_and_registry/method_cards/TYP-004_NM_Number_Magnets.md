# TYP-004 / NM — Number Magnets

## Reference label

TYP-004 / NM — Number Magnets

## Classification

| Field | Value |
|---|---|
| Backlog ID | H024 |
| Method code | TYP-004 |
| Short code | NM |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use distinct emphasis for numbers, percentages, steps, dates.

## Mechanism

Numbers create decision hooks and are easy to remember.

## Expected direction

Better exact recall for quantitative claims.

## Failure mode

May create false precision bias.

## Minimum viable experiment

Number-emphasis vs normal text.

## Primary metrics

Number recall; trust rating

## Source IDs

S09; S28
