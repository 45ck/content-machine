# AUD-006 / SAE — Silence as Emphasis

## Reference label

AUD-006 / SAE — Silence as Emphasis

## Classification

| Field | Value |
|---|---|
| Backlog ID | H111 |
| Method code | AUD-006 |
| Short code | SAE |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Multimodal Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use no overlay during silence or facial reaction, then land a short caption.

## Mechanism

Protects emotional beats.

## Expected direction

Better engagement and affect recognition.

## Failure mode

Muted viewers may need context.

## Minimum viable experiment

Continuous caption vs silence+payoff.

## Primary metrics

Engagement; tone recall

## Source IDs

S20; S32
