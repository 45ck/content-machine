# Analysis Plan

## Primary contrasts

1. SCC vs FTO: tests compression.
2. BCC vs SCC: tests bionic anchors.
3. BCC+ vs BCC: tests adaptive protocol.
4. HBC vs BCC: tests sparse vs heavy bionic formatting.
5. GSP vs BFP: tests placement.
6. PSP vs SYNC vs POST: tests timing.
7. VLAC vs fixed density: tests visual-load adaptation.

## Interpretation matrix

| Result | Meaning |
|---|---|
| SCC > FTO | Compression is useful. |
| BCC > SCC | Bionic anchors add value. |
| BCC ≈ SCC | Bionic anchors are optional. |
| BCC+ > BCC | Placement/load/timing are stronger than typography alone. |
| HBC < BCC | Dense bionic styling is harmful or noisy. |
| GSP > BFP | Placement should be adaptive. |
| PSP > SYNC | Predictive semantic priming is useful. |
| VLAC > fixed | Caption density should adapt to visual load. |
