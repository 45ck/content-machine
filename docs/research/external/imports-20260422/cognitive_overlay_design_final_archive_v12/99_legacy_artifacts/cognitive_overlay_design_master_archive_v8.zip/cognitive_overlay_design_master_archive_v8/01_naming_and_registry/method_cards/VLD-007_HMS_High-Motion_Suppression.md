# VLD-007 / HMS — High-Motion Suppression

## Reference label

VLD-007 / HMS — High-Motion Suppression

## Classification

| Field | Value |
|---|---|
| Backlog ID | H097 |
| Method code | VLD-007 |
| Short code | HMS |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Reduce caption animation and density during high visual motion.

## Mechanism

Prevents competing motion streams.

## Expected direction

Better visual recall.

## Failure mode

Could miss key speech during action.

## Minimum viable experiment

Motion-adaptive vs fixed overlay.

## Primary metrics

Visual recall; comprehension

## Source IDs

S19; S15
