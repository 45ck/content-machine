# MEM-003 / QCE — Quick Check End Card

## Reference label

MEM-003 / QCE — Quick Check End Card

## Classification

| Field | Value |
|---|---|
| Backlog ID | H118 |
| Method code | MEM-003 |
| Short code | QCE |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

End with micro quiz: Motivation or structure?

## Mechanism

Forces contrast recall.

## Expected direction

Higher memory and comments.

## Failure mode

May feel classroom-like.

## Minimum viable experiment

Quiz vs memory phrase.

## Primary metrics

Delayed recall; comments

## Source IDs

S09
