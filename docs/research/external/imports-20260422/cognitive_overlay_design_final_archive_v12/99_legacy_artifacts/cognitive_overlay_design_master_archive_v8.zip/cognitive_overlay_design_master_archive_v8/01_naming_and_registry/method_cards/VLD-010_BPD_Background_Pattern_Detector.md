# VLD-010 / BPD — Background Pattern Detector

## Reference label

VLD-010 / BPD — Background Pattern Detector

## Classification

| Field | Value |
|---|---|
| Backlog ID | H100 |
| Method code | VLD-010 |
| Short code | BPD |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Flag stripes, grids, leaves, and high-frequency textures behind text.

## Mechanism

Crowding and contrast risk is high on patterned backgrounds.

## Expected direction

Better readability after repositioning.

## Failure mode

Detector may overflag.

## Minimum viable experiment

Pattern-aware vs fixed placement.

## Primary metrics

Readability; failure rate

## Source IDs

S15; S28
