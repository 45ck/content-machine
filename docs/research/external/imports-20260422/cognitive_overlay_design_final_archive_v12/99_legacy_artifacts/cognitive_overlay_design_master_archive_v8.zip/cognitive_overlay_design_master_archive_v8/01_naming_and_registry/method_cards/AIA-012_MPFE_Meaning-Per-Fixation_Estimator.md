# AIA-012 / MPFE — Meaning-Per-Fixation Estimator

## Reference label

AIA-012 / MPFE — Meaning-Per-Fixation Estimator

## Classification

| Field | Value |
|---|---|
| Backlog ID | H152 |
| Method code | AIA-012 |
| Short code | MPFE |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | Adaptive System |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / future |
| Status | Backlog |

## Definition / what to try

Combine recall results and gaze/text dwell to estimate efficiency.

## Mechanism

Optimizes for cognitive value, not watch time alone.

## Expected direction

Better metric alignment.

## Failure mode

Requires eye/gaze data.

## Minimum viable experiment

Estimate vs actual recall.

## Primary metrics

Predictive validity

## Source IDs

S30; S11
