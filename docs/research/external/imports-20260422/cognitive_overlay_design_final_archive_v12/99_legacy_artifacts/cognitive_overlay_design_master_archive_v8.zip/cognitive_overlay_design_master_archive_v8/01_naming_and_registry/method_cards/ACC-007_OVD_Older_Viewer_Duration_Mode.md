# ACC-007 / OVD — Older Viewer Duration Mode

## Reference label

ACC-007 / OVD — Older Viewer Duration Mode

## Classification

| Field | Value |
|---|---|
| Backlog ID | H137 |
| Method code | ACC-007 |
| Short code | OVD |
| Category | Personalization / Access |
| Family | Accessibility and Personalization |
| Class | Rule / Mode |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Increase caption duration and font size for older viewers.

## Mechanism

Accounts for slower visual processing/reading needs.

## Expected direction

Better readability.

## Failure mode

May slow pacing.

## Minimum viable experiment

Standard vs longer/larger captions.

## Primary metrics

Readability; effort

## Source IDs

S03; S28
