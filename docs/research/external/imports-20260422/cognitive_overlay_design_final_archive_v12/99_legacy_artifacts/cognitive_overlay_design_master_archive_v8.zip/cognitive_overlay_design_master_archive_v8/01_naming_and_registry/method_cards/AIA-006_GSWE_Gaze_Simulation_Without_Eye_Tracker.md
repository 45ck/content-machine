# AIA-006 / GSWE — Gaze Simulation Without Eye Tracker

## Reference label

AIA-006 / GSWE — Gaze Simulation Without Eye Tracker

## Classification

| Field | Value |
|---|---|
| Backlog ID | H146 |
| Method code | AIA-006 |
| Short code | GSWE |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | Adaptive System |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use saliency/meaning maps to simulate likely gaze conflict.

## Mechanism

Low-cost proxy for early testing.

## Expected direction

Catches major layout failures.

## Failure mode

Cannot replace real gaze data.

## Minimum viable experiment

Model score vs user gaze subset.

## Primary metrics

Correlation with gaze/errors

## Source IDs

S11; S12
