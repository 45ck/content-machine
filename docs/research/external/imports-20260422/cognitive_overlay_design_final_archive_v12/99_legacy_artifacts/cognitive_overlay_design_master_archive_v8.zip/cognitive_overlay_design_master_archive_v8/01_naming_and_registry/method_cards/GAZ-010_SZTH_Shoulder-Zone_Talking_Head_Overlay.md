# GAZ-010 / SZTH — Shoulder-Zone Talking Head Overlay

## Reference label

GAZ-010 / SZTH — Shoulder-Zone Talking Head Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H065 |
| Method code | GAZ-010 |
| Short code | SZTH |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Place captions near upper chest/shoulder, away from mouth/eyes/UI.

## Mechanism

Balances face access and text proximity.

## Expected direction

Better than bottom captions for talking heads.

## Failure mode

May cover gestures or clothing patterns.

## Minimum viable experiment

Shoulder-zone vs lower-third.

## Primary metrics

Comprehension; mouth visibility

## Source IDs

S18; S32
