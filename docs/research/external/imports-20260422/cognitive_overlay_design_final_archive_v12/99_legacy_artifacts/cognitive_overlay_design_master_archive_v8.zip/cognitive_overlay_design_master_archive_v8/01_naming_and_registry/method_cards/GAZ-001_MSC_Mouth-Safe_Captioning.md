# GAZ-001 / MSC — Mouth-Safe Captioning

## Reference label

GAZ-001 / MSC — Mouth-Safe Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H056 |
| Method code | GAZ-001 |
| Short code | MSC |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Never cover the mouth during speech-heavy clips.

## Mechanism

Protects audiovisual speech cues.

## Expected direction

Better comprehension in noisy/audio-on conditions.

## Failure mode

Less relevant when muted.

## Minimum viable experiment

Mouth-covered vs mouth-safe overlay.

## Primary metrics

Comprehension; face dwell

## Source IDs

S18; S32
