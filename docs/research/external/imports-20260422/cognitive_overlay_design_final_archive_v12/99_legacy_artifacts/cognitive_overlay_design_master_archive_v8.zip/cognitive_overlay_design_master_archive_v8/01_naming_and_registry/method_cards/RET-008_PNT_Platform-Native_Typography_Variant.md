# RET-008 / PNT — Platform-Native Typography Variant

## Reference label

RET-008 / PNT — Platform-Native Typography Variant

## Classification

| Field | Value |
|---|---|
| Backlog ID | H163 |
| Method code | RET-008 |
| Short code | PNT |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Emerging direct evidence |
| Status | Backlog |

## Definition / what to try

Test clean professional vs TikTok-native emoji/non-standard style.

## Mechanism

Matches audience expectations.

## Expected direction

Higher engagement for some categories.

## Failure mode

Can reduce professionalism/accessibility.

## Minimum viable experiment

Clean vs native style.

## Primary metrics

Engagement; trust; comprehension

## Source IDs

S21; S28
