# VLD-001 / VLAW — Visual-Load Adaptive Word Count

## Reference label

VLD-001 / VLAW — Visual-Load Adaptive Word Count

## Classification

| Field | Value |
|---|---|
| Backlog ID | H091 |
| Method code | VLD-001 |
| Short code | VLAW |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Use fewer overlay words when the frame is visually busy.

## Mechanism

Balances visual-channel load.

## Expected direction

Better comprehension in demos and complex scenes.

## Failure mode

Can under-explain muted clips.

## Minimum viable experiment

Fixed vs adaptive density.

## Primary metrics

Gist; visual recall; effort

## Source IDs

S10; S15; S17
