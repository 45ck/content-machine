# GAZ — Placement and Gaze

This family contains 20 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GAZ-001 | MSC | Mouth-Safe Captioning | Placement Method | Pilot first | P0 | Strong adjacent | Never cover the mouth during speech-heavy clips. | Mouth-covered vs mouth-safe overlay. | Comprehension; face dwell |
| GAZ-002 | ESC | Eye-Safe Captioning | Placement Method | Pilot second | P1 | Moderate adjacent | Avoid covering eyes in emotional/storytelling clips. | Eye-covered vs eye-safe. | Emotion recognition; completion |
| GAZ-003 | ASC | Action-Safe Captioning | Placement Method | Pilot first | P0 | Strong adjacent | Avoid hands, products, joints, cursor, and key action path. | Action-covered vs action-safe. | Visual recall; task accuracy |
| GAZ-004 | ONL | Object-Near Labels | Placement Method | Pilot second | P1 | Moderate adjacent | Place short labels next to the relevant object instead of bottom captions. | Bottom caption vs object-near labels. | Task recall; gaze travel |
| GAZ-005 | USZT | UI-Safe Zone Templates | Placement Method | Pilot first | P0 | Strong practical / direct test needed | Define TikTok/Reels/Shorts danger zones and avoid them. | Bottom-fixed vs UI-safe placement. | Readability; occlusion rate |
| GAZ-006 | SAP | Saliency-Avoiding Placement | Placement Method | Pilot second | P1 | Moderate adjacent | Place text away from predicted high-saliency regions unless it is a label. | Fixed vs saliency-aware placement. | Visual recall; gaze distribution |
| GAZ-007 | MMP | Meaning-Map Placement | Placement Method | Pilot second | P1 | Moderate adjacent | Place text where it supports the semantic region of the scene. | Meaning-aware vs low-level saliency placement. | Gist recall; gaze alignment |
| GAZ-008 | CAC | Crowding-Aware Captioning | Placement Method | Pilot first | P0 | Strong adjacent | Avoid placing text near other text, UI, or high-frequency background. | Crowded vs uncrowded placement. | Readability; effort |
| GAZ-009 | NSC | Negative-Space Captions | Placement Method | Pilot second | P1 | Moderate adjacent | Use empty background regions for semantic overlays. | Negative space vs default bottom. | Readability; visual recall |
| GAZ-010 | SZTH | Shoulder-Zone Talking Head Overlay | Placement Method | Pilot second | P1 | Speculative / direct test needed | Place captions near upper chest/shoulder, away from mouth/eyes/UI. | Shoulder-zone vs lower-third. | Comprehension; mouth visibility |
| GAZ-011 | SRTL | Screen-Recording Target Labels | Placement Method | Pilot second | P1 | Moderate adjacent | Place labels near the cursor/control being discussed. | Bottom captions vs target labels. | Task accuracy; gaze path |
| GAZ-012 | PHC | Product Halo Captions | Placement Method | Explore later | P2 | Speculative / direct test needed | Place short labels in a ring around product without covering it. | Halo labels vs caption block. | Attribute recall; visual recall |
| GAZ-013 | FAP | Foveal Anchor + Peripheral Cue | Placement Method | Explore later | P2 | Moderate adjacent | Put readable text centrally; use peripheral arrows/icons for orientation. | Text-only vs text+peripheral cue. | Gist recall; gaze travel |
| GAZ-014 | DRAR | Dynamic Reflow Around ROI | Placement Method | Pilot second | P1 | Moderate adjacent | Move captions frame-by-frame around faces/hands/products. | Static safe zone vs dynamic reflow. | Visual recall; distraction |
| GAZ-015 | STAP | Shot-Type-Aware Placement | Placement Method | Pilot second | P1 | Speculative / direct test needed | Use different placement rules for talking head, demo, screen recording, story. | Generic vs shot-aware placement. | Comprehension by category |
| GAZ-016 | SFC | Speaker-Following Captions | Placement Method | Explore later | P2 | Moderate adjacent | Move text near active speaker in multi-speaker clips. | Bottom captions vs speaker-following. | Speaker recall; user preference |
| GAZ-017 | ELT | Eye-Line Triangle Rule | Rule / Mode | Explore later | P2 | Speculative / direct test needed | Place overlay within triangle between speaker’s eyes, hands/object, and center. | Triangle placement vs arbitrary. | Saccade distance; effort |
| GAZ-018 | PCR | Platform Crop Repositioning | Placement Method | Pilot second | P1 | Strong practical / direct test needed | Automatically reposition overlays for TikTok, Reels, Shorts, YouTube preview. | Single export vs platform-specific exports. | Occlusion rate; retention by platform |
| GAZ-019 | CCD | Caption Collision Detector | Placement Method | Pilot first | P0 | Strong practical / direct test needed | Detect overlap with native captions, stickers, captions, and UI. | Manual vs auto collision check. | Collision count; readability |
| GAZ-020 | GRW | Gaze Return Windows | Placement Method | Explore later | P2 | Moderate adjacent | After text appears, reserve moments where nothing blocks the face/object. | No-return vs return-window design. | Visual recall; gaze dwell |
