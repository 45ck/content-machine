# MEM-002 / PP — Prediction Prompt

## Reference label

MEM-002 / PP — Prediction Prompt

## Classification

| Field | Value |
|---|---|
| Backlog ID | H117 |
| Method code | MEM-002 |
| Short code | PP |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Before solution, ask viewer to predict cause/fix.

## Mechanism

Engages active processing.

## Expected direction

Better retention if answer arrives fast.

## Failure mode

May annoy viewers seeking quick answer.

## Minimum viable experiment

Prediction vs direct answer.

## Primary metrics

Recall; completion

## Source IDs

S09; S29
