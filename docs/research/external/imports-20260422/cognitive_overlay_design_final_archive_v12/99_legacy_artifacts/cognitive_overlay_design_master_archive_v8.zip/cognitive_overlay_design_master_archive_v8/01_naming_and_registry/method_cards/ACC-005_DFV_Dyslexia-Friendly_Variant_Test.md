# ACC-005 / DFV — Dyslexia-Friendly Variant Test

## Reference label

ACC-005 / DFV — Dyslexia-Friendly Variant Test

## Classification

| Field | Value |
|---|---|
| Backlog ID | H135 |
| Method code | ACC-005 |
| Short code | DFV |
| Category | Personalization / Access |
| Family | Accessibility and Personalization |
| Class | Access / Personalization Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Compare bionic, LARF-like annotation, spacing, and plain compression for dyslexic viewers.

## Mechanism

Different readability interventions may help specific groups.

## Expected direction

Identify subgroup-specific winners.

## Failure mode

Risk of overclaiming without subgroup testing.

## Minimum viable experiment

Dyslexic participants by overlay type.

## Primary metrics

Reading ease; comprehension

## Source IDs

S22; S23
