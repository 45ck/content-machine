# TIM-015 / OBS — On-Beat Silence

## Reference label

TIM-015 / OBS — On-Beat Silence

## Classification

| Field | Value |
|---|---|
| Backlog ID | H055 |
| Method code | TIM-015 |
| Short code | OBS |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use no text during important sounds, laughs, or music drops.

## Mechanism

Prevents text from flattening audio moments.

## Expected direction

Better enjoyment.

## Failure mode

Muted viewers lose context unless captions provide sound cue.

## Minimum viable experiment

Text during sound vs no text + sound cue.

## Primary metrics

Enjoyment; comprehension

## Source IDs

S01; S05; S20
