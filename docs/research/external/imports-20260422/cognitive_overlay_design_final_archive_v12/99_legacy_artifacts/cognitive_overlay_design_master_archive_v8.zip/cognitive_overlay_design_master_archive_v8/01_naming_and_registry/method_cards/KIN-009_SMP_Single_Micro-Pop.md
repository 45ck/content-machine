# KIN-009 / SMP — Single Micro-Pop

## Reference label

KIN-009 / SMP — Single Micro-Pop

## Classification

| Field | Value |
|---|---|
| Backlog ID | H084 |
| Method code | KIN-009 |
| Short code | SMP |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Only one word pops per beat.

## Mechanism

Captures attention without karaoke noise.

## Expected direction

Better than every-word popping.

## Failure mode

Wrong word pop harms comprehension.

## Minimum viable experiment

One-pop vs all-word pop.

## Primary metrics

Keyword recall; effort

## Source IDs

S08; S19
