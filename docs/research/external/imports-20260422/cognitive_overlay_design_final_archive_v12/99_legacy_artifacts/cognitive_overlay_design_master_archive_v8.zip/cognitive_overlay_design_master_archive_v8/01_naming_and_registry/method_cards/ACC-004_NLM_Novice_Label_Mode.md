# ACC-004 / NLM — Novice Label Mode

## Reference label

ACC-004 / NLM — Novice Label Mode

## Classification

| Field | Value |
|---|---|
| Backlog ID | H134 |
| Method code | ACC-004 |
| Short code | NLM |
| Category | Personalization / Access |
| Family | Accessibility and Personalization |
| Class | Rule / Mode |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Add labels for unfamiliar concepts before compressing heavily.

## Mechanism

Builds pretraining/context.

## Expected direction

Better beginner comprehension.

## Failure mode

More text load.

## Minimum viable experiment

Labels vs no labels for beginners.

## Primary metrics

Beginner gist; effort

## Source IDs

S09; S10
