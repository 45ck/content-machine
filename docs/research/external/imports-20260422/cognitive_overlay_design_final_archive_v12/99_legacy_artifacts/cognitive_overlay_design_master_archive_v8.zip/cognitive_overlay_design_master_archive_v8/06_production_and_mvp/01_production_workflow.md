# Production Workflow

## Step 1 — Transcript

Create a full transcript and preserve it for closed captions.

## Step 2 — Proposition extraction

Identify the underlying claim or instruction.

## Step 3 — Semantic beats

Break the proposition into short beats.

## Step 4 — Choose method

Use SCC for clean compression, BCC when testing bionic anchors, and BCC+ when using placement/density/muted-first rules.

## Step 5 — Add anchors

Full-bold operators: Not, No, Stop, Start, Less, More, First, Then.  
Partial-bold concept words: **moti**vation, **struc**ture, **fric**tion, **trig**ger, **sys**tem.

## Step 6 — Place safely

Avoid covering mouth, eyes, hands, object, UI, action, diagrams, or native captions.

## Step 7 — Time to beats

One-word impact: 0.5–0.8 sec. Two to three words: 0.8–1.2 sec. Four to seven words: 1.2–2.0 sec. Eight or more words: rewrite.

## Step 8 — Muted test

Watch without sound. If the main idea is unclear, add one clarifying word or beat.

## Step 9 — Visual interference test

If the overlay blocks what the viewer needs to process, move or shorten it.
