# BCC — Bionic Compression Captioning

## Definition

BCC combines semantic compression with two anchor types:

1. **Full-word operator anchors**: **Not**, **Stop**, **Less**, **First**, **Then**.
2. **Bionic concept anchors**: partial-word emphasis on core concepts, such as **moti**vation, **struc**ture, **fric**tion.

## Example

> **Not** **moti**vation.  
> **Struc**ture.

## Purpose

Test whether sparse typographic anchoring improves attention, recognition, or memory after the text has already been compressed.

## Core test

Compare SCC against BCC. If BCC does not beat SCC, bionic anchors become optional styling.
