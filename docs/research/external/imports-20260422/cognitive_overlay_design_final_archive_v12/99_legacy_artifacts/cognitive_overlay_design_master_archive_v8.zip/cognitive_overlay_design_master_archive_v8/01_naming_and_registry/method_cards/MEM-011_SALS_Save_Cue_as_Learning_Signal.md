# MEM-011 / SALS — Save Cue as Learning Signal

## Reference label

MEM-011 / SALS — Save Cue as Learning Signal

## Classification

| Field | Value |
|---|---|
| Backlog ID | H126 |
| Method code | MEM-011 |
| Short code | SALS |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use a save-worthy rule card, not a begging call-to-action.

## Mechanism

Memory object + utility.

## Expected direction

Higher saves without cheap engagement.

## Failure mode

Can feel manipulative if overused.

## Minimum viable experiment

Rule card vs generic CTA.

## Primary metrics

Saves; recall

## Source IDs

S25
