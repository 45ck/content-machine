# CTL-009 / BOP — Bottom-Only Placement

## Reference label

CTL-009 / BOP — Bottom-Only Placement

## Classification

| Field | Value |
|---|---|
| Backlog ID | H175 |
| Method code | CTL-009 |
| Short code | BOP |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P0 |
| Evidence grade | Control |
| Status | Backlog |

## Definition / what to try

Always lower-third regardless of content.

## Mechanism

Placement baseline.

## Expected direction

Can block UI/captions/action.

## Failure mode

Likely loses to gaze-safe placement.

## Minimum viable experiment

Compare to gaze-safe.

## Primary metrics

Occlusion; readability

## Source IDs

S02; S14
