# Changelog

## v8 — Master organized archive

Created on 2026-04-21.

### Added

- Consolidated all prior packs into one archive.
- Added `README.md` and `START_HERE.md`.
- Added detailed markdown registry for core vocabulary, condition codes, method families, method cards, and experiments.
- Added individual method cards for 178 named methods/components/controls.
- Added family-level markdown files for all method families.
- Added source index extracted from prior reports.
- Added first pilot, validation protocol, analysis plan, and production workflow.
- Preserved original files in `08_original_artifacts`.

### Current research stance

The strongest likely system is Semantic Compression + Signaling + Gaze-Safe Placement + Visual-Load Adaptation. Bionic anchors remain worth testing but should not be treated as the main mechanism until SCC vs BCC validates them.
