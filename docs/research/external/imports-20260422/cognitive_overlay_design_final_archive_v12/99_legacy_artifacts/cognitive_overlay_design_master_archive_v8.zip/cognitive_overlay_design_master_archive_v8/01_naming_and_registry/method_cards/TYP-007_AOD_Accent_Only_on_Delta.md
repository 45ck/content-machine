# TYP-007 / AOD — Accent Only on Delta

## Reference label

TYP-007 / AOD — Accent Only on Delta

## Classification

| Field | Value |
|---|---|
| Backlog ID | H027 |
| Method code | TYP-007 |
| Short code | AOD |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Highlight only what changes from old belief to new belief.

## Mechanism

Maximizes semantic contrast.

## Expected direction

Better reframe recall.

## Failure mode

Requires accurate detection of old/new model.

## Minimum viable experiment

Full highlight vs delta-only highlight.

## Primary metrics

Contrast recall

## Source IDs

S08; S09; S22; S23; S28
