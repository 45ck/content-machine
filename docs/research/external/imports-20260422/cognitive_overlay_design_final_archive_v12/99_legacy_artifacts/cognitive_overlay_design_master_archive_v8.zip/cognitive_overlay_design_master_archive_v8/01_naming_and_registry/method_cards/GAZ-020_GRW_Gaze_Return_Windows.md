# GAZ-020 / GRW — Gaze Return Windows

## Reference label

GAZ-020 / GRW — Gaze Return Windows

## Classification

| Field | Value |
|---|---|
| Backlog ID | H075 |
| Method code | GAZ-020 |
| Short code | GRW |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

After text appears, reserve moments where nothing blocks the face/object.

## Mechanism

Lets gaze return to visual information.

## Expected direction

Better visual recall.

## Failure mode

Muted viewers may need text continuity.

## Minimum viable experiment

No-return vs return-window design.

## Primary metrics

Visual recall; gaze dwell

## Source IDs

S05; S10; S13
