# TYP-002 / FOA — Full-Word Operator Anchors

## Reference label

TYP-002 / FOA — Full-Word Operator Anchors

## Classification

| Field | Value |
|---|---|
| Backlog ID | H022 |
| Method code | TYP-002 |
| Short code | FOA |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Bold full operator words: Not, Stop, First, Less.

## Mechanism

Makes logical relation visible instantly.

## Expected direction

Better contrast recall.

## Failure mode

Overuse reduces salience.

## Minimum viable experiment

Operator-bold vs no bold.

## Primary metrics

Contrast recall; fixation latency

## Source IDs

S08; S09; S27; S28
