# KIN-002 / DCM — Directional Causal Motion

## Reference label

KIN-002 / DCM — Directional Causal Motion

## Classification

| Field | Value |
|---|---|
| Backlog ID | H077 |
| Method code | KIN-002 |
| Short code | DCM |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Move cause toward effect with arrow/line animation.

## Mechanism

Spatializes causality.

## Expected direction

Better causal understanding.

## Failure mode

Can look cheesy or busy.

## Minimum viable experiment

Text-only vs directional cause animation.

## Primary metrics

Causal recall; transfer

## Source IDs

S19
