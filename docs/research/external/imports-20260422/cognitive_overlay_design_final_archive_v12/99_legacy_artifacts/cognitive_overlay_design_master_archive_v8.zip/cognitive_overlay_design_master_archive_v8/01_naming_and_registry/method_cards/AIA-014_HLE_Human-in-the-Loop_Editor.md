# AIA-014 / HLE — Human-in-the-Loop Editor

## Reference label

AIA-014 / HLE — Human-in-the-Loop Editor

## Classification

| Field | Value |
|---|---|
| Backlog ID | H154 |
| Method code | AIA-014 |
| Short code | HLE |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | Adaptive System |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

AI proposes; editor approves proposition, anchor, placement, timing.

## Mechanism

Balances speed with correctness.

## Expected direction

Fewer hallucinations than full automation.

## Failure mode

Still requires training/editor time.

## Minimum viable experiment

AI-only vs human-in-loop.

## Primary metrics

Accuracy; time saved

## Source IDs

S30
