# VLD-011 / FLCC — Frame-Level Contrast Correction

## Reference label

VLD-011 / FLCC — Frame-Level Contrast Correction

## Classification

| Field | Value |
|---|---|
| Backlog ID | H101 |
| Method code | VLD-011 |
| Short code | FLCC |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Auto adjust text/backplate contrast per frame.

## Mechanism

Keeps readability stable across video.

## Expected direction

Fewer unreadable moments.

## Failure mode

Style may shift too much.

## Minimum viable experiment

Static style vs auto-correct.

## Primary metrics

WCAG ratio; readability

## Source IDs

S28
