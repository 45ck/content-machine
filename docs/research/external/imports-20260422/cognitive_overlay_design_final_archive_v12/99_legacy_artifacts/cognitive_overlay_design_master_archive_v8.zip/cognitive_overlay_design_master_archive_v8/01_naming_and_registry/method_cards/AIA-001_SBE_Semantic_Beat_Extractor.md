# AIA-001 / SBE — Semantic Beat Extractor

## Reference label

AIA-001 / SBE — Semantic Beat Extractor

## Classification

| Field | Value |
|---|---|
| Backlog ID | H141 |
| Method code | AIA-001 |
| Short code | SBE |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | System Module |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

LLM extracts proposition, role, and beat boundaries from transcript.

## Mechanism

Automates compression pipeline.

## Expected direction

Faster production and consistent structure.

## Failure mode

LLM may hallucinate or distort meaning.

## Minimum viable experiment

Human vs AI beat extraction.

## Primary metrics

Edit distance; accuracy; time saved

## Source IDs

S09; S30
