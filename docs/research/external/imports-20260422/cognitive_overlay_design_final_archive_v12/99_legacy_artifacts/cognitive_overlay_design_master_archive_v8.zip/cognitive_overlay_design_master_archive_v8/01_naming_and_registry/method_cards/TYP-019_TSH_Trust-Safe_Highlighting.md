# TYP-019 / TSH — Trust-Safe Highlighting

## Reference label

TYP-019 / TSH — Trust-Safe Highlighting

## Classification

| Field | Value |
|---|---|
| Backlog ID | H039 |
| Method code | TYP-019 |
| Short code | TSH |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Avoid styling that exaggerates uncertain claims.

## Mechanism

Maintains credibility while cueing importance.

## Expected direction

Higher trust in nuanced content.

## Failure mode

May reduce hook strength.

## Minimum viable experiment

Overstated vs trust-safe styling.

## Primary metrics

Trust; comprehension; comments

## Source IDs

S08; S09; S22; S23; S28
