# TYP-016 / PAT — Punctuation as Timing Cue

## Reference label

TYP-016 / PAT — Punctuation as Timing Cue

## Classification

| Field | Value |
|---|---|
| Backlog ID | H036 |
| Method code | TYP-016 |
| Short code | PAT |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use periods, arrows, colons, and line breaks as rhythm markers.

## Mechanism

Supports phrase parsing and temporal expectation.

## Expected direction

Better phrase comprehension.

## Failure mode

TikTok-native styles may omit punctuation, conflicting with clarity.

## Minimum viable experiment

Punctuated vs non-punctuated versions.

## Primary metrics

Comprehension; engagement

## Source IDs

S21; S27
