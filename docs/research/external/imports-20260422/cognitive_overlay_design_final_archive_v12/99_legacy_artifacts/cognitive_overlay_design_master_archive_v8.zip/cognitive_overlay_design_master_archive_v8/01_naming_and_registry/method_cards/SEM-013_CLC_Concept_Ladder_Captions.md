# SEM-013 / CLC — Concept Ladder Captions

## Reference label

SEM-013 / CLC — Concept Ladder Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H013 |
| Method code | SEM-013 |
| Short code | CLC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Move from concrete to abstract: shoes → start → habit.

## Mechanism

Builds schema progressively.

## Expected direction

Better novice comprehension.

## Failure mode

Experts may find it slow.

## Minimum viable experiment

Beginner viewers: ladder vs direct concept.

## Primary metrics

Novice gist recall

## Source IDs

S06; S07; S09; S10; S27
