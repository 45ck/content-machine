# TYP-009 / CBU — Contrast Block Underlay

## Reference label

TYP-009 / CBU — Contrast Block Underlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H029 |
| Method code | TYP-009 |
| Short code | CBU |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Place text on a stable capsule/plate over busy video.

## Mechanism

Reduces crowding and background interference.

## Expected direction

Higher readability in busy scenes.

## Failure mode

May obscure visual content or look heavy.

## Minimum viable experiment

Plate vs no plate on busy backgrounds.

## Primary metrics

Readability; visual recall

## Source IDs

S15; S28
