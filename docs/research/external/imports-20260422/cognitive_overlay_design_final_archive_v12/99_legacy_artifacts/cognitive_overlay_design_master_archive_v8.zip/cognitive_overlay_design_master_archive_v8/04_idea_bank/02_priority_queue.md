# Priority Queue

| Method Code | Short Code | Canonical Name | Category | Phase | Priority | Evidence Grade | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CTL-001 | FTO | Full Transcript Overlay | Negative Control | Experiment control | P0 | Control | Compare against compression/BCC. | Exact recall; effort |
| CTL-002 | KHT | Keyword Highlight Transcript | Negative Control | Experiment control | P0 | Control | Compare to semantic compression. | Gist; effort |
| CTL-003 | WWDC | Word-by-Word Dynamic Caption | Negative Control | Experiment control | P0 | Control | Compare to semantic beats. | Gist; fatigue |
| CTL-004 | HBF | Heavy Bionic Formatting | Negative Control | Experiment control | P0 | Negative control | Compare to BCC and compression. | Recall; saccades; effort |
| CTL-007 | NNO | No Overlay / Native Captions Only | Negative Control | Experiment control | P0 | Control | Compare to all variants. | Gist; visual recall; retention |
| CTL-009 | BOP | Bottom-Only Placement | Negative Control | Experiment control | P0 | Control | Compare to gaze-safe. | Occlusion; readability |
| ACC-001 | CCP | Closed-Caption Preservation Rule | Personalization / Access | Pilot first | P0 | Strong requirement | User tests with overlay only vs dual layer. | Access rating; comprehension |
| ACC-008 | CBSC | Color-Blind Safe Coding | Personalization / Access | Pilot first | P0 | Strong requirement | Color-only vs color+label. | Role identification; access rating |
| AIA-004 | FMHO | Face/Mouth/Hand/Object Detector | AI / Adaptive | Pilot first | P0 | Strong practical / direct test needed | Manual vs CV safe-zone detection. | Occlusion errors; readability |
| AIA-009 | PSZT | Platform Safe-Zone Templates | AI / Adaptive | Pilot first | P0 | Strong practical / direct test needed | Template vs manual export. | Occlusion rate by platform |
| AIA-014 | HLE | Human-in-the-Loop Editor | AI / Adaptive | Pilot first | P0 | Strong practical / direct test needed | AI-only vs human-in-loop. | Accuracy; time saved |
| AUD-002 | MFM | Muted-First Mode | Sound / Multimodal | Pilot first | P0 | Strong adjacent | Muted-first vs cue-mode. | Muted gist; effort |
| AUD-003 | DLC | Dual-Layer Captioning | Sound / Multimodal | Pilot first | P0 | Strong adjacent | Closed captions only vs dual-layer. | Access rating; gist; clutter |
| AUD-004 | NSS | Non-Speech Sound Cues | Sound / Multimodal | Pilot first | P0 | Strong requirement | With/without sound cues. | Comprehension; access rating |
| GAZ-001 | MSC | Mouth-Safe Captioning | Placement / Gaze | Pilot first | P0 | Strong adjacent | Mouth-covered vs mouth-safe overlay. | Comprehension; face dwell |
| GAZ-003 | ASC | Action-Safe Captioning | Placement / Gaze | Pilot first | P0 | Strong adjacent | Action-covered vs action-safe. | Visual recall; task accuracy |
| GAZ-005 | USZT | UI-Safe Zone Templates | Placement / Gaze | Pilot first | P0 | Strong practical / direct test needed | Bottom-fixed vs UI-safe placement. | Readability; occlusion rate |
| GAZ-008 | CAC | Crowding-Aware Captioning | Placement / Gaze | Pilot first | P0 | Strong adjacent | Crowded vs uncrowded placement. | Readability; effort |
| GAZ-019 | CCD | Caption Collision Detector | Placement / Gaze | Pilot first | P0 | Strong practical / direct test needed | Manual vs auto collision check. | Collision count; readability |
| KIN-010 | DKC | De-Karaoke Captions | Motion / Kinetic | Pilot first | P0 | Strong adjacent | Karaoke vs semantic beats. | Gist recall; effort |
| RET-001 | HOO | Hook Card | Platform / Retention | Pilot first | P0 | Moderate adjacent | Hook card vs no hook card. | 1s/3s hold; comments sentiment |
| RET-002 | FPR | Fast Payoff Rule | Platform / Retention | Pilot first | P0 | Moderate adjacent | Delayed payoff vs fast payoff. | 3s hold; completion; trust |
| RET-011 | ERF | Ethical Retention Filter | Platform / Retention | Pilot first | P0 | Speculative / governance | Qualitative review + retention metrics. | Clarification comments; trust |
| SEM-001 | SCC | Semantic Compression Captions | Semantic / Compression | Pilot first | P0 | Strong adjacent | Full transcript vs semantic compression on same clip. | Gist recall; action recall; perceived effort |
| SEM-002 | PEO | Proposition Extraction Overlay | Semantic / Compression | Pilot first | P0 | Moderate adjacent | Human-coded propositions vs transcript overlay. | Main point accuracy; distortion errors |
| SEM-003 | OFC | Operator-First Captioning | Semantic / Compression | Pilot first | P0 | Moderate adjacent | Keyword-only vs Not-X/Y microphrases. | Contrast recall; completion rate |
| SEM-005 | PCFB | Problem–Cause–Fix Beat Cards | Semantic / Compression | Pilot first | P0 | Strong adjacent | Same explainer with/without beat labels. | Action recall; perceived structure |
| SEM-014 | CRL | Compression Ratio Ladder | Semantic / Compression | Pilot first | P0 | Strong adjacent | Same clip at multiple compression ratios. | Gist recall; text dwell; effort |
| SEM-016 | OIOS | One Idea, One Screen Rule | Semantic / Compression | Pilot first | P0 | Strong adjacent | Multi-idea vs one-idea overlay. | Effort; sequence recall |
| SEM-017 | GET | Gist vs Exact Mode Toggle | Semantic / Compression | Pilot first | P0 | Strong adjacent | Full captions plus gist overlay vs overlay alone. | Preference; comprehension; access rating |
| TIM-001 | PSP | Predictive Semantic Priming | Timing / Rhythm | Pilot first | P0 | Moderate adjacent | Pre-cue vs sync vs post-cue. | Gist recall; smoothness; effort |
| TIM-007 | MEG | Minimum Exposure Guardrail | Timing / Rhythm | Pilot first | P0 | Strong adjacent | Min duration on/off variants. | Missed caption rate; effort |
| TYP-001 | BCA | Bionic Concept Anchors | Typography / Anchors | Pilot first | P0 | Weak / contested | Semantic compression vs BCC. | Gist recall; fixation count; preference |
| TYP-002 | FOA | Full-Word Operator Anchors | Typography / Anchors | Pilot first | P0 | Moderate adjacent | Operator-bold vs no bold. | Contrast recall; fixation latency |
| TYP-003 | SKH | Sparse Keyword Highlight | Typography / Anchors | Pilot first | P0 | Strong adjacent | Sparse vs dense highlight. | Effort; recall; gaze distribution |
| TYP-018 | BDG | Bionic Density Gradient | Typography / Anchors | Pilot first | P0 | Weak / contested | Dose-response bionic experiment. | Recall; saccades; effort |
| TYP-020 | ACAC | Accessible Contrast Auto-Check | Typography / Anchors | Pilot first | P0 | Strong adjacent | Manual vs auto contrast corrected. | Readability; WCAG pass rate |
| VLD-001 | VLAW | Visual-Load Adaptive Word Count | Visual Load / Clutter | Pilot first | P0 | Strong adjacent | Fixed vs adaptive density. | Gist; visual recall; effort |
| VLD-006 | CCD2 | Caption Conflict Detector | Visual Load / Clutter | Pilot first | P0 | Strong practical / direct test needed | Conflict detector on/off. | Text count; effort; recall |
| VLD-008 | STB | Simultaneous Text Budget | Visual Load / Clutter | Pilot first | P0 | Strong adjacent | Budgeted vs unbudgeted overlays. | Effort; recall |
| VLD-009 | NCCC | Native Caption Conflict Checker | Visual Load / Clutter | Pilot first | P0 | Strong practical / direct test needed | With/without conflict checking. | Occlusion; user complaints |
| VLD-011 | FLCC | Frame-Level Contrast Correction | Visual Load / Clutter | Pilot first | P0 | Strong adjacent | Static style vs auto-correct. | WCAG ratio; readability |
| CTL-005 | ROW | RSVP One-Word Captions | Negative Control | Experiment control | P1 | Negative control | Compare to semantic beats. | Comprehension; fatigue |
| CTL-006 | CKT | Constant Kinetic Text | Negative Control | Experiment control | P1 | Negative control | Compare to logic motion. | Recall; fatigue; retention |
| CTL-008 | COM | Color-Only Meaning | Negative Control | Experiment control | P1 | Negative control | Compare to color+label. | Role ID; access rating |
| CTL-010 | RSP | Random Saliency Pop | Negative Control | Experiment control | P1 | Negative control | Compare to semantic cueing. | Gist; trust |
| CTL-011 | HDCS | High-Density Caption Stack | Negative Control | Experiment control | P1 | Negative control | Compare to budgeted text. | Readability; effort |
| ACC-004 | NLM | Novice Label Mode | Personalization / Access | Pilot second | P1 | Strong adjacent | Labels vs no labels for beginners. | Beginner gist; effort |
| ACC-006 | LMM | Low-Motion Mode | Personalization / Access | Pilot second | P1 | Moderate adjacent | Static vs kinetic variants. | Comfort; retention |
| AIA-001 | SBE | Semantic Beat Extractor | AI / Adaptive | Pilot second | P1 | Speculative / direct test needed | Human vs AI beat extraction. | Edit distance; accuracy; time saved |
| AIA-002 | GEN | Overlay Variant Generator | AI / Adaptive | Pilot second | P1 | Strong practical / direct test needed | Manual vs generated variants. | Production time; quality score |
| AIA-003 | SHP | Saliency Heatmap Placement | AI / Adaptive | Pilot second | P1 | Moderate adjacent | Fixed vs saliency-aware placement. | Visual recall; occlusion rate |
| AIA-005 | VLP | Visual Load Predictor | AI / Adaptive | Pilot second | P1 | Speculative / direct test needed | Human-coded vs model-coded load. | Prediction validity; recall |
| AIA-007 | ABG | Automatic A/B Generator | AI / Adaptive | Pilot second | P1 | Strong practical / direct test needed | Randomized content batches. | Variant lift; confidence intervals |
| AIA-008 | BRAS | BCC+ Rubric Auto-Scorer | AI / Adaptive | Pilot second | P1 | Moderate adjacent | Rubric vs no rubric production. | Failure rate; pilot performance |
| AUD-001 | AUD | Audio-On Cue Mode | Sound / Multimodal | Pilot second | P1 | Strong adjacent | Audio-on cue vs full overlay. | Visual recall; gist |
| AUD-007 | ACT | Audio Clarity Trigger | Sound / Multimodal | Pilot second | P1 | Moderate adjacent | Clean vs noisy audio variants. | Comprehension; effort |
| GAZ-002 | ESC | Eye-Safe Captioning | Placement / Gaze | Pilot second | P1 | Moderate adjacent | Eye-covered vs eye-safe. | Emotion recognition; completion |
| GAZ-004 | ONL | Object-Near Labels | Placement / Gaze | Pilot second | P1 | Moderate adjacent | Bottom caption vs object-near labels. | Task recall; gaze travel |
| GAZ-006 | SAP | Saliency-Avoiding Placement | Placement / Gaze | Pilot second | P1 | Moderate adjacent | Fixed vs saliency-aware placement. | Visual recall; gaze distribution |
| GAZ-007 | MMP | Meaning-Map Placement | Placement / Gaze | Pilot second | P1 | Moderate adjacent | Meaning-aware vs low-level saliency placement. | Gist recall; gaze alignment |
| GAZ-009 | NSC | Negative-Space Captions | Placement / Gaze | Pilot second | P1 | Moderate adjacent | Negative space vs default bottom. | Readability; visual recall |
| GAZ-010 | SZTH | Shoulder-Zone Talking Head Overlay | Placement / Gaze | Pilot second | P1 | Speculative / direct test needed | Shoulder-zone vs lower-third. | Comprehension; mouth visibility |
| GAZ-011 | SRTL | Screen-Recording Target Labels | Placement / Gaze | Pilot second | P1 | Moderate adjacent | Bottom captions vs target labels. | Task accuracy; gaze path |
| GAZ-014 | DRAR | Dynamic Reflow Around ROI | Placement / Gaze | Pilot second | P1 | Moderate adjacent | Static safe zone vs dynamic reflow. | Visual recall; distraction |
| GAZ-015 | STAP | Shot-Type-Aware Placement | Placement / Gaze | Pilot second | P1 | Speculative / direct test needed | Generic vs shot-aware placement. | Comprehension by category |
| GAZ-018 | PCR | Platform Crop Repositioning | Placement / Gaze | Pilot second | P1 | Strong practical / direct test needed | Single export vs platform-specific exports. | Occlusion rate; retention by platform |
| KIN-001 | LM | Logic Motion | Motion / Kinetic | Pilot second | P1 | Moderate adjacent | Static vs logic motion. | Sequence recall; effort |
| KIN-006 | PRL | Progressive Reveal Ladder | Motion / Kinetic | Pilot second | P1 | Strong adjacent | All-at-once vs progressive reveal. | Sequence recall; effort |
| KIN-008 | MS | Motion Silence | Motion / Kinetic | Pilot second | P1 | Moderate adjacent | Constant motion vs motion silence. | Recall; perceived quality |
| KIN-009 | SMP | Single Micro-Pop | Motion / Kinetic | Pilot second | P1 | Moderate adjacent | One-pop vs all-word pop. | Keyword recall; effort |
| KIN-012 | GST | Gesture-Synced Text | Motion / Kinetic | Pilot second | P1 | Moderate adjacent | Gesture-sync vs off-sync. | Task accuracy; recall |
| KIN-015 | MBS | Motion Budget Score | Motion / Kinetic | Pilot second | P1 | Moderate adjacent | Low/medium/high motion dose. | Effort; completion; recall |
| MEM-001 | RPC | Retrieval Prompt Caption | Memory / Learning | Pilot second | P1 | Strong adjacent | Prompt vs no prompt. | Delayed recall; saves |
| MEM-005 | TBSM | Three-Beat Schema Map | Memory / Learning | Pilot second | P1 | Strong adjacent | Map vs no map. | Sequence recall; save rate |
| MEM-013 | ACO | Action Checklist Overlay | Memory / Learning | Pilot second | P1 | Moderate adjacent | Checklist vs memory phrase. | Action recall; saves |
| RET-003 | OLER | Open-Loop With Early Resolution | Platform / Retention | Pilot second | P1 | Speculative / direct test needed | Delayed open-loop vs early-resolution. | Completion; trust |
| RET-006 | PAY | Payoff Card | Platform / Retention | Pilot second | P1 | Moderate adjacent | Payoff card vs normal ending. | Saves; recall |
| SEM-004 | CPC | Contrast Pair Cards | Semantic / Compression | Pilot second | P1 | Moderate adjacent | Contrast pair vs normal sentence. | Gist recall; save rate |
| SEM-008 | TFO | Takeaway-First Overlay | Semantic / Compression | Pilot second | P1 | Moderate adjacent | Hook-first vs takeaway-first variants. | 1s/3s hold; completion |
