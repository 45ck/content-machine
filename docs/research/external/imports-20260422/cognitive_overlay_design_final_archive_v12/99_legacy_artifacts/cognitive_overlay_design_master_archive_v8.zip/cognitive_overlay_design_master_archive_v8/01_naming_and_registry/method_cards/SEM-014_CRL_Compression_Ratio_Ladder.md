# SEM-014 / CRL — Compression Ratio Ladder

## Reference label

SEM-014 / CRL — Compression Ratio Ladder

## Classification

| Field | Value |
|---|---|
| Backlog ID | H014 |
| Method code | SEM-014 |
| Short code | CRL |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Test 100%, 60%, 30%, 15%, and 5% transcript equivalents.

## Mechanism

Finds minimum viable text.

## Expected direction

Identifies optimal text density by content type.

## Failure mode

Too low loses context; too high overloads.

## Minimum viable experiment

Same clip at multiple compression ratios.

## Primary metrics

Gist recall; text dwell; effort

## Source IDs

S06; S07; S09; S10; S27
