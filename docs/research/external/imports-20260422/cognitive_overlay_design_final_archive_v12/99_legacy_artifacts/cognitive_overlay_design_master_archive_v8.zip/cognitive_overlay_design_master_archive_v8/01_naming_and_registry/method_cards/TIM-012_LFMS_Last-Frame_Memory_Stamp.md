# TIM-012 / LFMS — Last-Frame Memory Stamp

## Reference label

TIM-012 / LFMS — Last-Frame Memory Stamp

## Classification

| Field | Value |
|---|---|
| Backlog ID | H052 |
| Method code | TIM-012 |
| Short code | LFMS |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Hold final takeaway for the last 0.8–1.5 sec.

## Mechanism

Supports post-view recall and saves.

## Expected direction

Higher save/share and delayed recall.

## Failure mode

Can reduce loop smoothness.

## Minimum viable experiment

With/without final stamp.

## Primary metrics

Delayed recall; saves

## Source IDs

S03; S09
