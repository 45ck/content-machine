# SCC — Semantic Compression Captions

## Definition

Semantic Compression Captions rewrite speech into the shortest meaning-preserving phrases suitable for short-form video overlays.

## Purpose

Reduce the amount of text the viewer must process while preserving the main point, instruction, contrast, or payoff.

## Example

Spoken:

> Most people don’t fail because they lack motivation. They fail because their day has no structure.

SCC:

> Not motivation.  
> Structure.

## What SCC tests

SCC tests whether compression itself improves gist recall, action recall, and perceived ease compared with full transcript overlays.
