# GAZ-016 / SFC — Speaker-Following Captions

## Reference label

GAZ-016 / SFC — Speaker-Following Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H071 |
| Method code | GAZ-016 |
| Short code | SFC |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Move text near active speaker in multi-speaker clips.

## Mechanism

Reduces speaker identification cost.

## Expected direction

Better dialogue attribution.

## Failure mode

Motion may annoy frequent subtitle users.

## Minimum viable experiment

Bottom captions vs speaker-following.

## Primary metrics

Speaker recall; user preference

## Source IDs

S13; S14
