# AUD-001 / AUD — Audio-On Cue Mode

## Reference label

AUD-001 / AUD — Audio-On Cue Mode

## Classification

| Field | Value |
|---|---|
| Backlog ID | H106 |
| Method code | AUD-001 |
| Short code | AUD |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Rule / Mode |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

When audio is expected, overlay only cues and structure, not full language.

## Mechanism

Avoids redundancy overload.

## Expected direction

Better visual recall with similar gist.

## Failure mode

Fails if viewer is muted.

## Minimum viable experiment

Audio-on cue vs full overlay.

## Primary metrics

Visual recall; gist

## Source IDs

S05; S10
