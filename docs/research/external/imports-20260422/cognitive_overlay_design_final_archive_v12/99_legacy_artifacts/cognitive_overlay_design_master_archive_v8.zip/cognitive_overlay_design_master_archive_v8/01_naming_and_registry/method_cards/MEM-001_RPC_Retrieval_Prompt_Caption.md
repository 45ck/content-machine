# MEM-001 / RPC — Retrieval Prompt Caption

## Reference label

MEM-001 / RPC — Retrieval Prompt Caption

## Classification

| Field | Value |
|---|---|
| Backlog ID | H116 |
| Method code | MEM-001 |
| Short code | RPC |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Ask a 1-question recall prompt at the end: What reduces friction?

## Mechanism

Retrieval strengthens memory and reveals comprehension.

## Expected direction

Higher delayed recall.

## Failure mode

Prompts may reduce entertainment value.

## Minimum viable experiment

Prompt vs no prompt.

## Primary metrics

Delayed recall; saves

## Source IDs

S09; S17
