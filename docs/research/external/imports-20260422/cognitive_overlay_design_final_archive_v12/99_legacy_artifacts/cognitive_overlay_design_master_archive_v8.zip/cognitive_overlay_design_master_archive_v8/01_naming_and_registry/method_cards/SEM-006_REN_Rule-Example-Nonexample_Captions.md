# SEM-006 / REN — Rule–Example–Nonexample Captions

## Reference label

SEM-006 / REN — Rule–Example–Nonexample Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H006 |
| Method code | SEM-006 |
| Short code | REN |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Rule / Mode |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Show a rule, a good example, then a wrong example.

## Mechanism

Creates classification boundaries.

## Expected direction

Better transfer to new examples.

## Failure mode

Too slow for very short clips.

## Minimum viable experiment

Learning clip with rule-only vs rule-example-nonexample.

## Primary metrics

Transfer question; completion

## Source IDs

S06; S07; S09; S10; S27
