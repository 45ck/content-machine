# Cognitive Overlay Design Master Archive v8

This archive consolidates the full project into one organized package: the research framing, naming system, method registry, idea bank, hypotheses, experiment plans, production workflow, MVP artifacts, data templates, source notes, and original prior workbooks/reports.

## Start here

1. Read `START_HERE.md` for the fastest orientation.
2. Use `01_naming_and_registry/00_core_vocabulary.md` to reference names consistently.
3. Use `01_naming_and_registry/02_method_registry_all.md` when choosing methods to test.
4. Use `05_experiments_and_validation/02_first_pilot.md` to run the first validation cycle.
5. Use `06_production_and_mvp/01_production_workflow.md` when building actual TikTok/Reels/Shorts assets.

## Core field hierarchy

| Level | Name | Code | Meaning |
|---|---|---|---|
| Whole field | Cognitive Overlay Design | COD | Designing on-screen text, timing, placement, motion, and emphasis to improve comprehension, attention, retention, and accessibility. |
| Short-form branch | Physiological Retention Typography | PRT | Short-form/mobile overlay design based on visual physiology, attention, working memory, saliency, fatigue, and scroll behavior. |
| Method family | Semantic Compression Captioning Family | SCCF | Methods that rewrite speech into compact meaning units rather than displaying a full transcript. |
| Core method | Semantic Compression Captions | SCC | Compression-only baseline: shortest meaning-preserving phrases. |
| Named method | Bionic Compression Captioning | BCC | SCC plus operator anchors and bionic concept anchors. |
| Advanced protocol | Bionic Compression Captioning Plus | BCC+ | BCC plus gaze-safe placement, visual-load adaptation, muted-first design, micro-rest timing, and full captions. |
| Future system | Adaptive Semantic Overlay Engine | ASOE | Automation/product system that selects, places, renders, scores, and tests overlays. |

## Project law

> Do not make viewers read faster. Engineer the video so they need fewer fixations to understand more.

## Master research question

> Does semantic compression, with or without bionic anchors and adaptive placement, improve gist recall, action recall, muted comprehension, and retention compared with full transcript overlays and word-by-word dynamic captions?

## Archive structure

| Folder | Contents |
|---|---|
| `00_executive_summary` | Project overview, research position, decision rules. |
| `01_naming_and_registry` | Stable names, short codes, condition codes, method cards, families. |
| `02_core_methods_and_protocols` | Detailed docs for SCC, BCC, BCC+, DLC, ASOE, and related protocols. |
| `03_research_and_evidence` | Evidence synthesis, physiology/cognition research map, unanswered questions, source index. |
| `04_idea_bank` | Large bank of methods/hypotheses grouped by family and priority. |
| `05_experiments_and_validation` | Pilot design, experiment recipes, metrics, analysis plan. |
| `06_production_and_mvp` | Production workflow, generator guide, MVP script files. |
| `07_data_assets` | CSVs, workbooks, and reusable data assets. |
| `08_original_artifacts` | Prior generated packs and original reports preserved. |
| `09_archive_notes` | Changelog and manifest. |

## Naming rule

Use `SCC` when testing compression only. Use `BCC` only when bionic concept anchors are present. Use `BCC+` only when BCC includes gaze-safe placement, visual-load adaptation, muted-first design, micro-rests, and full closed-caption preservation.
