# RET — Platform Retention

This family contains 11 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RET-001 | HOO | Hook Card | Retention Method | Pilot first | P0 | Moderate adjacent | Use first 0.5–1.5 sec as a semantic promise. | Hook card vs no hook card. | 1s/3s hold; comments sentiment |
| RET-002 | FPR | Fast Payoff Rule | Rule / Mode | Pilot first | P0 | Moderate adjacent | Deliver the first useful idea within 2–3 seconds. | Delayed payoff vs fast payoff. | 3s hold; completion; trust |
| RET-003 | OLER | Open-Loop With Early Resolution | Retention Method | Pilot second | P1 | Speculative / direct test needed | Open a gap, resolve quickly, then deepen. | Delayed open-loop vs early-resolution. | Completion; trust |
| RET-004 | PMM | Progress Marker Microbar | Retention Method | Explore later | P2 | Moderate adjacent | Show Problem → Cause → Fix progress. | With/without progress marker. | Completion; effort |
| RET-005 | CC | Chapter Chips | Retention Method | Explore later | P2 | Moderate adjacent | Tiny labels for 30–90s clips: Setup, Mistake, Fix, Rule. | Chapter chips vs none. | Completion; sequence recall |
| RET-006 | PAY | Payoff Card | Retention Method | Pilot second | P1 | Moderate adjacent | Use final screen as a self-contained takeaway or checklist. | Payoff card vs normal ending. | Saves; recall |
| RET-007 | CERP | Comment-Eliciting Recall Prompt | Retention Method | Explore later | P2 | Speculative / direct test needed | Ask a non-trivial answer prompt tied to video concept. | Recall prompt vs CTA. | Comment quality; recall |
| RET-008 | PNT | Platform-Native Typography Variant | Retention Method | Explore later | P2 | Emerging direct evidence | Test clean professional vs TikTok-native emoji/non-standard style. | Clean vs native style. | Engagement; trust; comprehension |
| RET-009 | SRMR | Scroll-Rescue Midpoint Reset | Retention Method | Explore later | P2 | Speculative / direct test needed | At 40–60%, add a new semantic hook or map update. | Midpoint reset vs none. | Completion curve; rewatch |
| RET-010 | LCE | Loop-Compatible Ending | Retention Method | Explore later | P2 | Speculative / direct test needed | End with text that connects to first frame without hiding final meaning. | Loop ending vs hard stop. | Rewatch; recall |
| RET-011 | ERF | Ethical Retention Filter | Retention Method | Pilot first | P0 | Speculative / governance | Reject overlays that increase watch time by confusion instead of clarity. | Qualitative review + retention metrics. | Clarification comments; trust |
