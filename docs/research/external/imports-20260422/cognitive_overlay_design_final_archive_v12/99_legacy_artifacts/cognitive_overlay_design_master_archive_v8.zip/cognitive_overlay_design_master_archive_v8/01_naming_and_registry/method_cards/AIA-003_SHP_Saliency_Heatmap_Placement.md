# AIA-003 / SHP — Saliency Heatmap Placement

## Reference label

AIA-003 / SHP — Saliency Heatmap Placement

## Classification

| Field | Value |
|---|---|
| Backlog ID | H143 |
| Method code | AIA-003 |
| Short code | SHP |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | Adaptive System |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Predict likely gaze heatmaps and avoid high-conflict zones.

## Mechanism

Automates gaze-safe placement.

## Expected direction

Better visual recall and fewer occlusions.

## Failure mode

Saliency may not equal semantic importance.

## Minimum viable experiment

Fixed vs saliency-aware placement.

## Primary metrics

Visual recall; occlusion rate

## Source IDs

S12; S14
