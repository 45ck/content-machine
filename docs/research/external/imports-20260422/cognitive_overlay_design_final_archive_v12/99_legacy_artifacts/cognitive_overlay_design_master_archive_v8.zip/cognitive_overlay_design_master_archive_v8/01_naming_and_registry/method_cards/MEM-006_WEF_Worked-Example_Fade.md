# MEM-006 / WEF — Worked-Example Fade

## Reference label

MEM-006 / WEF — Worked-Example Fade

## Classification

| Field | Value |
|---|---|
| Backlog ID | H121 |
| Method code | MEM-006 |
| Short code | WEF |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Start with full labels, then fade to minimal cues as viewer learns.

## Mechanism

Supports novice-to-expert transition.

## Expected direction

Better learning across repeated clips.

## Failure mode

Requires sequence of content.

## Minimum viable experiment

Full labels vs fading labels over series.

## Primary metrics

Transfer; fatigue

## Source IDs

S09; S10
