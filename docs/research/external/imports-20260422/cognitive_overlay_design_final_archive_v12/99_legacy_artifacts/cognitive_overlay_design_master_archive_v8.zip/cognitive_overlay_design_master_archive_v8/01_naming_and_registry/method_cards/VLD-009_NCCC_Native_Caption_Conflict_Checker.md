# VLD-009 / NCCC — Native Caption Conflict Checker

## Reference label

VLD-009 / NCCC — Native Caption Conflict Checker

## Classification

| Field | Value |
|---|---|
| Backlog ID | H099 |
| Method code | VLD-009 |
| Short code | NCCC |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Avoid overlay collisions with platform auto-captions or imported captions.

## Mechanism

Separates full caption layer and semantic layer.

## Expected direction

Improves access and readability.

## Failure mode

Platforms may render differently.

## Minimum viable experiment

With/without conflict checking.

## Primary metrics

Occlusion; user complaints

## Source IDs

S01; S02; S15
