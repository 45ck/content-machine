# AIA-004 / FMHO — Face/Mouth/Hand/Object Detector

## Reference label

AIA-004 / FMHO — Face/Mouth/Hand/Object Detector

## Classification

| Field | Value |
|---|---|
| Backlog ID | H144 |
| Method code | AIA-004 |
| Short code | FMHO |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | System Module |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Detect visual regions that should not be covered.

## Mechanism

Automates safe zones.

## Expected direction

Fewer obstruction failures.

## Failure mode

Detection errors in motion/low light.

## Minimum viable experiment

Manual vs CV safe-zone detection.

## Primary metrics

Occlusion errors; readability

## Source IDs

S14; S18; S32
