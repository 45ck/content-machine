# TYP-006 / DWC — Dual-Weight Captions

## Reference label

TYP-006 / DWC — Dual-Weight Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H026 |
| Method code | TYP-006 |
| Short code | DWC |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Normal weight for context, bold for decision word.

## Mechanism

Creates hierarchy without color dependence.

## Expected direction

Better scan speed and accessibility.

## Failure mode

Too subtle on small screens.

## Minimum viable experiment

Dual weight vs uniform weight.

## Primary metrics

First fixation to keyword; recall

## Source IDs

S08; S28
