# SEM-012 / SBT — Semantic Breadcrumb Trail

## Reference label

SEM-012 / SBT — Semantic Breadcrumb Trail

## Classification

| Field | Value |
|---|---|
| Backlog ID | H012 |
| Method code | SEM-012 |
| Short code | SBT |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Display one small concept per beat that accumulates meaning.

## Mechanism

Supports continuity without sentence blocks.

## Expected direction

Better follow-through in 45–90s clips.

## Failure mode

Too many breadcrumbs distract.

## Minimum viable experiment

Breadcrumb vs independent captions.

## Primary metrics

Sequence recall; effort rating

## Source IDs

S06; S07; S09; S10; S27
