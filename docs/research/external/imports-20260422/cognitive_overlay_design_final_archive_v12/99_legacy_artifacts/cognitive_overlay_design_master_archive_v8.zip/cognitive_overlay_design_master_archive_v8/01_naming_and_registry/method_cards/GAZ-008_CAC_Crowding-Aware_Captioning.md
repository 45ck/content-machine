# GAZ-008 / CAC — Crowding-Aware Captioning

## Reference label

GAZ-008 / CAC — Crowding-Aware Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H063 |
| Method code | GAZ-008 |
| Short code | CAC |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Avoid placing text near other text, UI, or high-frequency background.

## Mechanism

Reduces peripheral clutter interference.

## Expected direction

Better readability.

## Failure mode

May force bland layouts.

## Minimum viable experiment

Crowded vs uncrowded placement.

## Primary metrics

Readability; effort

## Source IDs

S15; S28
