# RET-005 / CC — Chapter Chips

## Reference label

RET-005 / CC — Chapter Chips

## Classification

| Field | Value |
|---|---|
| Backlog ID | H160 |
| Method code | RET-005 |
| Short code | CC |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Tiny labels for 30–90s clips: Setup, Mistake, Fix, Rule.

## Mechanism

Orient viewer over longer short-form.

## Expected direction

Better retention in longer clips.

## Failure mode

Too much structure for comedy.

## Minimum viable experiment

Chapter chips vs none.

## Primary metrics

Completion; sequence recall

## Source IDs

S09; S25
