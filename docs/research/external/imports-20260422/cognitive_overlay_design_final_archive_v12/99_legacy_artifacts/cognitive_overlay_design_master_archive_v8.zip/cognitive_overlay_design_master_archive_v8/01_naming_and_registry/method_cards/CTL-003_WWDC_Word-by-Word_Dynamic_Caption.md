# CTL-003 / WWDC — Word-by-Word Dynamic Caption

## Reference label

CTL-003 / WWDC — Word-by-Word Dynamic Caption

## Classification

| Field | Value |
|---|---|
| Backlog ID | H169 |
| Method code | CTL-003 |
| Short code | WWDC |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P0 |
| Evidence grade | Control |
| Status | Backlog |

## Definition / what to try

Active word highlight following speech.

## Mechanism

Common creator-tool baseline.

## Expected direction

May perform well for rhythm; worse for learning.

## Failure mode

Forces tracking every word.

## Minimum viable experiment

Compare to semantic beats.

## Primary metrics

Gist; fatigue

## Source IDs

S19; S24
