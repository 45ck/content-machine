# TYP-012 / SCST — Shape-Coded Status Tokens

## Reference label

TYP-012 / SCST — Shape-Coded Status Tokens

## Classification

| Field | Value |
|---|---|
| Backlog ID | H032 |
| Method code | TYP-012 |
| Short code | SCST |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use small shapes/icons for warning, rule, action, proof.

## Mechanism

Adds non-color semantic cue.

## Expected direction

Faster role recognition.

## Failure mode

Icons may distract or seem childish.

## Minimum viable experiment

Icon+text vs text-only.

## Primary metrics

Role recognition time; preference

## Source IDs

S09; S28
