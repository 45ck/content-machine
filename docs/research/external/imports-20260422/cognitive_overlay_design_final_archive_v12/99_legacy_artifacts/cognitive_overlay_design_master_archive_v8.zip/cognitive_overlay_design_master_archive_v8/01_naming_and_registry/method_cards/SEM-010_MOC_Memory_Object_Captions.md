# SEM-010 / MOC — Memory Object Captions

## Reference label

SEM-010 / MOC — Memory Object Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H010 |
| Method code | SEM-010 |
| Short code | MOC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

End with a short, repeatable phrase: Systems beat mood.

## Mechanism

Creates a verbal chunk for later recall.

## Expected direction

Higher delayed recall.

## Failure mode

Can become cliché or inaccurate.

## Minimum viable experiment

With/without end memory phrase.

## Primary metrics

Delayed recall; shares

## Source IDs

S06; S07; S09; S10; S27
