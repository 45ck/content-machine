# TIM-014 / SAC — Speed-Adaptive Captions

## Reference label

TIM-014 / SAC — Speed-Adaptive Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H054 |
| Method code | TIM-014 |
| Short code | SAC |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Detect playback speed or speech rate and adjust overlay density.

## Mechanism

Personalizes load.

## Expected direction

Better across fast/slow viewers.

## Failure mode

Platform may not expose playback speed.

## Minimum viable experiment

Manual fast/slow variants.

## Primary metrics

Comprehension by speech rate

## Source IDs

S06; S30
