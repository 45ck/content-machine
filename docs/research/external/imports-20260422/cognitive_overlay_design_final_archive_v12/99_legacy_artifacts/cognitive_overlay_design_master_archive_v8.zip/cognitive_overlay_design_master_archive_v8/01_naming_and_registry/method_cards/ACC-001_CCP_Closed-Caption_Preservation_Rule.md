# ACC-001 / CCP — Closed-Caption Preservation Rule

## Reference label

ACC-001 / CCP — Closed-Caption Preservation Rule

## Classification

| Field | Value |
|---|---|
| Backlog ID | H131 |
| Method code | ACC-001 |
| Short code | CCP |
| Category | Personalization / Access |
| Family | Accessibility and Personalization |
| Class | Rule / Mode |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong requirement |
| Status | Backlog |

## Definition / what to try

Always keep full captions available when using creative overlays.

## Mechanism

Separates accessibility from retention styling.

## Expected direction

Avoids excluding DHH/muted viewers.

## Failure mode

Platform support may vary.

## Minimum viable experiment

User tests with overlay only vs dual layer.

## Primary metrics

Access rating; comprehension

## Source IDs

S01; S02
