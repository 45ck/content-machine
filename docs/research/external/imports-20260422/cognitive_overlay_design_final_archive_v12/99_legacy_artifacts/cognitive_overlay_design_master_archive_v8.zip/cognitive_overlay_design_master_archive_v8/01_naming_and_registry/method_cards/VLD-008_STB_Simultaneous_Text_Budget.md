# VLD-008 / STB — Simultaneous Text Budget

## Reference label

VLD-008 / STB — Simultaneous Text Budget

## Classification

| Field | Value |
|---|---|
| Backlog ID | H098 |
| Method code | VLD-008 |
| Short code | STB |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Rule / Mode |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Limit screen to one primary text block plus one micro-label.

## Mechanism

Keeps working memory manageable.

## Expected direction

Lower effort.

## Failure mode

May constrain complex explanations.

## Minimum viable experiment

Budgeted vs unbudgeted overlays.

## Primary metrics

Effort; recall

## Source IDs

S10; S17
