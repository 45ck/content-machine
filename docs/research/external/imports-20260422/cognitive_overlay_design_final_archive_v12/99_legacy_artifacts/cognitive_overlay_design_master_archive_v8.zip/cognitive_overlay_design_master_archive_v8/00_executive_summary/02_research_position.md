# Research Position

## Strongest claim

Cognitive Overlay Design may improve short-form comprehension by reducing unnecessary reading, increasing semantic signaling, and improving text placement/timing.

## Weakest claim

Bionic Reading alone makes people read captions faster. Current research does not support this as the central claim.

## Defensible framing

BCC is not speed-reading for video. It is a sparse semantic overlay method that uses partial-word anchors only after speech has already been compressed into a meaningful beat.

## What should be tested first

1. **SCC vs Full Transcript Overlay**: does compression improve gist/action recall?
2. **SCC vs BCC**: do bionic anchors add value beyond compression?
3. **BCC vs BCC+**: do placement and visual-load adaptation improve performance?
4. **BCC vs Heavy Bionic Control**: does sparse anchoring beat dense bionic formatting?

## Main predicted outcome

Semantic compression will likely produce most of the benefit. Bionic anchors may add a smaller effect for memory, attention, subjective clarity, or recognition. BCC+ may outperform BCC because placement and load adaptation reduce interference with the video.
