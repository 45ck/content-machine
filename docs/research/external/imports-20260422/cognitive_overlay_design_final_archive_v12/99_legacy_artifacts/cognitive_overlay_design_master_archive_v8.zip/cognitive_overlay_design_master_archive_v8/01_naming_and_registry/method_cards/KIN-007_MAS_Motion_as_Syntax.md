# KIN-007 / MAS — Motion as Syntax

## Reference label

KIN-007 / MAS — Motion as Syntax

## Classification

| Field | Value |
|---|---|
| Backlog ID | H082 |
| Method code | KIN-007 |
| Short code | MAS |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use motion type to encode grammar: contrast slides apart, cause connects.

## Mechanism

Creates visual grammar across videos.

## Expected direction

Faster recognition after repeated exposure.

## Failure mode

Requires audience learning.

## Minimum viable experiment

Consistent grammar vs random motion.

## Primary metrics

Role recognition; long-term preference

## Source IDs

S19; S27
