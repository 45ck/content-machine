# KIN-001 / LM — Logic Motion

## Reference label

KIN-001 / LM — Logic Motion

## Classification

| Field | Value |
|---|---|
| Backlog ID | H076 |
| Method code | KIN-001 |
| Short code | LM |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Animate the relation: problem enters, cause connects, fix resolves.

## Mechanism

Motion encodes structure, not decoration.

## Expected direction

Better sequence recall.

## Failure mode

Over-animation increases load.

## Minimum viable experiment

Static vs logic motion.

## Primary metrics

Sequence recall; effort

## Source IDs

S19; S09
