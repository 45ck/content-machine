# First Pilot

## Pilot goal

Run the smallest useful test to identify whether BCC should remain a core method or whether semantic compression alone does most of the work.

## Pilot design

- 6–12 videos, 15–45 seconds each.
- Categories: productivity, study/learning, fitness/health, finance/business, tutorial/demo, story/commentary.
- Conditions: FTO, KHT, SCC, BCC, BCC+, HBC, optionally NCO/WDC.
- Viewing modes: audio-on and muted.
- Participants: 30–50 for pilot; 120–250 for validation.

## Example variants

FTO: full transcript.  
KHT: full transcript with key words highlighted.  
SCC: `Not motivation. / Structure.`  
BCC: `**Not** **moti**vation. / **Struc**ture.`  
BCC+: `**Not** **moti**vation. / **Struc**ture. / Reduce **fric**tion. / Shrink the **start**.`  
HBC: heavy bionic formatting across most words.
