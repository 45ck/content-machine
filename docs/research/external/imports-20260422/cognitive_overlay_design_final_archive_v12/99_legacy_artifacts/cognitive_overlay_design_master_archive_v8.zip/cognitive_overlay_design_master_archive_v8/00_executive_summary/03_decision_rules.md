# Decision Rules

## Naming decisions

- Use **SCC** when the overlay is compression-only.
- Use **BCC** only when bionic concept anchors are present.
- Use **BCC+** only when BCC includes placement, density, muted-first, micro-rest, and full-caption layers.
- Use **DLC** when describing the architecture of full closed captions plus a separate creative overlay.
- Use **ASOE** when discussing the future automated product/system.

## Research decisions

| Result | Decision |
|---|---|
| SCC beats full transcript | Keep semantic compression as core mechanism. |
| BCC beats SCC | Keep bionic anchors as a core method feature. |
| BCC does not beat SCC | Treat bionic anchors as optional styling. |
| BCC+ beats BCC | Prioritize gaze-safe placement and visual-load adaptation. |
| Heavy bionic underperforms | Avoid dense bionic formatting except as a control. |
| Word-by-word dynamic captions underperform | Use them only for rhythm/comedy/music, not dense learning. |

## Production decisions

- If a caption exceeds 7 words, compress it.
- If text blocks mouth, eyes, hands, product, UI, or action, move it.
- If a clip cannot be understood muted, improve the semantic overlay.
- If the overlay replaces accessibility captions, the system is incomplete.
- If motion does not reveal structure, remove it.
