# AIA-009 / PSZT — Platform Safe-Zone Templates

## Reference label

AIA-009 / PSZT — Platform Safe-Zone Templates

## Classification

| Field | Value |
|---|---|
| Backlog ID | H149 |
| Method code | AIA-009 |
| Short code | PSZT |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | Adaptive System |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Reusable templates for TikTok/Reels/Shorts/Stories UI zones.

## Mechanism

Prevents UI occlusion.

## Expected direction

Higher readability across platforms.

## Failure mode

UI changes often.

## Minimum viable experiment

Template vs manual export.

## Primary metrics

Occlusion rate by platform

## Source IDs

S02; S28
