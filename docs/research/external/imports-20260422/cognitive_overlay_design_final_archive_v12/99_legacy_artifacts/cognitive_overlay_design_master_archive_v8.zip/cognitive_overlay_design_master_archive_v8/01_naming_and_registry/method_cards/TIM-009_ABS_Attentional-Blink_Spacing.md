# TIM-009 / ABS — Attentional-Blink Spacing

## Reference label

TIM-009 / ABS — Attentional-Blink Spacing

## Classification

| Field | Value |
|---|---|
| Backlog ID | H049 |
| Method code | TIM-009 |
| Short code | ABS |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Avoid presenting two critical words within 200–500 ms.

## Mechanism

Prevents rapid target competition.

## Expected direction

Better recall of second critical word.

## Failure mode

May slow high-energy edits.

## Minimum viable experiment

Critical words close vs spaced.

## Primary metrics

Second-keyword recall

## Source IDs

S24; S29
