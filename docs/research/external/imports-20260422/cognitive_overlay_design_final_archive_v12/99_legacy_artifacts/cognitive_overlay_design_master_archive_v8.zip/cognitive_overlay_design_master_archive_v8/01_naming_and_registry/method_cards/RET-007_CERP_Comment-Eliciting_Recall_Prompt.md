# RET-007 / CERP — Comment-Eliciting Recall Prompt

## Reference label

RET-007 / CERP — Comment-Eliciting Recall Prompt

## Classification

| Field | Value |
|---|---|
| Backlog ID | H162 |
| Method code | RET-007 |
| Short code | CERP |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Ask a non-trivial answer prompt tied to video concept.

## Mechanism

Turns engagement into retrieval.

## Expected direction

Higher comments and recall.

## Failure mode

Can look engagement-bait.

## Minimum viable experiment

Recall prompt vs CTA.

## Primary metrics

Comment quality; recall

## Source IDs

S09; S25
