# AIA-008 / BRAS — BCC+ Rubric Auto-Scorer

## Reference label

AIA-008 / BRAS — BCC+ Rubric Auto-Scorer

## Classification

| Field | Value |
|---|---|
| Backlog ID | H148 |
| Method code | AIA-008 |
| Short code | BRAS |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | System Module |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Score compression, anchors, placement, load, contrast, muted clarity.

## Mechanism

Standardizes human review.

## Expected direction

Better pre-publication quality.

## Failure mode

Scores may reward rules over outcomes.

## Minimum viable experiment

Rubric vs no rubric production.

## Primary metrics

Failure rate; pilot performance

## Source IDs

S02; S09; S28
