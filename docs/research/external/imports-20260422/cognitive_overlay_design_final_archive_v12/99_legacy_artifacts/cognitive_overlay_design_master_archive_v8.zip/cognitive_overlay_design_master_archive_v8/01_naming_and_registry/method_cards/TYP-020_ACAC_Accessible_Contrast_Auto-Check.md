# TYP-020 / ACAC — Accessible Contrast Auto-Check

## Reference label

TYP-020 / ACAC — Accessible Contrast Auto-Check

## Classification

| Field | Value |
|---|---|
| Backlog ID | H040 |
| Method code | TYP-020 |
| Short code | ACAC |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Auto-check caption/backplate contrast per frame.

## Mechanism

Prevents unreadable overlays.

## Expected direction

Fewer missed captions.

## Failure mode

May force ugly backplates in complex frames.

## Minimum viable experiment

Manual vs auto contrast corrected.

## Primary metrics

Readability; WCAG pass rate

## Source IDs

S28; S15
