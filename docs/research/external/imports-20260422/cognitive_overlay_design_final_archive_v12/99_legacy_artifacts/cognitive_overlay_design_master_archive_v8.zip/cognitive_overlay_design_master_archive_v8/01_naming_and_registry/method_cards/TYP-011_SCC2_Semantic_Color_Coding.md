# TYP-011 / SCC2 — Semantic Color Coding

## Reference label

TYP-011 / SCC2 — Semantic Color Coding

## Classification

| Field | Value |
|---|---|
| Backlog ID | H031 |
| Method code | TYP-011 |
| Short code | SCC2 |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Assign stable colors to roles: problem, cause, fix.

## Mechanism

Preattentive role recognition.

## Expected direction

Better sequence recall.

## Failure mode

Color alone is inaccessible; must pair with label/shape.

## Minimum viable experiment

Role color+label vs label only.

## Primary metrics

Sequence recall; accessibility rating

## Source IDs

S09; S28
