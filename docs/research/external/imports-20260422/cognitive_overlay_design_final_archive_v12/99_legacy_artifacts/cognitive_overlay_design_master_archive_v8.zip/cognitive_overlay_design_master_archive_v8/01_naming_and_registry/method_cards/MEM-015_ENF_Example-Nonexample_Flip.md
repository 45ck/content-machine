# MEM-015 / ENF — Example-Nonexample Flip

## Reference label

MEM-015 / ENF — Example-Nonexample Flip

## Classification

| Field | Value |
|---|---|
| Backlog ID | H130 |
| Method code | MEM-015 |
| Short code | ENF |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Quickly contrast a wrong and right execution.

## Mechanism

Boundary learning.

## Expected direction

Better transfer.

## Failure mode

Requires visuals to match text.

## Minimum viable experiment

Example-only vs example/nonexample.

## Primary metrics

Transfer; task accuracy

## Source IDs

S09; S10
