# GAZ-009 / NSC — Negative-Space Captions

## Reference label

GAZ-009 / NSC — Negative-Space Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H064 |
| Method code | GAZ-009 |
| Short code | NSC |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use empty background regions for semantic overlays.

## Mechanism

Increases contrast and reduces interference.

## Expected direction

Higher readability and aesthetic rating.

## Failure mode

Not every shot has negative space.

## Minimum viable experiment

Negative space vs default bottom.

## Primary metrics

Readability; visual recall

## Source IDs

S15; S28
