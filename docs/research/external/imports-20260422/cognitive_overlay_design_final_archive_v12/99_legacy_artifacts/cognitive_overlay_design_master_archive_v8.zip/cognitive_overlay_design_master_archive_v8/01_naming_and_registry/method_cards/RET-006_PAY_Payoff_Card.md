# RET-006 / PAY — Payoff Card

## Reference label

RET-006 / PAY — Payoff Card

## Classification

| Field | Value |
|---|---|
| Backlog ID | H161 |
| Method code | RET-006 |
| Short code | PAY |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use final screen as a self-contained takeaway or checklist.

## Mechanism

Creates save/share object.

## Expected direction

Higher saves and delayed recall.

## Failure mode

May reduce natural loop.

## Minimum viable experiment

Payoff card vs normal ending.

## Primary metrics

Saves; recall

## Source IDs

S09; S25
