# ACC-003 / ESM — Expert Shorthand Mode

## Reference label

ACC-003 / ESM — Expert Shorthand Mode

## Classification

| Field | Value |
|---|---|
| Backlog ID | H133 |
| Method code | ACC-003 |
| Short code | ESM |
| Category | Personalization / Access |
| Family | Accessibility and Personalization |
| Class | Rule / Mode |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use domain shorthand for expert audiences.

## Mechanism

Reduces unnecessary explanation.

## Expected direction

Higher retention for expert clips.

## Failure mode

Novices get lost.

## Minimum viable experiment

Expert vs novice overlay versions.

## Primary metrics

Comprehension by expertise

## Source IDs

S10; S17
