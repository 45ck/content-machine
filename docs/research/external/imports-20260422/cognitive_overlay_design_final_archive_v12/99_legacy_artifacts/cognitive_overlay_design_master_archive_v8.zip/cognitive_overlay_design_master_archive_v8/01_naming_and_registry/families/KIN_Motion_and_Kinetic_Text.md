# KIN — Motion and Kinetic Text

This family contains 15 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| KIN-001 | LM | Logic Motion | Motion Method | Pilot second | P1 | Moderate adjacent | Animate the relation: problem enters, cause connects, fix resolves. | Static vs logic motion. | Sequence recall; effort |
| KIN-002 | DCM | Directional Causal Motion | Motion Method | Explore later | P2 | Speculative / direct test needed | Move cause toward effect with arrow/line animation. | Text-only vs directional cause animation. | Causal recall; transfer |
| KIN-003 | KCF | Kinetic Contrast Flip | Motion Method | Explore later | P2 | Speculative / direct test needed | Visually flip from false belief to correction. | Static contrast vs flip animation. | Contrast recall; distraction |
| KIN-004 | FDA | Friction Drag Animation | Motion Method | Explore later | P3 | Speculative / direct test needed | Make the word friction move slowly or resist movement. | Static concept vs metaphor motion. | Concept recall; preference |
| KIN-005 | SAA | Snap-to-Action Animation | Motion Method | Explore later | P2 | Speculative / direct test needed | Action word snaps into place when instruction lands. | Static vs snap action. | Action recall; completion |
| KIN-006 | PRL | Progressive Reveal Ladder | Motion Method | Pilot second | P1 | Strong adjacent | Reveal sequence vertically: cue → action → reward. | All-at-once vs progressive reveal. | Sequence recall; effort |
| KIN-007 | MAS | Motion as Syntax | Motion Method | Explore later | P3 | Speculative / direct test needed | Use motion type to encode grammar: contrast slides apart, cause connects. | Consistent grammar vs random motion. | Role recognition; long-term preference |
| KIN-008 | MS | Motion Silence | Motion Method | Pilot second | P1 | Moderate adjacent | Keep key ideas static while less important transitions move. | Constant motion vs motion silence. | Recall; perceived quality |
| KIN-009 | SMP | Single Micro-Pop | Motion Method | Pilot second | P1 | Moderate adjacent | Only one word pops per beat. | One-pop vs all-word pop. | Keyword recall; effort |
| KIN-010 | DKC | De-Karaoke Captions | Motion Method | Pilot first | P0 | Strong adjacent | Replace active word-by-word highlighting with semantic beats for dense content. | Karaoke vs semantic beats. | Gist recall; effort |
| KIN-011 | OAC | Object-Attached Captions | Motion Method | Explore later | P2 | Moderate adjacent | Caption moves with object or hand only when labeling it. | Attached label vs static caption. | Task recall; gaze path |
| KIN-012 | GST | Gesture-Synced Text | Motion Method | Pilot second | P1 | Moderate adjacent | Reveal instruction exactly when hand gesture demonstrates it. | Gesture-sync vs off-sync. | Task accuracy; recall |
| KIN-013 | ZBT | Zoom-Blocked Text | Motion Method | Explore later | P2 | Speculative / direct test needed | Suppress text during major zoom/camera movement. | Text during zoom vs delayed text. | Effort; visual recall |
| KIN-014 | IFC | Impact Freeze Caption | Motion Method | Explore later | P2 | Speculative / direct test needed | Briefly freeze/slow frame for a complex takeaway. | Normal speed vs freeze caption. | Recall; completion |
| KIN-015 | MBS | Motion Budget Score | Rule / Mode | Pilot second | P1 | Moderate adjacent | Limit animated overlay events per 10 seconds. | Low/medium/high motion dose. | Effort; completion; recall |
