# Negative Control

12 ideas/hypotheses.

| ID | Idea / Hypothesis | What to try | Mechanism to test | Expected direction | Failure mode | Minimum viable experiment | Primary metrics | Evidence grade | Priority |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| H167 | Full Transcript Overlay | Use complete burned-in transcript as baseline. | Baseline for exact wording and accessibility-adjacent display. | Best exact recall, worse visual efficiency. | May overload visual channel. | Compare against compression/BCC. | Exact recall; effort | Control | P0 |
| H168 | Keyword Highlight Transcript | Highlight important words inside full transcript. | Commercial-style baseline. | Moderate improvement over full transcript. | Still contains too many words. | Compare to semantic compression. | Gist; effort | Control | P0 |
| H169 | Word-by-Word Dynamic Caption | Active word highlight following speech. | Common creator-tool baseline. | May perform well for rhythm; worse for learning. | Forces tracking every word. | Compare to semantic beats. | Gist; fatigue | Control | P0 |
| H170 | Heavy Bionic Formatting | Apply bionic partial bolding to most words. | Tests whether heavy bionic hurts. | Likely underperforms sparse anchors. | Can look novel but noisy. | Compare to BCC and compression. | Recall; saccades; effort | Negative control | P0 |
| H171 | RSVP One-Word Captions | One word at a time in same spot. | Tests speed-reading style in video context. | Likely weak for comprehension. | Suppresses parafoveal context/rereading. | Compare to semantic beats. | Comprehension; fatigue | Negative control | P1 |
| H172 | Constant Kinetic Text | Every word moves or pops. | Tests motion overload. | Likely higher attention, lower comprehension. | Motion becomes noise. | Compare to logic motion. | Recall; fatigue; retention | Negative control | P1 |
| H173 | No Overlay / Native Captions Only | Baseline platform state. | Determines value of any overlay. | May win for visual recall. | May lose muted gist. | Compare to all variants. | Gist; visual recall; retention | Control | P0 |
| H174 | Color-Only Meaning | Use color without labels/icons for semantic roles. | Accessibility negative control. | Likely failure for color-blind/low contrast contexts. | Meaning can be missed. | Compare to color+label. | Role ID; access rating | Negative control | P1 |
| H175 | Bottom-Only Placement | Always lower-third regardless of content. | Placement baseline. | Can block UI/captions/action. | Likely loses to gaze-safe placement. | Compare to gaze-safe. | Occlusion; readability | Control | P0 |
| H176 | Random Saliency Pop | Make random words visually pop. | Tests whether salience without meaning helps. | Likely harms trust/comprehension. | Misguides attention. | Compare to semantic cueing. | Gist; trust | Negative control | P1 |
| H177 | High-Density Caption Stack | Multiple overlays/captions/stickers simultaneously. | Stress test for visual crowding. | Likely high failure rate. | Overload/crowding. | Compare to budgeted text. | Readability; effort | Negative control | P1 |
| H178 | Emoji/Nonstandard Subtitle Variant | Use platform-native non-standard typography and emoji. | Tests TikTok-native engagement signal. | Could increase engagement for informal categories. | May harm accessibility/professionalism. | Compare with clean captioning by category. | Engagement; trust; comprehension | Emerging direct evidence | P2 |
