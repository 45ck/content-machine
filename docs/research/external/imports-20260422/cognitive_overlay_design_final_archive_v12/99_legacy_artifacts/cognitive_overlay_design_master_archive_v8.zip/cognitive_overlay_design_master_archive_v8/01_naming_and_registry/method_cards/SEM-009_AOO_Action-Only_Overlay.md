# SEM-009 / AOO — Action-Only Overlay

## Reference label

SEM-009 / AOO — Action-Only Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H009 |
| Method code | SEM-009 |
| Short code | AOO |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

For advice clips, show only the next action, not explanation.

## Mechanism

Turns passive consumption into instruction.

## Expected direction

Higher action recall and saves.

## Failure mode

Weak context if viewer misses why.

## Minimum viable experiment

Action-only vs explanation captions.

## Primary metrics

Action recall; saves

## Source IDs

S06; S07; S09; S10; S27
