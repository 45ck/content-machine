# TYP — Typography and Anchors

This family contains 20 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TYP-001 | BCA | Bionic Concept Anchors | Anchor / Typography Component | Pilot first | P0 | Weak / contested | Partially bold only key concept words after compression. | Semantic compression vs BCC. | Gist recall; fixation count; preference |
| TYP-002 | FOA | Full-Word Operator Anchors | Anchor / Typography Component | Pilot first | P0 | Moderate adjacent | Bold full operator words: Not, Stop, First, Less. | Operator-bold vs no bold. | Contrast recall; fixation latency |
| TYP-003 | SKH | Sparse Keyword Highlight | Anchor / Typography Component | Pilot first | P0 | Strong adjacent | Highlight only 5–15% of displayed words. | Sparse vs dense highlight. | Effort; recall; gaze distribution |
| TYP-004 | NM | Number Magnets | Anchor / Typography Component | Pilot second | P1 | Moderate adjacent | Use distinct emphasis for numbers, percentages, steps, dates. | Number-emphasis vs normal text. | Number recall; trust rating |
| TYP-005 | SLB | Semantic Line Breaks | Anchor / Typography Component | Pilot second | P1 | Strong adjacent | Break lines by meaning, not by width alone. | Natural vs arbitrary line breaks. | Effort; reading completion |
| TYP-006 | DWC | Dual-Weight Captions | Anchor / Typography Component | Pilot second | P1 | Moderate adjacent | Normal weight for context, bold for decision word. | Dual weight vs uniform weight. | First fixation to keyword; recall |
| TYP-007 | AOD | Accent Only on Delta | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Highlight only what changes from old belief to new belief. | Full highlight vs delta-only highlight. | Contrast recall |
| TYP-008 | DEF | De-Emphasis Fades | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Dull background words and keep key terms high opacity. | Opacity fade vs bold highlight. | Recall; contrast compliance |
| TYP-009 | CBU | Contrast Block Underlay | Anchor / Typography Component | Pilot second | P1 | Strong adjacent | Place text on a stable capsule/plate over busy video. | Plate vs no plate on busy backgrounds. | Readability; visual recall |
| TYP-010 | SOF | Stroke/Outline Fallback | Anchor / Typography Component | Pilot second | P1 | Moderate adjacent | Use outline/shadow only when background contrast is unstable. | Outline vs capsule vs none. | Readability; aesthetic rating |
| TYP-011 | SCC2 | Semantic Color Coding | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Assign stable colors to roles: problem, cause, fix. | Role color+label vs label only. | Sequence recall; accessibility rating |
| TYP-012 | SCST | Shape-Coded Status Tokens | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Use small shapes/icons for warning, rule, action, proof. | Icon+text vs text-only. | Role recognition time; preference |
| TYP-013 | TTT | Typeface Trust Test | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Compare clean sans, condensed bold, handwritten, meme style. | Font variants with same text. | Trust; retention; recall |
| TYP-014 | VWAR | Variable Weight Attention Ramp | Anchor / Typography Component | Explore later | P3 | Speculative / direct test needed | Gradually increase weight on words as they become relevant. | Static bold vs weight ramp. | Smoothness; recall; gaze |
| TYP-015 | CR | Capitalization Rhythm | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Use case intentionally: title case for labels, sentence case for ideas. | Case variants. | Effort; retention |
| TYP-016 | PAT | Punctuation as Timing Cue | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Use periods, arrows, colons, and line breaks as rhythm markers. | Punctuated vs non-punctuated versions. | Comprehension; engagement |
| TYP-017 | IWP | Icon+Word Pairing | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Pair a simple icon with a concept word: friction, trigger, proof. | Word-only vs icon+word. | Delayed recall; confusion |
| TYP-018 | BDG | Bionic Density Gradient | Anchor / Typography Component | Pilot first | P0 | Weak / contested | Test no bionic, one word bionic, all concepts bionic, all words bionic. | Dose-response bionic experiment. | Recall; saccades; effort |
| TYP-019 | TSH | Trust-Safe Highlighting | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Avoid styling that exaggerates uncertain claims. | Overstated vs trust-safe styling. | Trust; comprehension; comments |
| TYP-020 | ACAC | Accessible Contrast Auto-Check | Anchor / Typography Component | Pilot first | P0 | Strong adjacent | Auto-check caption/backplate contrast per frame. | Manual vs auto contrast corrected. | Readability; WCAG pass rate |
