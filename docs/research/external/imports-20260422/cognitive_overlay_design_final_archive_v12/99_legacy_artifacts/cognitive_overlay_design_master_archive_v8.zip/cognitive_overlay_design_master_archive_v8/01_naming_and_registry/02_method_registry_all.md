# Full Method Registry

| Method Code | Short Code | Canonical Name | Category | Class | Phase | Priority | Evidence Grade | Definition / What to try |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SEM-001 | SCC | Semantic Compression Captions | Semantic / Compression | Method | Pilot first | P0 | Strong adjacent | Rewrite spoken sentences into shortest meaning-preserving phrases. |
| SEM-002 | PEO | Proposition Extraction Overlay | Semantic / Compression | Method | Pilot first | P0 | Moderate adjacent | Show the underlying claim rather than the literal words. |
| SEM-003 | OFC | Operator-First Captioning | Semantic / Compression | Method | Pilot first | P0 | Moderate adjacent | Begin overlay with logical operator: Not, Stop, Less, First, Then. |
| SEM-004 | CPC | Contrast Pair Cards | Semantic / Compression | Method | Pilot second | P1 | Moderate adjacent | Use two-line contrasts: Not X / Y, Stop X / Start Y. |
| SEM-005 | PCFB | Problem–Cause–Fix Beat Cards | Semantic / Compression | Method | Pilot first | P0 | Strong adjacent | Display three labels across the clip: Problem, Cause, Fix. |
| SEM-006 | REN | Rule–Example–Nonexample Captions | Semantic / Compression | Rule / Mode | Explore later | P2 | Moderate adjacent | Show a rule, a good example, then a wrong example. |
| SEM-007 | CEP | Claim–Evidence–Payoff Overlay | Semantic / Compression | Method | Explore later | P2 | Moderate adjacent | Label claim, proof, and takeaway as separate beats. |
| SEM-008 | TFO | Takeaway-First Overlay | Semantic / Compression | Method | Pilot second | P1 | Moderate adjacent | Show the final point in the first second, then explain. |
| SEM-009 | AOO | Action-Only Overlay | Semantic / Compression | Method | Pilot second | P1 | Moderate adjacent | For advice clips, show only the next action, not explanation. |
| SEM-010 | MOC | Memory Object Captions | Semantic / Compression | Method | Pilot second | P1 | Moderate adjacent | End with a short, repeatable phrase: Systems beat mood. |
| SEM-011 | MVC | Minimal Verb Captioning | Semantic / Compression | Method | Explore later | P2 | Speculative / direct test needed | Preserve verbs over nouns when showing fewer words. |
| SEM-012 | SBT | Semantic Breadcrumb Trail | Semantic / Compression | Method | Explore later | P2 | Moderate adjacent | Display one small concept per beat that accumulates meaning. |
| SEM-013 | CLC | Concept Ladder Captions | Semantic / Compression | Method | Explore later | P2 | Moderate adjacent | Move from concrete to abstract: shoes → start → habit. |
| SEM-014 | CRL | Compression Ratio Ladder | Semantic / Compression | Method | Pilot first | P0 | Strong adjacent | Test 100%, 60%, 30%, 15%, and 5% transcript equivalents. |
| SEM-015 | KMC | Keyword-to-Microphrase Conversion | Semantic / Compression | Method | Pilot second | P1 | Moderate adjacent | Convert isolated keywords into 2–4 word phrase chunks. |
| SEM-016 | OIOS | One Idea, One Screen Rule | Semantic / Compression | Rule / Mode | Pilot first | P0 | Strong adjacent | Never show two unrelated ideas in one overlay event. |
| SEM-017 | GET | Gist vs Exact Mode Toggle | Semantic / Compression | Rule / Mode | Pilot first | P0 | Strong adjacent | Use gist overlay for retention, closed captions for exact speech. |
| SEM-018 | AFC | Anti-Filler Captioning | Semantic / Compression | Method | Pilot second | P1 | Moderate adjacent | Remove basically, actually, kind of, really, and redundant phrases. |
| SEM-019 | CT | Certainty Tags | Semantic / Compression | Method | Explore later | P2 | Speculative / direct test needed | Mark claims as Rule, Hypothesis, Example, Warning, Tested. |
| SEM-020 | QTA | Question-to-Answer Captions | Semantic / Compression | Method | Pilot second | P1 | Moderate adjacent | Open with a concise question, answer one beat later. |
| TYP-001 | BCA | Bionic Concept Anchors | Typography / Anchors | Anchor / Typography Component | Pilot first | P0 | Weak / contested | Partially bold only key concept words after compression. |
| TYP-002 | FOA | Full-Word Operator Anchors | Typography / Anchors | Anchor / Typography Component | Pilot first | P0 | Moderate adjacent | Bold full operator words: Not, Stop, First, Less. |
| TYP-003 | SKH | Sparse Keyword Highlight | Typography / Anchors | Anchor / Typography Component | Pilot first | P0 | Strong adjacent | Highlight only 5–15% of displayed words. |
| TYP-004 | NM | Number Magnets | Typography / Anchors | Anchor / Typography Component | Pilot second | P1 | Moderate adjacent | Use distinct emphasis for numbers, percentages, steps, dates. |
| TYP-005 | SLB | Semantic Line Breaks | Typography / Anchors | Anchor / Typography Component | Pilot second | P1 | Strong adjacent | Break lines by meaning, not by width alone. |
| TYP-006 | DWC | Dual-Weight Captions | Typography / Anchors | Anchor / Typography Component | Pilot second | P1 | Moderate adjacent | Normal weight for context, bold for decision word. |
| TYP-007 | AOD | Accent Only on Delta | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Highlight only what changes from old belief to new belief. |
| TYP-008 | DEF | De-Emphasis Fades | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Dull background words and keep key terms high opacity. |
| TYP-009 | CBU | Contrast Block Underlay | Typography / Anchors | Anchor / Typography Component | Pilot second | P1 | Strong adjacent | Place text on a stable capsule/plate over busy video. |
| TYP-010 | SOF | Stroke/Outline Fallback | Typography / Anchors | Anchor / Typography Component | Pilot second | P1 | Moderate adjacent | Use outline/shadow only when background contrast is unstable. |
| TYP-011 | SCC2 | Semantic Color Coding | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Assign stable colors to roles: problem, cause, fix. |
| TYP-012 | SCST | Shape-Coded Status Tokens | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Use small shapes/icons for warning, rule, action, proof. |
| TYP-013 | TTT | Typeface Trust Test | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Compare clean sans, condensed bold, handwritten, meme style. |
| TYP-014 | VWAR | Variable Weight Attention Ramp | Typography / Anchors | Anchor / Typography Component | Explore later | P3 | Speculative / direct test needed | Gradually increase weight on words as they become relevant. |
| TYP-015 | CR | Capitalization Rhythm | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Use case intentionally: title case for labels, sentence case for ideas. |
| TYP-016 | PAT | Punctuation as Timing Cue | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Use periods, arrows, colons, and line breaks as rhythm markers. |
| TYP-017 | IWP | Icon+Word Pairing | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Moderate adjacent | Pair a simple icon with a concept word: friction, trigger, proof. |
| TYP-018 | BDG | Bionic Density Gradient | Typography / Anchors | Anchor / Typography Component | Pilot first | P0 | Weak / contested | Test no bionic, one word bionic, all concepts bionic, all words bionic. |
| TYP-019 | TSH | Trust-Safe Highlighting | Typography / Anchors | Anchor / Typography Component | Explore later | P2 | Speculative / direct test needed | Avoid styling that exaggerates uncertain claims. |
| TYP-020 | ACAC | Accessible Contrast Auto-Check | Typography / Anchors | Anchor / Typography Component | Pilot first | P0 | Strong adjacent | Auto-check caption/backplate contrast per frame. |
| TIM-001 | PSP | Predictive Semantic Priming | Timing / Rhythm | Timing Method | Pilot first | P0 | Moderate adjacent | Show compressed meaning 200–400 ms before the speaker lands it. |
| TIM-002 | SLSB | Sync-Locked Semantic Beat | Timing / Rhythm | Timing Method | Pilot second | P1 | Strong adjacent | Show the overlay exactly when the semantic beat is spoken. |
| TIM-003 | PCC | Post-Cue Confirmation | Timing / Rhythm | Timing Method | Explore later | P2 | Moderate adjacent | Display a summary immediately after the sentence. |
| TIM-004 | PWC | Pause-Window Captioning | Timing / Rhythm | Timing Method | Pilot second | P1 | Moderate adjacent | Place heavier text only during speech pauses or low-action moments. |
| TIM-005 | BAC | Breath-Aligned Captions | Timing / Rhythm | Timing Method | Explore later | P2 | Speculative / direct test needed | Use natural speech breaths to segment caption events. |
| TIM-006 | CLR | Cut-Locked Reveal | Timing / Rhythm | Timing Method | Explore later | P2 | Moderate adjacent | Reveal caption on visual cut or camera movement boundary. |
| TIM-007 | MEG | Minimum Exposure Guardrail | Timing / Rhythm | Timing Method | Pilot first | P0 | Strong adjacent | No caption shorter than 0.8 sec except one-word impact beats. |
| TIM-008 | MRR | Micro-Rest Rhythm | Timing / Rhythm | Timing Method | Pilot second | P1 | Moderate adjacent | Insert brief no-text gaps between semantic beats. |
| TIM-009 | ABS | Attentional-Blink Spacing | Timing / Rhythm | Timing Method | Explore later | P2 | Moderate adjacent | Avoid presenting two critical words within 200–500 ms. |
| TIM-010 | TMD | Tempo-Matched Density | Timing / Rhythm | Timing Method | Pilot second | P1 | Strong adjacent | Decrease word count as speech tempo rises. |
| TIM-011 | CRP | Caption Refractory Period | Timing / Rhythm | Timing Method | Explore later | P2 | Speculative / direct test needed | After an emphasized word, hold visual quiet for a beat. |
| TIM-012 | LFMS | Last-Frame Memory Stamp | Timing / Rhythm | Timing Method | Pilot second | P1 | Moderate adjacent | Hold final takeaway for the last 0.8–1.5 sec. |
| TIM-013 | LCC | Loop Callback Caption | Timing / Rhythm | Timing Method | Explore later | P2 | Speculative / direct test needed | End with a phrase that reinterprets the opening hook. |
| TIM-014 | SAC | Speed-Adaptive Captions | Timing / Rhythm | Timing Method | Explore later | P3 | Speculative / direct test needed | Detect playback speed or speech rate and adjust overlay density. |
| TIM-015 | OBS | On-Beat Silence | Timing / Rhythm | Timing Method | Explore later | P2 | Moderate adjacent | Use no text during important sounds, laughs, or music drops. |
| GAZ-001 | MSC | Mouth-Safe Captioning | Placement / Gaze | Placement Method | Pilot first | P0 | Strong adjacent | Never cover the mouth during speech-heavy clips. |
| GAZ-002 | ESC | Eye-Safe Captioning | Placement / Gaze | Placement Method | Pilot second | P1 | Moderate adjacent | Avoid covering eyes in emotional/storytelling clips. |
| GAZ-003 | ASC | Action-Safe Captioning | Placement / Gaze | Placement Method | Pilot first | P0 | Strong adjacent | Avoid hands, products, joints, cursor, and key action path. |
| GAZ-004 | ONL | Object-Near Labels | Placement / Gaze | Placement Method | Pilot second | P1 | Moderate adjacent | Place short labels next to the relevant object instead of bottom captions. |
| GAZ-005 | USZT | UI-Safe Zone Templates | Placement / Gaze | Placement Method | Pilot first | P0 | Strong practical / direct test needed | Define TikTok/Reels/Shorts danger zones and avoid them. |
| GAZ-006 | SAP | Saliency-Avoiding Placement | Placement / Gaze | Placement Method | Pilot second | P1 | Moderate adjacent | Place text away from predicted high-saliency regions unless it is a label. |
| GAZ-007 | MMP | Meaning-Map Placement | Placement / Gaze | Placement Method | Pilot second | P1 | Moderate adjacent | Place text where it supports the semantic region of the scene. |
| GAZ-008 | CAC | Crowding-Aware Captioning | Placement / Gaze | Placement Method | Pilot first | P0 | Strong adjacent | Avoid placing text near other text, UI, or high-frequency background. |
| GAZ-009 | NSC | Negative-Space Captions | Placement / Gaze | Placement Method | Pilot second | P1 | Moderate adjacent | Use empty background regions for semantic overlays. |
| GAZ-010 | SZTH | Shoulder-Zone Talking Head Overlay | Placement / Gaze | Placement Method | Pilot second | P1 | Speculative / direct test needed | Place captions near upper chest/shoulder, away from mouth/eyes/UI. |
| GAZ-011 | SRTL | Screen-Recording Target Labels | Placement / Gaze | Placement Method | Pilot second | P1 | Moderate adjacent | Place labels near the cursor/control being discussed. |
| GAZ-012 | PHC | Product Halo Captions | Placement / Gaze | Placement Method | Explore later | P2 | Speculative / direct test needed | Place short labels in a ring around product without covering it. |
| GAZ-013 | FAP | Foveal Anchor + Peripheral Cue | Placement / Gaze | Placement Method | Explore later | P2 | Moderate adjacent | Put readable text centrally; use peripheral arrows/icons for orientation. |
| GAZ-014 | DRAR | Dynamic Reflow Around ROI | Placement / Gaze | Placement Method | Pilot second | P1 | Moderate adjacent | Move captions frame-by-frame around faces/hands/products. |
| GAZ-015 | STAP | Shot-Type-Aware Placement | Placement / Gaze | Placement Method | Pilot second | P1 | Speculative / direct test needed | Use different placement rules for talking head, demo, screen recording, story. |
| GAZ-016 | SFC | Speaker-Following Captions | Placement / Gaze | Placement Method | Explore later | P2 | Moderate adjacent | Move text near active speaker in multi-speaker clips. |
| GAZ-017 | ELT | Eye-Line Triangle Rule | Placement / Gaze | Rule / Mode | Explore later | P2 | Speculative / direct test needed | Place overlay within triangle between speaker’s eyes, hands/object, and center. |
| GAZ-018 | PCR | Platform Crop Repositioning | Placement / Gaze | Placement Method | Pilot second | P1 | Strong practical / direct test needed | Automatically reposition overlays for TikTok, Reels, Shorts, YouTube preview. |
| GAZ-019 | CCD | Caption Collision Detector | Placement / Gaze | Placement Method | Pilot first | P0 | Strong practical / direct test needed | Detect overlap with native captions, stickers, captions, and UI. |
| GAZ-020 | GRW | Gaze Return Windows | Placement / Gaze | Placement Method | Explore later | P2 | Moderate adjacent | After text appears, reserve moments where nothing blocks the face/object. |
| KIN-001 | LM | Logic Motion | Motion / Kinetic | Motion Method | Pilot second | P1 | Moderate adjacent | Animate the relation: problem enters, cause connects, fix resolves. |
| KIN-002 | DCM | Directional Causal Motion | Motion / Kinetic | Motion Method | Explore later | P2 | Speculative / direct test needed | Move cause toward effect with arrow/line animation. |
| KIN-003 | KCF | Kinetic Contrast Flip | Motion / Kinetic | Motion Method | Explore later | P2 | Speculative / direct test needed | Visually flip from false belief to correction. |
| KIN-004 | FDA | Friction Drag Animation | Motion / Kinetic | Motion Method | Explore later | P3 | Speculative / direct test needed | Make the word friction move slowly or resist movement. |
| KIN-005 | SAA | Snap-to-Action Animation | Motion / Kinetic | Motion Method | Explore later | P2 | Speculative / direct test needed | Action word snaps into place when instruction lands. |
| KIN-006 | PRL | Progressive Reveal Ladder | Motion / Kinetic | Motion Method | Pilot second | P1 | Strong adjacent | Reveal sequence vertically: cue → action → reward. |
| KIN-007 | MAS | Motion as Syntax | Motion / Kinetic | Motion Method | Explore later | P3 | Speculative / direct test needed | Use motion type to encode grammar: contrast slides apart, cause connects. |
| KIN-008 | MS | Motion Silence | Motion / Kinetic | Motion Method | Pilot second | P1 | Moderate adjacent | Keep key ideas static while less important transitions move. |
| KIN-009 | SMP | Single Micro-Pop | Motion / Kinetic | Motion Method | Pilot second | P1 | Moderate adjacent | Only one word pops per beat. |
| KIN-010 | DKC | De-Karaoke Captions | Motion / Kinetic | Motion Method | Pilot first | P0 | Strong adjacent | Replace active word-by-word highlighting with semantic beats for dense content. |
| KIN-011 | OAC | Object-Attached Captions | Motion / Kinetic | Motion Method | Explore later | P2 | Moderate adjacent | Caption moves with object or hand only when labeling it. |
| KIN-012 | GST | Gesture-Synced Text | Motion / Kinetic | Motion Method | Pilot second | P1 | Moderate adjacent | Reveal instruction exactly when hand gesture demonstrates it. |
| KIN-013 | ZBT | Zoom-Blocked Text | Motion / Kinetic | Motion Method | Explore later | P2 | Speculative / direct test needed | Suppress text during major zoom/camera movement. |
| KIN-014 | IFC | Impact Freeze Caption | Motion / Kinetic | Motion Method | Explore later | P2 | Speculative / direct test needed | Briefly freeze/slow frame for a complex takeaway. |
| KIN-015 | MBS | Motion Budget Score | Motion / Kinetic | Rule / Mode | Pilot second | P1 | Moderate adjacent | Limit animated overlay events per 10 seconds. |
| VLD-001 | VLAW | Visual-Load Adaptive Word Count | Visual Load / Clutter | Load-Control Method | Pilot first | P0 | Strong adjacent | Use fewer overlay words when the frame is visually busy. |
| VLD-002 | DML | Demo Minimal Labels | Visual Load / Clutter | Load-Control Method | Pilot second | P1 | Moderate adjacent | During demonstrations, show only verbs or labels: twist, lock, pull. |
| VLD-003 | BBAP | Busy Background Auto-Plate | Visual Load / Clutter | Load-Control Method | Pilot second | P1 | Strong adjacent | Add a soft plate behind text only when background is complex. |
| VLD-004 | BDW | Background Dimming Window | Visual Load / Clutter | Load-Control Method | Explore later | P2 | Moderate adjacent | Temporarily dim non-essential background behind text. |
| VLD-005 | VCS | Visual Complexity Score | Visual Load / Clutter | Load-Control Method | Pilot second | P1 | Speculative / direct test needed | Compute frame-level complexity and use it to regulate overlay density. |
| VLD-006 | CCD2 | Caption Conflict Detector | Visual Load / Clutter | Load-Control Method | Pilot first | P0 | Strong practical / direct test needed | Detect when too many text layers exist simultaneously. |
| VLD-007 | HMS | High-Motion Suppression | Visual Load / Clutter | Load-Control Method | Pilot second | P1 | Moderate adjacent | Reduce caption animation and density during high visual motion. |
| VLD-008 | STB | Simultaneous Text Budget | Visual Load / Clutter | Rule / Mode | Pilot first | P0 | Strong adjacent | Limit screen to one primary text block plus one micro-label. |
| VLD-009 | NCCC | Native Caption Conflict Checker | Visual Load / Clutter | Load-Control Method | Pilot first | P0 | Strong practical / direct test needed | Avoid overlay collisions with platform auto-captions or imported captions. |
| VLD-010 | BPD | Background Pattern Detector | Visual Load / Clutter | Load-Control Method | Explore later | P2 | Moderate adjacent | Flag stripes, grids, leaves, and high-frequency textures behind text. |
| VLD-011 | FLCC | Frame-Level Contrast Correction | Visual Load / Clutter | Load-Control Method | Pilot first | P0 | Strong adjacent | Auto adjust text/backplate contrast per frame. |
| VLD-012 | TDB | Text Dwell Budget | Visual Load / Clutter | Rule / Mode | Pilot second | P1 | Speculative / direct test needed | Limit total seconds of on-screen text per 10 seconds of video. |
| VLD-013 | DVG | Density by Viewer Goal | Visual Load / Clutter | Load-Control Method | Explore later | P2 | Speculative / direct test needed | Use heavier overlays for learning clips, lighter for entertainment clips. |
| VLD-014 | CSEF | Caption Safe Empty Frames | Visual Load / Clutter | Load-Control Method | Explore later | P2 | Speculative / direct test needed | Intentionally reserve clean frames for text instead of adding text anywhere. |
| VLD-015 | RFL | Readability Failure Log | Visual Load / Clutter | Load-Control Method | Pilot second | P1 | Strong practical / direct test needed | Annotate every point where a tester missed or struggled with text. |
| AUD-001 | AUD | Audio-On Cue Mode | Sound / Multimodal | Rule / Mode | Pilot second | P1 | Strong adjacent | When audio is expected, overlay only cues and structure, not full language. |
| AUD-002 | MFM | Muted-First Mode | Sound / Multimodal | Rule / Mode | Pilot first | P0 | Strong adjacent | Overlay carries enough meaning without sound. |
| AUD-003 | DLC | Dual-Layer Captioning | Sound / Multimodal | Multimodal Method | Pilot first | P0 | Strong adjacent | Full closed captions plus separate semantic overlay. |
| AUD-004 | NSS | Non-Speech Sound Cues | Sound / Multimodal | Multimodal Method | Pilot first | P0 | Strong requirement | Show [laughter], [music rises], [door slam] only when meaningful. |
| AUD-005 | PAE | Prosody-Aware Emphasis | Sound / Multimodal | Multimodal Method | Explore later | P2 | Moderate adjacent | Map speaker emphasis/intensity to controlled text weight or motion. |
| AUD-006 | SAE | Silence as Emphasis | Sound / Multimodal | Multimodal Method | Explore later | P2 | Speculative / direct test needed | Use no overlay during silence or facial reaction, then land a short caption. |
| AUD-007 | ACT | Audio Clarity Trigger | Sound / Multimodal | Multimodal Method | Pilot second | P1 | Moderate adjacent | If background music/noise is high, increase caption completeness. |
| AUD-008 | RRC | Rhythm-Respecting Captions | Sound / Multimodal | Multimodal Method | Explore later | P2 | Speculative / direct test needed | Avoid text changes on every music beat unless text is music/lyric content. |
| AUD-009 | TI | Tone Icons | Sound / Multimodal | Multimodal Method | Explore later | P3 | Speculative / direct test needed | Use small icons for sarcasm, warning, encouragement only when tone is ambiguous. |
| AUD-010 | HCV | Haptic Caption Variant | Sound / Multimodal | Multimodal Method | Explore later | P3 | Speculative / cutting-edge | For AR/wearables, use vibration patterns for emotion or emphasis. |
| MEM-001 | RPC | Retrieval Prompt Caption | Memory / Learning | Learning Method | Pilot second | P1 | Strong adjacent | Ask a 1-question recall prompt at the end: What reduces friction? |
| MEM-002 | PP | Prediction Prompt | Memory / Learning | Learning Method | Explore later | P2 | Moderate adjacent | Before solution, ask viewer to predict cause/fix. |
| MEM-003 | QCE | Quick Check End Card | Memory / Learning | Learning Method | Explore later | P2 | Moderate adjacent | End with micro quiz: Motivation or structure? |
| MEM-004 | SRAS | Spaced Recap Across Series | Memory / Learning | Learning Method | Explore later | P2 | Strong adjacent | Repeat same memory phrase across multiple videos with variation. |
| MEM-005 | TBSM | Three-Beat Schema Map | Memory / Learning | Learning Method | Pilot second | P1 | Strong adjacent | Always use a small visual map: Problem → Cause → Fix. |
| MEM-006 | WEF | Worked-Example Fade | Memory / Learning | Learning Method | Explore later | P3 | Moderate adjacent | Start with full labels, then fade to minimal cues as viewer learns. |
| MEM-007 | ANA | Analogy Overlay | Memory / Learning | Learning Method | Explore later | P2 | Moderate adjacent | Add one compressed analogy for abstract ideas. |
| MEM-008 | MCM | Mini Concept Map | Memory / Learning | Learning Method | Explore later | P2 | Moderate adjacent | Show 2–4 nodes connected during complex explanations. |
| MEM-009 | BAS | Before/After State Card | Memory / Learning | Learning Method | Explore later | P2 | Speculative / direct test needed | Show old state → new state visually/textually. |
| MEM-010 | ARP | Active Recall Pause | Memory / Learning | Learning Method | Explore later | P2 | Moderate adjacent | Pause briefly after an instruction before giving answer/example. |
| MEM-011 | SALS | Save Cue as Learning Signal | Memory / Learning | Learning Method | Explore later | P2 | Speculative / direct test needed | Use a save-worthy rule card, not a begging call-to-action. |
| MEM-012 | MC | Mnemonic Compression | Memory / Learning | Learning Method | Explore later | P3 | Speculative / direct test needed | Turn takeaways into memorable parallel structures or rhymes. |
| MEM-013 | ACO | Action Checklist Overlay | Memory / Learning | Learning Method | Pilot second | P1 | Moderate adjacent | Convert advice into 2–3 checklist items at end. |
| MEM-014 | EDM | Error Diagnosis Matrix | Memory / Learning | Learning Method | Explore later | P3 | Speculative / direct test needed | Show two-axis quick diagnosis: effort high / clarity low. |
| MEM-015 | ENF | Example-Nonexample Flip | Memory / Learning | Learning Method | Explore later | P2 | Moderate adjacent | Quickly contrast a wrong and right execution. |
| ACC-001 | CCP | Closed-Caption Preservation Rule | Personalization / Access | Rule / Mode | Pilot first | P0 | Strong requirement | Always keep full captions available when using creative overlays. |
| ACC-002 | LSM | L2 Simplified Mode | Personalization / Access | Rule / Mode | Explore later | P2 | Moderate adjacent | Use simpler vocabulary and more context for second-language viewers. |
| ACC-003 | ESM | Expert Shorthand Mode | Personalization / Access | Rule / Mode | Explore later | P2 | Moderate adjacent | Use domain shorthand for expert audiences. |
| ACC-004 | NLM | Novice Label Mode | Personalization / Access | Rule / Mode | Pilot second | P1 | Strong adjacent | Add labels for unfamiliar concepts before compressing heavily. |
| ACC-005 | DFV | Dyslexia-Friendly Variant Test | Personalization / Access | Access / Personalization Method | Explore later | P3 | Speculative / direct test needed | Compare bionic, LARF-like annotation, spacing, and plain compression for dyslexic viewers. |
| ACC-006 | LMM | Low-Motion Mode | Personalization / Access | Rule / Mode | Pilot second | P1 | Moderate adjacent | Provide a static/low-animation overlay for viewers sensitive to motion. |
| ACC-007 | OVD | Older Viewer Duration Mode | Personalization / Access | Rule / Mode | Explore later | P2 | Speculative / direct test needed | Increase caption duration and font size for older viewers. |
| ACC-008 | CBSC | Color-Blind Safe Coding | Personalization / Access | Access / Personalization Method | Pilot first | P0 | Strong requirement | Never rely on color alone; pair with labels/icons/shape. |
| ACC-009 | RSA | Reader-Speed Adaptive Mode | Personalization / Access | Rule / Mode | Explore later | P3 | Speculative / future | Allow overlays to persist longer or simplify if viewer often pauses/rewatches. |
| ACC-010 | VSA | Viewer-State Adaptive Mode | Personalization / Access | Rule / Mode | Explore later | P3 | Speculative / future | Switch overlay mode based on audio-on/off, device, language, and content category. |
| AIA-001 | SBE | Semantic Beat Extractor | AI / Adaptive | System Module | Pilot second | P1 | Speculative / direct test needed | LLM extracts proposition, role, and beat boundaries from transcript. |
| AIA-002 | GEN | Overlay Variant Generator | AI / Adaptive | System Module | Pilot second | P1 | Strong practical / direct test needed | Auto-generates transcript, keyword, compression, BCC, BCC+, and controls. |
| AIA-003 | SHP | Saliency Heatmap Placement | AI / Adaptive | Adaptive System | Pilot second | P1 | Moderate adjacent | Predict likely gaze heatmaps and avoid high-conflict zones. |
| AIA-004 | FMHO | Face/Mouth/Hand/Object Detector | AI / Adaptive | System Module | Pilot first | P0 | Strong practical / direct test needed | Detect visual regions that should not be covered. |
| AIA-005 | VLP | Visual Load Predictor | AI / Adaptive | System Module | Pilot second | P1 | Speculative / direct test needed | Estimate per-frame visual complexity to choose word count. |
| AIA-006 | GSWE | Gaze Simulation Without Eye Tracker | AI / Adaptive | Adaptive System | Explore later | P2 | Speculative / direct test needed | Use saliency/meaning maps to simulate likely gaze conflict. |
| AIA-007 | ABG | Automatic A/B Generator | AI / Adaptive | System Module | Pilot second | P1 | Strong practical / direct test needed | Generate and track variants across platforms. |
| AIA-008 | BRAS | BCC+ Rubric Auto-Scorer | AI / Adaptive | System Module | Pilot second | P1 | Moderate adjacent | Score compression, anchors, placement, load, contrast, muted clarity. |
| AIA-009 | PSZT | Platform Safe-Zone Templates | AI / Adaptive | Adaptive System | Pilot first | P0 | Strong practical / direct test needed | Reusable templates for TikTok/Reels/Shorts/Stories UI zones. |
| AIA-010 | CRO | Compression Ratio Optimizer | AI / Adaptive | System Module | Explore later | P2 | Speculative / future | Suggest percent transcript to display based on speech rate/visual load. |
| AIA-011 | RWET | Remote Webcam Eye-Tracking Pilot | AI / Adaptive | Adaptive System | Explore later | P3 | Speculative / direct test needed | Use webcam gaze estimation for rough large-sample placement tests. |
| AIA-012 | MPFE | Meaning-Per-Fixation Estimator | AI / Adaptive | Adaptive System | Explore later | P3 | Speculative / future | Combine recall results and gaze/text dwell to estimate efficiency. |
| AIA-013 | AR | Adaptive Renderer | AI / Adaptive | System Module | Explore later | P2 | Speculative / future | Renders overlays based on detected shot type and visual load. |
| AIA-014 | HLE | Human-in-the-Loop Editor | AI / Adaptive | Adaptive System | Pilot first | P0 | Strong practical / direct test needed | AI proposes; editor approves proposition, anchor, placement, timing. |
| AIA-015 | SRNG | Source/Risk Note Generator | AI / Adaptive | System Module | Explore later | P2 | Speculative / direct test needed | For research/health/finance clips, overlay flags if claim is advice, evidence, or speculation. |
| RET-001 | HOO | Hook Card | Platform / Retention | Retention Method | Pilot first | P0 | Moderate adjacent | Use first 0.5–1.5 sec as a semantic promise. |
| RET-002 | FPR | Fast Payoff Rule | Platform / Retention | Rule / Mode | Pilot first | P0 | Moderate adjacent | Deliver the first useful idea within 2–3 seconds. |
| RET-003 | OLER | Open-Loop With Early Resolution | Platform / Retention | Retention Method | Pilot second | P1 | Speculative / direct test needed | Open a gap, resolve quickly, then deepen. |
| RET-004 | PMM | Progress Marker Microbar | Platform / Retention | Retention Method | Explore later | P2 | Moderate adjacent | Show Problem → Cause → Fix progress. |
| RET-005 | CC | Chapter Chips | Platform / Retention | Retention Method | Explore later | P2 | Moderate adjacent | Tiny labels for 30–90s clips: Setup, Mistake, Fix, Rule. |
| RET-006 | PAY | Payoff Card | Platform / Retention | Retention Method | Pilot second | P1 | Moderate adjacent | Use final screen as a self-contained takeaway or checklist. |
| RET-007 | CERP | Comment-Eliciting Recall Prompt | Platform / Retention | Retention Method | Explore later | P2 | Speculative / direct test needed | Ask a non-trivial answer prompt tied to video concept. |
| RET-008 | PNT | Platform-Native Typography Variant | Platform / Retention | Retention Method | Explore later | P2 | Emerging direct evidence | Test clean professional vs TikTok-native emoji/non-standard style. |
| RET-009 | SRMR | Scroll-Rescue Midpoint Reset | Platform / Retention | Retention Method | Explore later | P2 | Speculative / direct test needed | At 40–60%, add a new semantic hook or map update. |
| RET-010 | LCE | Loop-Compatible Ending | Platform / Retention | Retention Method | Explore later | P2 | Speculative / direct test needed | End with text that connects to first frame without hiding final meaning. |
| RET-011 | ERF | Ethical Retention Filter | Platform / Retention | Retention Method | Pilot first | P0 | Speculative / governance | Reject overlays that increase watch time by confusion instead of clarity. |
| CTL-001 | FTO | Full Transcript Overlay | Negative Control | Control / Baseline | Experiment control | P0 | Control | Use complete burned-in transcript as baseline. |
| CTL-002 | KHT | Keyword Highlight Transcript | Negative Control | Control / Baseline | Experiment control | P0 | Control | Highlight important words inside full transcript. |
| CTL-003 | WWDC | Word-by-Word Dynamic Caption | Negative Control | Control / Baseline | Experiment control | P0 | Control | Active word highlight following speech. |
| CTL-004 | HBF | Heavy Bionic Formatting | Negative Control | Control / Baseline | Experiment control | P0 | Negative control | Apply bionic partial bolding to most words. |
| CTL-005 | ROW | RSVP One-Word Captions | Negative Control | Control / Baseline | Experiment control | P1 | Negative control | One word at a time in same spot. |
| CTL-006 | CKT | Constant Kinetic Text | Negative Control | Control / Baseline | Experiment control | P1 | Negative control | Every word moves or pops. |
| CTL-007 | NNO | No Overlay / Native Captions Only | Negative Control | Control / Baseline | Experiment control | P0 | Control | Baseline platform state. |
| CTL-008 | COM | Color-Only Meaning | Negative Control | Control / Baseline | Experiment control | P1 | Negative control | Use color without labels/icons for semantic roles. |
| CTL-009 | BOP | Bottom-Only Placement | Negative Control | Control / Baseline | Experiment control | P0 | Control | Always lower-third regardless of content. |
| CTL-010 | RSP | Random Saliency Pop | Negative Control | Control / Baseline | Experiment control | P1 | Negative control | Make random words visually pop. |
| CTL-011 | HDCS | High-Density Caption Stack | Negative Control | Control / Baseline | Experiment control | P1 | Negative control | Multiple overlays/captions/stickers simultaneously. |
| CTL-012 | ENS | Emoji/Nonstandard Subtitle Variant | Negative Control | Control / Baseline | Experiment control | P2 | Emerging direct evidence | Use platform-native non-standard typography and emoji. |
