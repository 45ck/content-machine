# KIN-005 / SAA — Snap-to-Action Animation

## Reference label

KIN-005 / SAA — Snap-to-Action Animation

## Classification

| Field | Value |
|---|---|
| Backlog ID | H080 |
| Method code | KIN-005 |
| Short code | SAA |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Action word snaps into place when instruction lands.

## Mechanism

Marks action moment.

## Expected direction

Better action recall.

## Failure mode

Can feel like generic social editing.

## Minimum viable experiment

Static vs snap action.

## Primary metrics

Action recall; completion

## Source IDs

S19
