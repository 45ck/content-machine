# SEM-020 / QTA — Question-to-Answer Captions

## Reference label

SEM-020 / QTA — Question-to-Answer Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H020 |
| Method code | SEM-020 |
| Short code | QTA |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Open with a concise question, answer one beat later.

## Mechanism

Uses prediction and curiosity without clickbait.

## Expected direction

Higher retention if payoff is fast.

## Failure mode

Can feel manipulative if delayed.

## Minimum viable experiment

Question-answer vs statement overlay.

## Primary metrics

3s hold; completion; trust

## Source IDs

S06; S07; S09; S10; S27
