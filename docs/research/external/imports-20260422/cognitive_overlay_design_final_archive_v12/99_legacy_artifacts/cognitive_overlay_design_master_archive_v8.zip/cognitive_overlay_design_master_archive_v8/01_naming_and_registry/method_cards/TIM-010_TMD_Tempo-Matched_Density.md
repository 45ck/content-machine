# TIM-010 / TMD — Tempo-Matched Density

## Reference label

TIM-010 / TMD — Tempo-Matched Density

## Classification

| Field | Value |
|---|---|
| Backlog ID | H050 |
| Method code | TIM-010 |
| Short code | TMD |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Decrease word count as speech tempo rises.

## Mechanism

Keeps reading load stable.

## Expected direction

Better comprehension at fast speech.

## Failure mode

May omit too much at high speed.

## Minimum viable experiment

Fixed density vs tempo-adaptive.

## Primary metrics

Gist recall; effort

## Source IDs

S04; S06
