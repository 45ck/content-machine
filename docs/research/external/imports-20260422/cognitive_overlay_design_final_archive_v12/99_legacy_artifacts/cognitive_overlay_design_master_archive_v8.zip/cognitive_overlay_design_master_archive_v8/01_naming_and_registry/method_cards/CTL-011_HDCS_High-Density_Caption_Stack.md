# CTL-011 / HDCS — High-Density Caption Stack

## Reference label

CTL-011 / HDCS — High-Density Caption Stack

## Classification

| Field | Value |
|---|---|
| Backlog ID | H177 |
| Method code | CTL-011 |
| Short code | HDCS |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P1 |
| Evidence grade | Negative control |
| Status | Backlog |

## Definition / what to try

Multiple overlays/captions/stickers simultaneously.

## Mechanism

Stress test for visual crowding.

## Expected direction

Likely high failure rate.

## Failure mode

Overload/crowding.

## Minimum viable experiment

Compare to budgeted text.

## Primary metrics

Readability; effort

## Source IDs

S15; S17
