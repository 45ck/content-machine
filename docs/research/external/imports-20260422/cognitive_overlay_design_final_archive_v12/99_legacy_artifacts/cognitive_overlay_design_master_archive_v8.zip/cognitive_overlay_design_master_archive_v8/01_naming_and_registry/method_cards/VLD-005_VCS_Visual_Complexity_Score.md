# VLD-005 / VCS — Visual Complexity Score

## Reference label

VLD-005 / VCS — Visual Complexity Score

## Classification

| Field | Value |
|---|---|
| Backlog ID | H095 |
| Method code | VLD-005 |
| Short code | VCS |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Compute frame-level complexity and use it to regulate overlay density.

## Mechanism

Makes density adaptive and testable.

## Expected direction

Better across mixed footage.

## Failure mode

Complexity metric may not match human load.

## Minimum viable experiment

Manual vs automated complexity rules.

## Primary metrics

Prediction accuracy; recall

## Source IDs

S12; S15
