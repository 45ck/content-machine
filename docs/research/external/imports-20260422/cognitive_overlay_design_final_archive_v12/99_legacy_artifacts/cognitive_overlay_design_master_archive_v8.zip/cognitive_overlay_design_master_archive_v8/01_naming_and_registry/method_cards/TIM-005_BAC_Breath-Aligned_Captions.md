# TIM-005 / BAC — Breath-Aligned Captions

## Reference label

TIM-005 / BAC — Breath-Aligned Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H045 |
| Method code | TIM-005 |
| Short code | BAC |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use natural speech breaths to segment caption events.

## Mechanism

Matches human prosody and reduces rush.

## Expected direction

Improved comfort and comprehension.

## Failure mode

Breaths are hard to detect in noisy audio.

## Minimum viable experiment

Breath-aligned vs uniform timing.

## Primary metrics

Comfort; completion

## Source IDs

S03; S19
