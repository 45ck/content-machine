# RET-002 / FPR — Fast Payoff Rule

## Reference label

RET-002 / FPR — Fast Payoff Rule

## Classification

| Field | Value |
|---|---|
| Backlog ID | H157 |
| Method code | RET-002 |
| Short code | FPR |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Rule / Mode |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Deliver the first useful idea within 2–3 seconds.

## Mechanism

Feeds reward prediction without deception.

## Expected direction

Higher retention and trust.

## Failure mode

Can compress too aggressively.

## Minimum viable experiment

Delayed payoff vs fast payoff.

## Primary metrics

3s hold; completion; trust

## Source IDs

S25
