# GAZ-005 / USZT — UI-Safe Zone Templates

## Reference label

GAZ-005 / USZT — UI-Safe Zone Templates

## Classification

| Field | Value |
|---|---|
| Backlog ID | H060 |
| Method code | GAZ-005 |
| Short code | USZT |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Define TikTok/Reels/Shorts danger zones and avoid them.

## Mechanism

Prevents platform interface collision.

## Expected direction

Higher readability in feed context.

## Failure mode

Safe zones vary by device/platform.

## Minimum viable experiment

Bottom-fixed vs UI-safe placement.

## Primary metrics

Readability; occlusion rate

## Source IDs

S02; S15; S28
