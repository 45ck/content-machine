# Core Vocabulary

| Code | Name | Type | Definition |
| --- | --- | --- | --- |
| COD | Cognitive Overlay Design | Field | Designing text, timing, placement, motion, and emphasis in video to improve comprehension, retention, attention, and accessibility. |
| PRT | Physiological Retention Typography | Branch | Short-form/mobile overlay design based on visual physiology, gaze, attention, working memory, saliency, fatigue, and scroll behavior. |
| SCCF | Semantic Compression Captioning Family | Family | Methods that rewrite speech into compact meaning units rather than full transcript text. |
| SCC | Semantic Compression Captions | Core method | Shortest meaning-preserving overlay derived from speech. |
| BCC | Bionic Compression Captioning | Named method | SCC plus full-word operator anchors and partial-word bionic concept anchors. |
| BCC+ | Bionic Compression Captioning Plus | Advanced protocol | BCC plus gaze-safe placement, visual-load adaptation, muted-first design, micro-rest rhythm, and full captions. |
| DLC | Dual-Layer Captioning | Architecture | Full closed captions for accessibility plus a separate semantic overlay for retention/gist. |
| ASOE | Adaptive Semantic Overlay Engine | Future system | Automated/human-in-loop engine that extracts, names, places, renders, scores, and tests overlays. |
| MPS | Meaning per Second | Metric | Amount of understood/remembered meaning per second watched. |
| MPF | Meaning per Fixation | Metric | Amount of understood/remembered meaning per gaze fixation or visual attention cost. |

## Family codes

| Code | Family |
| --- | --- |
| SEM | Semantic Compression |
| TYP | Typography and Anchors |
| TIM | Timing and Rhythm |
| GAZ | Placement and Gaze |
| KIN | Motion and Kinetic Text |
| VLD | Visual Load and Clutter |
| AUD | Sound and Multimodal |
| MEM | Memory and Learning |
| ACC | Accessibility and Personalization |
| AIA | AI and Adaptive Systems |
| RET | Platform Retention |
| CTL | Controls and Failure Modes |
