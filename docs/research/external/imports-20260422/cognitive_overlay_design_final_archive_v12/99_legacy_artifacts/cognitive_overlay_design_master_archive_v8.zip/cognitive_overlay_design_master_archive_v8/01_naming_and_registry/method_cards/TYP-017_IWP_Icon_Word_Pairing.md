# TYP-017 / IWP — Icon+Word Pairing

## Reference label

TYP-017 / IWP — Icon+Word Pairing

## Classification

| Field | Value |
|---|---|
| Backlog ID | H037 |
| Method code | TYP-017 |
| Short code | IWP |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Pair a simple icon with a concept word: friction, trigger, proof.

## Mechanism

Dual coding may aid memory if not decorative.

## Expected direction

Improved delayed recall.

## Failure mode

Icon mismatch confuses.

## Minimum viable experiment

Word-only vs icon+word.

## Primary metrics

Delayed recall; confusion

## Source IDs

S09; S10
