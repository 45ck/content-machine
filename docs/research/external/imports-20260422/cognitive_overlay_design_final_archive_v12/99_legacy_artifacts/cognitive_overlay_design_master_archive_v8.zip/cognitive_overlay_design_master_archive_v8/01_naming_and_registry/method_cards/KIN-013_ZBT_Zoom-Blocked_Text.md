# KIN-013 / ZBT — Zoom-Blocked Text

## Reference label

KIN-013 / ZBT — Zoom-Blocked Text

## Classification

| Field | Value |
|---|---|
| Backlog ID | H088 |
| Method code | KIN-013 |
| Short code | ZBT |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Suppress text during major zoom/camera movement.

## Mechanism

Prevents concurrent motion competition.

## Expected direction

Lower visual fatigue.

## Failure mode

May leave semantic gaps.

## Minimum viable experiment

Text during zoom vs delayed text.

## Primary metrics

Effort; visual recall

## Source IDs

S19; S15
