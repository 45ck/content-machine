# GAZ-019 / CCD — Caption Collision Detector

## Reference label

GAZ-019 / CCD — Caption Collision Detector

## Classification

| Field | Value |
|---|---|
| Backlog ID | H074 |
| Method code | GAZ-019 |
| Short code | CCD |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Detect overlap with native captions, stickers, captions, and UI.

## Mechanism

Prevents clutter stacking.

## Expected direction

Higher readability.

## Failure mode

False positives could restrict layout.

## Minimum viable experiment

Manual vs auto collision check.

## Primary metrics

Collision count; readability

## Source IDs

S15; S28
