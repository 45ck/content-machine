# RET-003 / OLER — Open-Loop With Early Resolution

## Reference label

RET-003 / OLER — Open-Loop With Early Resolution

## Classification

| Field | Value |
|---|---|
| Backlog ID | H158 |
| Method code | RET-003 |
| Short code | OLER |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Open a gap, resolve quickly, then deepen.

## Mechanism

Balances curiosity and cognitive comfort.

## Expected direction

Better completion than delayed tease.

## Failure mode

Too much tease lowers trust.

## Minimum viable experiment

Delayed open-loop vs early-resolution.

## Primary metrics

Completion; trust

## Source IDs

S25
