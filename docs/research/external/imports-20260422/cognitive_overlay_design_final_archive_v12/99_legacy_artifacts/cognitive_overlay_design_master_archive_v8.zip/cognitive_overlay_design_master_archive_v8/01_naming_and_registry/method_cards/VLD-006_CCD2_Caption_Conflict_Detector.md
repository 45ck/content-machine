# VLD-006 / CCD2 — Caption Conflict Detector

## Reference label

VLD-006 / CCD2 — Caption Conflict Detector

## Classification

| Field | Value |
|---|---|
| Backlog ID | H096 |
| Method code | VLD-006 |
| Short code | CCD2 |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Detect when too many text layers exist simultaneously.

## Mechanism

Prevents split attention and crowding.

## Expected direction

Higher clarity.

## Failure mode

May suppress useful labels.

## Minimum viable experiment

Conflict detector on/off.

## Primary metrics

Text count; effort; recall

## Source IDs

S10; S15
