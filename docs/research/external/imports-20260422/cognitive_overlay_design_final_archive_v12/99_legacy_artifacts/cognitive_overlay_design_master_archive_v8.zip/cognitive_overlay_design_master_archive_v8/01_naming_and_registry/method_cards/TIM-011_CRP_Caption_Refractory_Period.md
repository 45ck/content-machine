# TIM-011 / CRP — Caption Refractory Period

## Reference label

TIM-011 / CRP — Caption Refractory Period

## Classification

| Field | Value |
|---|---|
| Backlog ID | H051 |
| Method code | TIM-011 |
| Short code | CRP |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

After an emphasized word, hold visual quiet for a beat.

## Mechanism

Gives consolidation time.

## Expected direction

Better memory for highlighted term.

## Failure mode

May feel slow.

## Minimum viable experiment

Immediate next text vs refractory gap.

## Primary metrics

Keyword recall; completion

## Source IDs

S24; S29
