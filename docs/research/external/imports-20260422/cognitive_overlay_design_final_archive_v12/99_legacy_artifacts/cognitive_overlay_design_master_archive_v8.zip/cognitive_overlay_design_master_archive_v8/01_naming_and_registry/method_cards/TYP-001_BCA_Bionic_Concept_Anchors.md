# TYP-001 / BCA — Bionic Concept Anchors

## Reference label

TYP-001 / BCA — Bionic Concept Anchors

## Classification

| Field | Value |
|---|---|
| Backlog ID | H021 |
| Method code | TYP-001 |
| Short code | BCA |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Weak / contested |
| Status | Backlog |

## Definition / what to try

Partially bold only key concept words after compression.

## Mechanism

Tests whether partial-word anchors add anything after compression.

## Expected direction

Small boost to recall or subjective clarity.

## Failure mode

May add noise; bionic evidence weak.

## Minimum viable experiment

Semantic compression vs BCC.

## Primary metrics

Gist recall; fixation count; preference

## Source IDs

S08; S22; S23
