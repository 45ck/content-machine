# VLD — Visual Load and Clutter

This family contains 15 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| VLD-001 | VLAW | Visual-Load Adaptive Word Count | Load-Control Method | Pilot first | P0 | Strong adjacent | Use fewer overlay words when the frame is visually busy. | Fixed vs adaptive density. | Gist; visual recall; effort |
| VLD-002 | DML | Demo Minimal Labels | Load-Control Method | Pilot second | P1 | Moderate adjacent | During demonstrations, show only verbs or labels: twist, lock, pull. | Sentence captions vs labels in demo. | Task recall; completion |
| VLD-003 | BBAP | Busy Background Auto-Plate | Load-Control Method | Pilot second | P1 | Strong adjacent | Add a soft plate behind text only when background is complex. | Auto plate vs always/never plate. | Readability; aesthetic rating |
| VLD-004 | BDW | Background Dimming Window | Load-Control Method | Explore later | P2 | Moderate adjacent | Temporarily dim non-essential background behind text. | Dimming vs none. | Readability; immersion |
| VLD-005 | VCS | Visual Complexity Score | Load-Control Method | Pilot second | P1 | Speculative / direct test needed | Compute frame-level complexity and use it to regulate overlay density. | Manual vs automated complexity rules. | Prediction accuracy; recall |
| VLD-006 | CCD2 | Caption Conflict Detector | Load-Control Method | Pilot first | P0 | Strong practical / direct test needed | Detect when too many text layers exist simultaneously. | Conflict detector on/off. | Text count; effort; recall |
| VLD-007 | HMS | High-Motion Suppression | Load-Control Method | Pilot second | P1 | Moderate adjacent | Reduce caption animation and density during high visual motion. | Motion-adaptive vs fixed overlay. | Visual recall; comprehension |
| VLD-008 | STB | Simultaneous Text Budget | Rule / Mode | Pilot first | P0 | Strong adjacent | Limit screen to one primary text block plus one micro-label. | Budgeted vs unbudgeted overlays. | Effort; recall |
| VLD-009 | NCCC | Native Caption Conflict Checker | Load-Control Method | Pilot first | P0 | Strong practical / direct test needed | Avoid overlay collisions with platform auto-captions or imported captions. | With/without conflict checking. | Occlusion; user complaints |
| VLD-010 | BPD | Background Pattern Detector | Load-Control Method | Explore later | P2 | Moderate adjacent | Flag stripes, grids, leaves, and high-frequency textures behind text. | Pattern-aware vs fixed placement. | Readability; failure rate |
| VLD-011 | FLCC | Frame-Level Contrast Correction | Load-Control Method | Pilot first | P0 | Strong adjacent | Auto adjust text/backplate contrast per frame. | Static style vs auto-correct. | WCAG ratio; readability |
| VLD-012 | TDB | Text Dwell Budget | Rule / Mode | Pilot second | P1 | Speculative / direct test needed | Limit total seconds of on-screen text per 10 seconds of video. | Low/medium/high dwell budgets. | Visual recall; effort; muted comprehension |
| VLD-013 | DVG | Density by Viewer Goal | Load-Control Method | Explore later | P2 | Speculative / direct test needed | Use heavier overlays for learning clips, lighter for entertainment clips. | Category-specific vs universal density. | Recall; retention by category |
| VLD-014 | CSEF | Caption Safe Empty Frames | Load-Control Method | Explore later | P2 | Speculative / direct test needed | Intentionally reserve clean frames for text instead of adding text anywhere. | Planned empty frames vs reactive overlays. | Readability; production time |
| VLD-015 | RFL | Readability Failure Log | Load-Control Method | Pilot second | P1 | Strong practical / direct test needed | Annotate every point where a tester missed or struggled with text. | No log vs failure-log revision. | Revision improvement rate |
