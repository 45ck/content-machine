# Overlay Generator Guide

The current prototype includes `bcc_overlay_generator.py`. It is a human-in-the-loop asset generator rather than a fully automated ASOE system.

## Expected input

```csv
video_id,start,end,spoken_text,semantic_caption,role,keywords,placement_zone,visual_load
```

## Expected outputs

- SRT captions
- VTT captions
- ASS subtitle/overlay files
- JSON overlay plans
- Editor CSV exports

## Future improvements

Automatic proposition extraction, semantic beat detection, anchor selection, face/mouth/hand/object detection, visual-load prediction, saliency-safe placement, platform safe-zone templates, rubric auto-scoring, and A/B variant generation.
