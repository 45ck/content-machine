# SEM — Semantic Compression

This family contains 20 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| SEM-001 | SCC | Semantic Compression Captions | Method | Pilot first | P0 | Strong adjacent | Rewrite spoken sentences into shortest meaning-preserving phrases. | Full transcript vs semantic compression on same clip. | Gist recall; action recall; perceived effort |
| SEM-002 | PEO | Proposition Extraction Overlay | Method | Pilot first | P0 | Moderate adjacent | Show the underlying claim rather than the literal words. | Human-coded propositions vs transcript overlay. | Main point accuracy; distortion errors |
| SEM-003 | OFC | Operator-First Captioning | Method | Pilot first | P0 | Moderate adjacent | Begin overlay with logical operator: Not, Stop, Less, First, Then. | Keyword-only vs Not-X/Y microphrases. | Contrast recall; completion rate |
| SEM-004 | CPC | Contrast Pair Cards | Method | Pilot second | P1 | Moderate adjacent | Use two-line contrasts: Not X / Y, Stop X / Start Y. | Contrast pair vs normal sentence. | Gist recall; save rate |
| SEM-005 | PCFB | Problem–Cause–Fix Beat Cards | Method | Pilot first | P0 | Strong adjacent | Display three labels across the clip: Problem, Cause, Fix. | Same explainer with/without beat labels. | Action recall; perceived structure |
| SEM-006 | REN | Rule–Example–Nonexample Captions | Rule / Mode | Explore later | P2 | Moderate adjacent | Show a rule, a good example, then a wrong example. | Learning clip with rule-only vs rule-example-nonexample. | Transfer question; completion |
| SEM-007 | CEP | Claim–Evidence–Payoff Overlay | Method | Explore later | P2 | Moderate adjacent | Label claim, proof, and takeaway as separate beats. | Advice clip with claim/payoff labels vs no labels. | Credibility rating; saves |
| SEM-008 | TFO | Takeaway-First Overlay | Method | Pilot second | P1 | Moderate adjacent | Show the final point in the first second, then explain. | Hook-first vs takeaway-first variants. | 1s/3s hold; completion |
| SEM-009 | AOO | Action-Only Overlay | Method | Pilot second | P1 | Moderate adjacent | For advice clips, show only the next action, not explanation. | Action-only vs explanation captions. | Action recall; saves |
| SEM-010 | MOC | Memory Object Captions | Method | Pilot second | P1 | Moderate adjacent | End with a short, repeatable phrase: Systems beat mood. | With/without end memory phrase. | Delayed recall; shares |
| SEM-011 | MVC | Minimal Verb Captioning | Method | Explore later | P2 | Speculative / direct test needed | Preserve verbs over nouns when showing fewer words. | Verb-heavy vs noun-heavy compression. | Action recall |
| SEM-012 | SBT | Semantic Breadcrumb Trail | Method | Explore later | P2 | Moderate adjacent | Display one small concept per beat that accumulates meaning. | Breadcrumb vs independent captions. | Sequence recall; effort rating |
| SEM-013 | CLC | Concept Ladder Captions | Method | Explore later | P2 | Moderate adjacent | Move from concrete to abstract: shoes → start → habit. | Beginner viewers: ladder vs direct concept. | Novice gist recall |
| SEM-014 | CRL | Compression Ratio Ladder | Method | Pilot first | P0 | Strong adjacent | Test 100%, 60%, 30%, 15%, and 5% transcript equivalents. | Same clip at multiple compression ratios. | Gist recall; text dwell; effort |
| SEM-015 | KMC | Keyword-to-Microphrase Conversion | Method | Pilot second | P1 | Moderate adjacent | Convert isolated keywords into 2–4 word phrase chunks. | Keywords vs microphrases. | Gist recall; visual recall |
| SEM-016 | OIOS | One Idea, One Screen Rule | Rule / Mode | Pilot first | P0 | Strong adjacent | Never show two unrelated ideas in one overlay event. | Multi-idea vs one-idea overlay. | Effort; sequence recall |
| SEM-017 | GET | Gist vs Exact Mode Toggle | Rule / Mode | Pilot first | P0 | Strong adjacent | Use gist overlay for retention, closed captions for exact speech. | Full captions plus gist overlay vs overlay alone. | Preference; comprehension; access rating |
| SEM-018 | AFC | Anti-Filler Captioning | Method | Pilot second | P1 | Moderate adjacent | Remove basically, actually, kind of, really, and redundant phrases. | Auto-filler removal vs verbatim. | Effort; clarity rating |
| SEM-019 | CT | Certainty Tags | Method | Explore later | P2 | Speculative / direct test needed | Mark claims as Rule, Hypothesis, Example, Warning, Tested. | Claims with/without certainty tags. | Trust rating; misunderstanding rate |
| SEM-020 | QTA | Question-to-Answer Captions | Method | Pilot second | P1 | Moderate adjacent | Open with a concise question, answer one beat later. | Question-answer vs statement overlay. | 3s hold; completion; trust |
