# CTL-005 / ROW — RSVP One-Word Captions

## Reference label

CTL-005 / ROW — RSVP One-Word Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H171 |
| Method code | CTL-005 |
| Short code | ROW |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P1 |
| Evidence grade | Negative control |
| Status | Backlog |

## Definition / what to try

One word at a time in same spot.

## Mechanism

Tests speed-reading style in video context.

## Expected direction

Likely weak for comprehension.

## Failure mode

Suppresses parafoveal context/rereading.

## Minimum viable experiment

Compare to semantic beats.

## Primary metrics

Comprehension; fatigue

## Source IDs

S24
