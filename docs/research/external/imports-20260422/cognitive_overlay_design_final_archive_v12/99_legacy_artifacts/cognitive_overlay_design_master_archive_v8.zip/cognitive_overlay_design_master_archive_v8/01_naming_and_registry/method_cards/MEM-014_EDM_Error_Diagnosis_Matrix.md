# MEM-014 / EDM — Error Diagnosis Matrix

## Reference label

MEM-014 / EDM — Error Diagnosis Matrix

## Classification

| Field | Value |
|---|---|
| Backlog ID | H129 |
| Method code | MEM-014 |
| Short code | EDM |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Show two-axis quick diagnosis: effort high / clarity low.

## Mechanism

Helps viewer categorize problem.

## Expected direction

Better transfer to self-context.

## Failure mode

Too complex for small screen.

## Minimum viable experiment

Matrix vs plain explanation.

## Primary metrics

Transfer; effort

## Source IDs

S17; S15
