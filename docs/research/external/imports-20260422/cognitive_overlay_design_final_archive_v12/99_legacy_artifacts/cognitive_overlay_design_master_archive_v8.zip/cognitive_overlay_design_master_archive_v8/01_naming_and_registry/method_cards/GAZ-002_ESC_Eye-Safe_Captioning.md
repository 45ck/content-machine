# GAZ-002 / ESC — Eye-Safe Captioning

## Reference label

GAZ-002 / ESC — Eye-Safe Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H057 |
| Method code | GAZ-002 |
| Short code | ESC |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Avoid covering eyes in emotional/storytelling clips.

## Mechanism

Protects social/emotional information.

## Expected direction

Better empathy and retention.

## Failure mode

May reduce text placement options.

## Minimum viable experiment

Eye-covered vs eye-safe.

## Primary metrics

Emotion recognition; completion

## Source IDs

S20; S32
