# KIN-010 / DKC — De-Karaoke Captions

## Reference label

KIN-010 / DKC — De-Karaoke Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H085 |
| Method code | KIN-010 |
| Short code | DKC |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Replace active word-by-word highlighting with semantic beats for dense content.

## Mechanism

Avoids forced tracking of every word.

## Expected direction

Better gist and lower fatigue.

## Failure mode

May reduce perceived energy.

## Minimum viable experiment

Karaoke vs semantic beats.

## Primary metrics

Gist recall; effort

## Source IDs

S06; S24
