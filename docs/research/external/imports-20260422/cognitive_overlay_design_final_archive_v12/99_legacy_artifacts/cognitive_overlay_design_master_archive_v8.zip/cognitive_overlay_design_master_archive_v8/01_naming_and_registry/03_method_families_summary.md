# Method Families Summary

| Code | Family | Count | Folder |
| --- | --- | --- | --- |
| SEM | Semantic Compression | 20 | families/SEM_Semantic_Compression.md |
| TYP | Typography and Anchors | 20 | families/TYP_Typography_and_Anchors.md |
| TIM | Timing and Rhythm | 15 | families/TIM_Timing_and_Rhythm.md |
| GAZ | Placement and Gaze | 20 | families/GAZ_Placement_and_Gaze.md |
| KIN | Motion and Kinetic Text | 15 | families/KIN_Motion_and_Kinetic_Text.md |
| VLD | Visual Load and Clutter | 15 | families/VLD_Visual_Load_and_Clutter.md |
| AUD | Sound and Multimodal | 10 | families/AUD_Sound_and_Multimodal.md |
| MEM | Memory and Learning | 15 | families/MEM_Memory_and_Learning.md |
| ACC | Accessibility and Personalization | 10 | families/ACC_Accessibility_and_Personalization.md |
| AIA | AI and Adaptive Systems | 15 | families/AIA_AI_and_Adaptive_Systems.md |
| RET | Platform Retention | 11 | families/RET_Platform_Retention.md |
| CTL | Controls and Failure Modes | 12 | families/CTL_Controls_and_Failure_Modes.md |
