# AUD-009 / TI — Tone Icons

## Reference label

AUD-009 / TI — Tone Icons

## Classification

| Field | Value |
|---|---|
| Backlog ID | H114 |
| Method code | AUD-009 |
| Short code | TI |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Multimodal Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use small icons for sarcasm, warning, encouragement only when tone is ambiguous.

## Mechanism

Adds affective context without long text.

## Expected direction

Better tone interpretation.

## Failure mode

Icons can trivialize serious content.

## Minimum viable experiment

Tone icon vs none.

## Primary metrics

Tone accuracy; preference

## Source IDs

S20; S34
