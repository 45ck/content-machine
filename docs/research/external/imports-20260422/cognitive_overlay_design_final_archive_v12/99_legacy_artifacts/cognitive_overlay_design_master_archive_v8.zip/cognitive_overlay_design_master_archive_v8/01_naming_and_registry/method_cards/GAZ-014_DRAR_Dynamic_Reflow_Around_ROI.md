# GAZ-014 / DRAR — Dynamic Reflow Around ROI

## Reference label

GAZ-014 / DRAR — Dynamic Reflow Around ROI

## Classification

| Field | Value |
|---|---|
| Backlog ID | H069 |
| Method code | GAZ-014 |
| Short code | DRAR |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Move captions frame-by-frame around faces/hands/products.

## Mechanism

Avoids visual obstruction dynamically.

## Expected direction

Better across complex shots.

## Failure mode

Movement itself may distract.

## Minimum viable experiment

Static safe zone vs dynamic reflow.

## Primary metrics

Visual recall; distraction

## Source IDs

S12; S13; S14
