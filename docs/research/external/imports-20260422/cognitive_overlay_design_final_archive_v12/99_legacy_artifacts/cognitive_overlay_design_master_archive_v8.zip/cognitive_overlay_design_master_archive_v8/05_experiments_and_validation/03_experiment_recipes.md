# Experiment Recipes

## E1 — Core Isolation

Question: Does BCC beat SCC? Conditions: SCC vs BCC. Metrics: gist recall, contrast recall, perceived effort, completion rate.

## E2 — Adaptive Protocol Test

Question: Does BCC+ beat BCC? Conditions: BCC vs BCC+. Metrics: visual recall, muted comprehension, completion rate, perceived effort.

## E3 — Placement Test

Question: Does gaze-safe placement beat bottom-fixed placement? Conditions: BFP vs GSP.

## E4 — Timing Offset Test

Question: Does predictive semantic priming help? Conditions: PSP 400 ms, PSP 200 ms, SYNC, POST 200 ms, POST 400 ms.

## E5 — Visual Load Adaptation

Question: Should caption density change with frame complexity? Conditions: fixed density vs VLAC.

## E6 — Motion Dose

Question: How much motion helps before it overloads? Conditions: static, fade/scale, logic motion, word pop, karaoke, constant kinetic.

## E7 — Audio Mode Test

Question: Should audio-on and muted viewers receive different overlay strategies?

## E8 — Highlight Density

Question: What emphasis density is best? Conditions: 0%, 5%, 10–15%, 25%, 50%, heavy bionic.

## E9 — Micro-Rest Rhythm

Question: Do no-text gaps improve visual recall and reduce fatigue?

## E10 — Viewer Segment Test

Question: Which viewer groups benefit from which overlay modes?
