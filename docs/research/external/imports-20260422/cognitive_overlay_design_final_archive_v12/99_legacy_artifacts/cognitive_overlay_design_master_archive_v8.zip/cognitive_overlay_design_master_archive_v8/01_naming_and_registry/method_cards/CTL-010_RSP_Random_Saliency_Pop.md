# CTL-010 / RSP — Random Saliency Pop

## Reference label

CTL-010 / RSP — Random Saliency Pop

## Classification

| Field | Value |
|---|---|
| Backlog ID | H176 |
| Method code | CTL-010 |
| Short code | RSP |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P1 |
| Evidence grade | Negative control |
| Status | Backlog |

## Definition / what to try

Make random words visually pop.

## Mechanism

Tests whether salience without meaning helps.

## Expected direction

Likely harms trust/comprehension.

## Failure mode

Misguides attention.

## Minimum viable experiment

Compare to semantic cueing.

## Primary metrics

Gist; trust

## Source IDs

S09; S11
