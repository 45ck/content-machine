# TYP-010 / SOF — Stroke/Outline Fallback

## Reference label

TYP-010 / SOF — Stroke/Outline Fallback

## Classification

| Field | Value |
|---|---|
| Backlog ID | H030 |
| Method code | TYP-010 |
| Short code | SOF |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use outline/shadow only when background contrast is unstable.

## Mechanism

Maintains readability across frames.

## Expected direction

Lower missed captions.

## Failure mode

Can look noisy if too thick.

## Minimum viable experiment

Outline vs capsule vs none.

## Primary metrics

Readability; aesthetic rating

## Source IDs

S28; S15
