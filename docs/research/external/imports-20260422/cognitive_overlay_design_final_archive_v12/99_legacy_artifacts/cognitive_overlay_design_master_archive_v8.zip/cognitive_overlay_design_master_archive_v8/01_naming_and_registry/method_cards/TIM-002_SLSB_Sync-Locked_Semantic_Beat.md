# TIM-002 / SLSB — Sync-Locked Semantic Beat

## Reference label

TIM-002 / SLSB — Sync-Locked Semantic Beat

## Classification

| Field | Value |
|---|---|
| Backlog ID | H042 |
| Method code | TIM-002 |
| Short code | SLSB |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Show the overlay exactly when the semantic beat is spoken.

## Mechanism

Preserves audio-text relation.

## Expected direction

Reliable baseline.

## Failure mode

May be slightly late for fast comprehension.

## Minimum viable experiment

Sync vs pre/post.

## Primary metrics

Comprehension; preference

## Source IDs

S03; S04; S29
