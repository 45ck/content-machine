# TYP-008 / DEF — De-Emphasis Fades

## Reference label

TYP-008 / DEF — De-Emphasis Fades

## Classification

| Field | Value |
|---|---|
| Backlog ID | H028 |
| Method code | TYP-008 |
| Short code | DEF |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Dull background words and keep key terms high opacity.

## Mechanism

Guides attention while preserving context.

## Expected direction

May lower reading load.

## Failure mode

Low opacity may fail contrast/accessibility.

## Minimum viable experiment

Opacity fade vs bold highlight.

## Primary metrics

Recall; contrast compliance

## Source IDs

S08; S28
