# CTL-007 / NNO — No Overlay / Native Captions Only

## Reference label

CTL-007 / NNO — No Overlay / Native Captions Only

## Classification

| Field | Value |
|---|---|
| Backlog ID | H173 |
| Method code | CTL-007 |
| Short code | NNO |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P0 |
| Evidence grade | Control |
| Status | Backlog |

## Definition / what to try

Baseline platform state.

## Mechanism

Determines value of any overlay.

## Expected direction

May win for visual recall.

## Failure mode

May lose muted gist.

## Minimum viable experiment

Compare to all variants.

## Primary metrics

Gist; visual recall; retention

## Source IDs

S01; S05
