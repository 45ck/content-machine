# CTL-006 / CKT — Constant Kinetic Text

## Reference label

CTL-006 / CKT — Constant Kinetic Text

## Classification

| Field | Value |
|---|---|
| Backlog ID | H172 |
| Method code | CTL-006 |
| Short code | CKT |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P1 |
| Evidence grade | Negative control |
| Status | Backlog |

## Definition / what to try

Every word moves or pops.

## Mechanism

Tests motion overload.

## Expected direction

Likely higher attention, lower comprehension.

## Failure mode

Motion becomes noise.

## Minimum viable experiment

Compare to logic motion.

## Primary metrics

Recall; fatigue; retention

## Source IDs

S19
