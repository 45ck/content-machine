# Physiology and Cognition Map

## Visual channel bottleneck

Short-form viewers process speech, face, motion, UI, captions, overlays, and platform signals simultaneously. If audio is muted, the visual channel carries nearly all verbal meaning.

## Foveal/peripheral constraint

Detailed text must be foveated. Peripheral overlays should be cues, not full sentences.

## Visual crowding

Text placed near other text, UI, stickers, busy backgrounds, or patterned surfaces becomes harder to recognize. This justifies crowding-aware placement and backplates.

## Working memory

Viewers cannot hold long sentence fragments while also processing motion. Use semantic beats and one-idea-per-screen.

## Attention and saliency

Bright/moving text grabs attention, but meaning-rich text earns attention. The goal is not to maximize salience; it is to maximize meaning gained per gaze cost.

## Speech perception

The mouth and face support speech comprehension, especially when audio is degraded. Talking-head overlays should avoid covering mouth and eyes.

## Fatigue

Continuous text and motion can produce a constant reading task. Micro-rest rhythm gives the eyes time to return to the video.
