# SEM-002 / PEO — Proposition Extraction Overlay

## Reference label

SEM-002 / PEO — Proposition Extraction Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H002 |
| Method code | SEM-002 |
| Short code | PEO |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Show the underlying claim rather than the literal words.

## Mechanism

Lets viewer process mental model instead of syntax.

## Expected direction

Higher main-point recall, especially muted.

## Failure mode

May distort nuance if proposition is wrong.

## Minimum viable experiment

Human-coded propositions vs transcript overlay.

## Primary metrics

Main point accuracy; distortion errors

## Source IDs

S06; S07; S09; S10; S27
