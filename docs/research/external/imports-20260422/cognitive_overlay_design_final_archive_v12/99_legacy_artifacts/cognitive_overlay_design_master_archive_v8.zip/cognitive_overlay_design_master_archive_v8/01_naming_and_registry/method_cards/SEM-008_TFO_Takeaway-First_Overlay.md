# SEM-008 / TFO — Takeaway-First Overlay

## Reference label

SEM-008 / TFO — Takeaway-First Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H008 |
| Method code | SEM-008 |
| Short code | TFO |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Show the final point in the first second, then explain.

## Mechanism

Reduces uncertainty and raises reward prediction.

## Expected direction

Better 3-second hold for educational clips.

## Failure mode

May spoil suspense or jokes.

## Minimum viable experiment

Hook-first vs takeaway-first variants.

## Primary metrics

1s/3s hold; completion

## Source IDs

S06; S07; S09; S10; S27
