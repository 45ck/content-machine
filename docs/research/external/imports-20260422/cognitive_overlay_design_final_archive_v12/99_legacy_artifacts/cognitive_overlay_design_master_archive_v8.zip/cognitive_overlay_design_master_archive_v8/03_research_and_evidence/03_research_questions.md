# Research Questions and Unknowns

1. Does **BCC** outperform **SCC** after compression is already done?
2. Does **BCC+** outperform **BCC** because of placement and adaptive density?
3. What compression ratio preserves gist without becoming cryptic?
4. What highlight density is optimal for short-form video?
5. Where should overlays be placed for each content type?
6. Should semantic text appear before, during, or after the spoken phrase?
7. How much motion helps before it becomes distracting?
8. Should audio-on and muted viewing use different overlay strategies?
9. Which viewer groups benefit or suffer: L2, DHH, dyslexic, ADHD, expert, novice, older viewers?
10. Which metric best captures success: meaning per second, meaning per fixation, gist recall, action recall, or completion rate?
