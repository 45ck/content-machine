# ACC-002 / LSM — L2 Simplified Mode

## Reference label

ACC-002 / LSM — L2 Simplified Mode

## Classification

| Field | Value |
|---|---|
| Backlog ID | H132 |
| Method code | ACC-002 |
| Short code | LSM |
| Category | Personalization / Access |
| Family | Accessibility and Personalization |
| Class | Rule / Mode |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use simpler vocabulary and more context for second-language viewers.

## Mechanism

Reduces language processing burden.

## Expected direction

Better L2 comprehension.

## Failure mode

May feel too simple for natives.

## Minimum viable experiment

Native vs L2-tailored captions.

## Primary metrics

L2 gist; effort

## Source IDs

S07; S10
