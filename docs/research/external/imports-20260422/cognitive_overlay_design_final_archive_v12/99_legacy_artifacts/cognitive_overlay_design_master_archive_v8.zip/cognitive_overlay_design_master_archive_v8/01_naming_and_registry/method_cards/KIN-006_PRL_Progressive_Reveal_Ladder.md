# KIN-006 / PRL — Progressive Reveal Ladder

## Reference label

KIN-006 / PRL — Progressive Reveal Ladder

## Classification

| Field | Value |
|---|---|
| Backlog ID | H081 |
| Method code | KIN-006 |
| Short code | PRL |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Reveal sequence vertically: cue → action → reward.

## Mechanism

Segmenting supports working memory.

## Expected direction

Better procedural recall.

## Failure mode

Too slide-like for entertainment.

## Minimum viable experiment

All-at-once vs progressive reveal.

## Primary metrics

Sequence recall; effort

## Source IDs

S09; S19
