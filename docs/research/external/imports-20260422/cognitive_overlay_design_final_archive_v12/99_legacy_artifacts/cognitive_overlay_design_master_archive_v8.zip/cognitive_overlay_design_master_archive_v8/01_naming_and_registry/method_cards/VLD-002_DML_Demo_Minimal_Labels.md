# VLD-002 / DML — Demo Minimal Labels

## Reference label

VLD-002 / DML — Demo Minimal Labels

## Classification

| Field | Value |
|---|---|
| Backlog ID | H092 |
| Method code | VLD-002 |
| Short code | DML |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

During demonstrations, show only verbs or labels: twist, lock, pull.

## Mechanism

Preserves action visibility.

## Expected direction

Better procedural recall.

## Failure mode

Too sparse for novices.

## Minimum viable experiment

Sentence captions vs labels in demo.

## Primary metrics

Task recall; completion

## Source IDs

S10; S15
