# SEM-005 / PCFB — Problem–Cause–Fix Beat Cards

## Reference label

SEM-005 / PCFB — Problem–Cause–Fix Beat Cards

## Classification

| Field | Value |
|---|---|
| Backlog ID | H005 |
| Method code | SEM-005 |
| Short code | PCFB |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Display three labels across the clip: Problem, Cause, Fix.

## Mechanism

Externalizes structure and reduces working-memory demand.

## Expected direction

Better action recall for educational clips.

## Failure mode

Can feel like a slide deck if overused.

## Minimum viable experiment

Same explainer with/without beat labels.

## Primary metrics

Action recall; perceived structure

## Source IDs

S06; S07; S09; S10; S27
