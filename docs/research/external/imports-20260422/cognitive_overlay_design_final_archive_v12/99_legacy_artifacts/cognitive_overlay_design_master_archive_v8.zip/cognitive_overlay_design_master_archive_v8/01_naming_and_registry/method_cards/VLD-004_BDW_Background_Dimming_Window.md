# VLD-004 / BDW — Background Dimming Window

## Reference label

VLD-004 / BDW — Background Dimming Window

## Classification

| Field | Value |
|---|---|
| Backlog ID | H094 |
| Method code | VLD-004 |
| Short code | BDW |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Temporarily dim non-essential background behind text.

## Mechanism

Reduces crowding and contrast problems.

## Expected direction

Better text recognition.

## Failure mode

May feel intrusive.

## Minimum viable experiment

Dimming vs none.

## Primary metrics

Readability; immersion

## Source IDs

S15; S28
