# ACC-006 / LMM — Low-Motion Mode

## Reference label

ACC-006 / LMM — Low-Motion Mode

## Classification

| Field | Value |
|---|---|
| Backlog ID | H136 |
| Method code | ACC-006 |
| Short code | LMM |
| Category | Personalization / Access |
| Family | Accessibility and Personalization |
| Class | Rule / Mode |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Provide a static/low-animation overlay for viewers sensitive to motion.

## Mechanism

Reduces distraction/fatigue.

## Expected direction

Better perceived comfort.

## Failure mode

May reduce platform energy.

## Minimum viable experiment

Static vs kinetic variants.

## Primary metrics

Comfort; retention

## Source IDs

S19; S26
