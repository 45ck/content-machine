# Validation Protocol

## Purpose

Validate whether semantic compression, bionic anchors, gaze-safe placement, and visual-load adaptation improve short-form video outcomes.

## Main conditions

| Condition | Code | Purpose |
|---|---|---|
| Native captions only | NCO | Platform baseline |
| Full transcript overlay | FTO | Verbatim overlay baseline |
| Keyword highlight transcript | KHT | Existing-tool comparison |
| Semantic compression | SCC | Compression-only test |
| Bionic compression captioning | BCC | Tests bionic anchors after compression |
| BCC+ | BCC+ | Tests adaptive placement/density/muted-first protocol |
| Heavy bionic control | HBC | Negative/noisy bionic control |
| Word-by-word dynamic captions | WDC | Existing dynamic caption comparison |

## Main measures

Gist recall, action recall, contrast recall, exact wording recall, muted comprehension, visual recall, perceived effort, completion rate, rewatch rate, save/share rate, and gaze metrics when available.

## Decision rule

If SCC beats full transcript, keep semantic compression. If BCC beats SCC, keep bionic anchors. If BCC+ beats BCC, prioritize adaptive placement/density as a core product capability.
