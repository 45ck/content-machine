# CTL-001 / FTO — Full Transcript Overlay

## Reference label

CTL-001 / FTO — Full Transcript Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H167 |
| Method code | CTL-001 |
| Short code | FTO |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P0 |
| Evidence grade | Control |
| Status | Backlog |

## Definition / what to try

Use complete burned-in transcript as baseline.

## Mechanism

Baseline for exact wording and accessibility-adjacent display.

## Expected direction

Best exact recall, worse visual efficiency.

## Failure mode

May overload visual channel.

## Minimum viable experiment

Compare against compression/BCC.

## Primary metrics

Exact recall; effort

## Source IDs

S01; S06; S10
