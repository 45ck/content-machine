# GAZ-017 / ELT — Eye-Line Triangle Rule

## Reference label

GAZ-017 / ELT — Eye-Line Triangle Rule

## Classification

| Field | Value |
|---|---|
| Backlog ID | H072 |
| Method code | GAZ-017 |
| Short code | ELT |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Rule / Mode |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Place overlay within triangle between speaker’s eyes, hands/object, and center.

## Mechanism

Reduces gaze travel.

## Expected direction

Lower saccade distance and effort.

## Failure mode

Needs eye-tracking validation.

## Minimum viable experiment

Triangle placement vs arbitrary.

## Primary metrics

Saccade distance; effort

## Source IDs

S32; S14
