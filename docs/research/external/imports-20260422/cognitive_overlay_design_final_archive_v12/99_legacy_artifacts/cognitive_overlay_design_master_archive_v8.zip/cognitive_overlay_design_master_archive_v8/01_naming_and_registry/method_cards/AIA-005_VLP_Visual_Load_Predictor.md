# AIA-005 / VLP — Visual Load Predictor

## Reference label

AIA-005 / VLP — Visual Load Predictor

## Classification

| Field | Value |
|---|---|
| Backlog ID | H145 |
| Method code | AIA-005 |
| Short code | VLP |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | System Module |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Estimate per-frame visual complexity to choose word count.

## Mechanism

Controls visual-channel load.

## Expected direction

Better comprehension in busy scenes.

## Failure mode

Metric may not match human load.

## Minimum viable experiment

Human-coded vs model-coded load.

## Primary metrics

Prediction validity; recall

## Source IDs

S12; S15
