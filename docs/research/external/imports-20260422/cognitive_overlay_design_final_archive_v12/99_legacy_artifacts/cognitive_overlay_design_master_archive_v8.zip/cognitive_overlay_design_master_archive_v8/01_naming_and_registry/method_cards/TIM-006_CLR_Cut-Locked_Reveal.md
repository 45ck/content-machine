# TIM-006 / CLR — Cut-Locked Reveal

## Reference label

TIM-006 / CLR — Cut-Locked Reveal

## Classification

| Field | Value |
|---|---|
| Backlog ID | H046 |
| Method code | TIM-006 |
| Short code | CLR |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Reveal caption on visual cut or camera movement boundary.

## Mechanism

Uses visual reset for attention capture.

## Expected direction

Better noticing without extra motion.

## Failure mode

Can compete with scene change if too much text.

## Minimum viable experiment

Cut-locked vs mid-shot reveal.

## Primary metrics

First fixation; recall

## Source IDs

S19; S29
