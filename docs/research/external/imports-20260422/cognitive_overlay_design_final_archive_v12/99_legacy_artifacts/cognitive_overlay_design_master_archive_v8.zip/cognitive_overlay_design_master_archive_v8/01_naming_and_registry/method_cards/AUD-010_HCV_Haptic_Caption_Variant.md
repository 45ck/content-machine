# AUD-010 / HCV — Haptic Caption Variant

## Reference label

AUD-010 / HCV — Haptic Caption Variant

## Classification

| Field | Value |
|---|---|
| Backlog ID | H115 |
| Method code | AUD-010 |
| Short code | HCV |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Multimodal Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / cutting-edge |
| Status | Backlog |

## Definition / what to try

For AR/wearables, use vibration patterns for emotion or emphasis.

## Mechanism

Multimodal cueing for accessibility.

## Expected direction

Better affective access in DHH contexts.

## Failure mode

Not relevant to normal TikTok yet.

## Minimum viable experiment

Lab prototype with haptic cues.

## Primary metrics

Tone recognition; workload

## Source IDs

S34; S33
