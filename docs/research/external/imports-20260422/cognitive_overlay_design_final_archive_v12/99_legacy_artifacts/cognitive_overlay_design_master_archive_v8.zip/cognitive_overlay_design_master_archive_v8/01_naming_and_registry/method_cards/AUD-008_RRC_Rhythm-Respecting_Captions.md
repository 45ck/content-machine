# AUD-008 / RRC — Rhythm-Respecting Captions

## Reference label

AUD-008 / RRC — Rhythm-Respecting Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H113 |
| Method code | AUD-008 |
| Short code | RRC |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Multimodal Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Avoid text changes on every music beat unless text is music/lyric content.

## Mechanism

Prevents text from becoming percussion.

## Expected direction

Lower fatigue in non-music clips.

## Failure mode

May reduce platform-native energy.

## Minimum viable experiment

Beat-synced vs semantic-synced.

## Primary metrics

Effort; recall

## Source IDs

S19
