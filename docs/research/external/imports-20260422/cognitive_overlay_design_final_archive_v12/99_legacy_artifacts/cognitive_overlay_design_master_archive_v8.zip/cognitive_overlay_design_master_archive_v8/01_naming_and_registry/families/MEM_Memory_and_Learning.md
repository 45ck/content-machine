# MEM — Memory and Learning

This family contains 15 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| MEM-001 | RPC | Retrieval Prompt Caption | Learning Method | Pilot second | P1 | Strong adjacent | Ask a 1-question recall prompt at the end: What reduces friction? | Prompt vs no prompt. | Delayed recall; saves |
| MEM-002 | PP | Prediction Prompt | Learning Method | Explore later | P2 | Moderate adjacent | Before solution, ask viewer to predict cause/fix. | Prediction vs direct answer. | Recall; completion |
| MEM-003 | QCE | Quick Check End Card | Learning Method | Explore later | P2 | Moderate adjacent | End with micro quiz: Motivation or structure? | Quiz vs memory phrase. | Delayed recall; comments |
| MEM-004 | SRAS | Spaced Recap Across Series | Learning Method | Explore later | P2 | Strong adjacent | Repeat same memory phrase across multiple videos with variation. | Series with/without recurring phrase. | Delayed recognition; follower retention |
| MEM-005 | TBSM | Three-Beat Schema Map | Learning Method | Pilot second | P1 | Strong adjacent | Always use a small visual map: Problem → Cause → Fix. | Map vs no map. | Sequence recall; save rate |
| MEM-006 | WEF | Worked-Example Fade | Learning Method | Explore later | P3 | Moderate adjacent | Start with full labels, then fade to minimal cues as viewer learns. | Full labels vs fading labels over series. | Transfer; fatigue |
| MEM-007 | ANA | Analogy Overlay | Learning Method | Explore later | P2 | Moderate adjacent | Add one compressed analogy for abstract ideas. | Analogy vs definition. | Delayed recall; transfer |
| MEM-008 | MCM | Mini Concept Map | Learning Method | Explore later | P2 | Moderate adjacent | Show 2–4 nodes connected during complex explanations. | Concept map vs captions. | Relation recall; effort |
| MEM-009 | BAS | Before/After State Card | Learning Method | Explore later | P2 | Speculative / direct test needed | Show old state → new state visually/textually. | Before/after vs regular caption. | Recall; perceived usefulness |
| MEM-010 | ARP | Active Recall Pause | Learning Method | Explore later | P2 | Moderate adjacent | Pause briefly after an instruction before giving answer/example. | Pause vs no pause. | Delayed recall; completion |
| MEM-011 | SALS | Save Cue as Learning Signal | Learning Method | Explore later | P2 | Speculative / direct test needed | Use a save-worthy rule card, not a begging call-to-action. | Rule card vs generic CTA. | Saves; recall |
| MEM-012 | MC | Mnemonic Compression | Learning Method | Explore later | P3 | Speculative / direct test needed | Turn takeaways into memorable parallel structures or rhymes. | Mnemonic vs plain takeaway. | Delayed recall; shares |
| MEM-013 | ACO | Action Checklist Overlay | Learning Method | Pilot second | P1 | Moderate adjacent | Convert advice into 2–3 checklist items at end. | Checklist vs memory phrase. | Action recall; saves |
| MEM-014 | EDM | Error Diagnosis Matrix | Learning Method | Explore later | P3 | Speculative / direct test needed | Show two-axis quick diagnosis: effort high / clarity low. | Matrix vs plain explanation. | Transfer; effort |
| MEM-015 | ENF | Example-Nonexample Flip | Learning Method | Explore later | P2 | Moderate adjacent | Quickly contrast a wrong and right execution. | Example-only vs example/nonexample. | Transfer; task accuracy |
