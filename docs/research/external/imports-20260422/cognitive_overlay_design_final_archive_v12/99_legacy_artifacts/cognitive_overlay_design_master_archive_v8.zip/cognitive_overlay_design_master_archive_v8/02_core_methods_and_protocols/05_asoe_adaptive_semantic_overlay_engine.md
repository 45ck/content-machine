# ASOE — Adaptive Semantic Overlay Engine

## Definition

The Adaptive Semantic Overlay Engine is the future product/system direction. It would generate and evaluate overlays using semantic extraction, visual analysis, placement rules, and experiment feedback.

## Required modules

1. Transcript ingestion.
2. Proposition extraction.
3. Semantic beat extraction.
4. Method selection.
5. Anchor selection.
6. Visual-load prediction.
7. Face/mouth/hand/object detection.
8. Platform UI safe-zone templates.
9. Gaze/saliency conflict prediction.
10. Renderer/exporter.
11. Rubric auto-scorer.
12. A/B variant generator.
13. Analytics ingestion.
