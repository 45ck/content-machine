# GAZ-003 / ASC — Action-Safe Captioning

## Reference label

GAZ-003 / ASC — Action-Safe Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H058 |
| Method code | GAZ-003 |
| Short code | ASC |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Avoid hands, products, joints, cursor, and key action path.

## Mechanism

Prevents text from stealing task-critical visual information.

## Expected direction

Better visual recall and task learning.

## Failure mode

May require dynamic object tracking.

## Minimum viable experiment

Action-covered vs action-safe.

## Primary metrics

Visual recall; task accuracy

## Source IDs

S10; S14; S15
