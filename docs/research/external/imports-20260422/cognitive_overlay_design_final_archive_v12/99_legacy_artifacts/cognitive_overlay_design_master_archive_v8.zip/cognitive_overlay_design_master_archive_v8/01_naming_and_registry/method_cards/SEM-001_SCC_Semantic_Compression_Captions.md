# SEM-001 / SCC — Semantic Compression Captions

## Reference label

SEM-001 / SCC — Semantic Compression Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H001 |
| Method code | SEM-001 |
| Short code | SCC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Rewrite spoken sentences into shortest meaning-preserving phrases.

## Mechanism

Reduces verbal load while preserving gist.

## Expected direction

Better gist/action recall than full transcript overlays.

## Failure mode

Over-compression makes captions cryptic.

## Minimum viable experiment

Full transcript vs semantic compression on same clip.

## Primary metrics

Gist recall; action recall; perceived effort

## Source IDs

S06; S07; S09; S10; S27
