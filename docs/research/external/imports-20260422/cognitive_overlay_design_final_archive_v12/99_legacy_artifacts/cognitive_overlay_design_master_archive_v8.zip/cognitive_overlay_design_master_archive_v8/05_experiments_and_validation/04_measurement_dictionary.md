# Measurement Dictionary

| Metric | Definition | Why it matters |
|---|---|---|
| Gist recall | Viewer can state the main point. | Tests rapid meaning extraction. |
| Action recall | Viewer knows what to do next. | Tests practical usefulness. |
| Contrast recall | Viewer remembers the false belief and correction. | Tests operator-first and contrast methods. |
| Exact recall | Viewer remembers specific wording. | Full captions may win here. |
| Visual recall | Viewer remembers what happened visually. | Detects if text stole too much attention. |
| Muted comprehension | Viewer understands without sound. | Tests muted-first design. |
| Perceived effort | Viewer rates difficulty. | Captures cognitive load subjectively. |
| Completion rate | Fraction of video watched. | Platform retention signal. |
| Rewatch rate | Frequency of replay. | Can indicate value or confusion. |
| Saves/shares | Platform utility/memorability signal. | Measures perceived usefulness. |
| Text dwell time | Gaze time on overlay text. | Measures visual cost. |
| Face/object dwell time | Gaze time on important visual regions. | Measures video preservation. |
| Meaning per Second | Recall/understanding divided by seconds watched. | Platform-friendly efficiency metric. |
| Meaning per Fixation | Recall/understanding divided by fixation cost. | Research-grade efficiency metric. |
