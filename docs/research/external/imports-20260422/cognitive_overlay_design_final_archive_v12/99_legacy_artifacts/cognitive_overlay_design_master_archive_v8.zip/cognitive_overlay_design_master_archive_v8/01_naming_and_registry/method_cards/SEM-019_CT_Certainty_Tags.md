# SEM-019 / CT — Certainty Tags

## Reference label

SEM-019 / CT — Certainty Tags

## Classification

| Field | Value |
|---|---|
| Backlog ID | H019 |
| Method code | SEM-019 |
| Short code | CT |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Mark claims as Rule, Hypothesis, Example, Warning, Tested.

## Mechanism

Prevents overclaiming and adds epistemic clarity.

## Expected direction

Higher trust and lower misinterpretation.

## Failure mode

May feel academic or slow.

## Minimum viable experiment

Claims with/without certainty tags.

## Primary metrics

Trust rating; misunderstanding rate

## Source IDs

S06; S07; S09; S10; S27
