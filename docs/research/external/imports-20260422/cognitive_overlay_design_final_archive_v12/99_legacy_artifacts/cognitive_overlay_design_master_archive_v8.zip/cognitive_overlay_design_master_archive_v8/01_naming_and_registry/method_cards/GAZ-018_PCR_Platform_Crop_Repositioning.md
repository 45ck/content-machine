# GAZ-018 / PCR — Platform Crop Repositioning

## Reference label

GAZ-018 / PCR — Platform Crop Repositioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H073 |
| Method code | GAZ-018 |
| Short code | PCR |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Automatically reposition overlays for TikTok, Reels, Shorts, YouTube preview.

## Mechanism

Prevents cross-platform occlusion.

## Expected direction

Higher readability after reposting.

## Failure mode

Requires platform templates.

## Minimum viable experiment

Single export vs platform-specific exports.

## Primary metrics

Occlusion rate; retention by platform

## Source IDs

S02; S28
