# TIM-004 / PWC — Pause-Window Captioning

## Reference label

TIM-004 / PWC — Pause-Window Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H044 |
| Method code | TIM-004 |
| Short code | PWC |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Place heavier text only during speech pauses or low-action moments.

## Mechanism

Avoids competing with important audiovisual input.

## Expected direction

Higher visual recall.

## Failure mode

Pauses may be too rare in fast speech.

## Minimum viable experiment

Same overlay during speech vs pauses.

## Primary metrics

Visual recall; effort

## Source IDs

S05; S10; S18
