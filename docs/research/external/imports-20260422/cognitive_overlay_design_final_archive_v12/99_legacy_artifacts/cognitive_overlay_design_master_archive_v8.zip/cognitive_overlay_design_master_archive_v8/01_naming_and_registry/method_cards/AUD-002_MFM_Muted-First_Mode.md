# AUD-002 / MFM — Muted-First Mode

## Reference label

AUD-002 / MFM — Muted-First Mode

## Classification

| Field | Value |
|---|---|
| Backlog ID | H107 |
| Method code | AUD-002 |
| Short code | MFM |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Rule / Mode |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Overlay carries enough meaning without sound.

## Mechanism

Supports sound-off viewing.

## Expected direction

Better muted comprehension.

## Failure mode

May be too much text for audio-on viewers.

## Minimum viable experiment

Muted-first vs cue-mode.

## Primary metrics

Muted gist; effort

## Source IDs

S05; S01
