# KIN-015 / MBS — Motion Budget Score

## Reference label

KIN-015 / MBS — Motion Budget Score

## Classification

| Field | Value |
|---|---|
| Backlog ID | H090 |
| Method code | KIN-015 |
| Short code | MBS |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Rule / Mode |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Limit animated overlay events per 10 seconds.

## Mechanism

Keeps motion rare and meaningful.

## Expected direction

Lower fatigue, higher clarity.

## Failure mode

Too low may feel flat on platforms.

## Minimum viable experiment

Low/medium/high motion dose.

## Primary metrics

Effort; completion; recall

## Source IDs

S19; S26
