# Platform / Retention

11 ideas/hypotheses.

| ID | Idea / Hypothesis | What to try | Mechanism to test | Expected direction | Failure mode | Minimum viable experiment | Primary metrics | Evidence grade | Priority |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| H156 | Hook Card | Use first 0.5–1.5 sec as a semantic promise. | Reduces early uncertainty and stops scroll. | Higher 1s/3s hold. | Clickbait if promise not delivered. | Hook card vs no hook card. | 1s/3s hold; comments sentiment | Moderate adjacent | P0 |
| H157 | Fast Payoff Rule | Deliver the first useful idea within 2–3 seconds. | Feeds reward prediction without deception. | Higher retention and trust. | Can compress too aggressively. | Delayed payoff vs fast payoff. | 3s hold; completion; trust | Moderate adjacent | P0 |
| H158 | Open-Loop With Early Resolution | Open a gap, resolve quickly, then deepen. | Balances curiosity and cognitive comfort. | Better completion than delayed tease. | Too much tease lowers trust. | Delayed open-loop vs early-resolution. | Completion; trust | Speculative / direct test needed | P1 |
| H159 | Progress Marker Microbar | Show Problem → Cause → Fix progress. | Reduces uncertainty about where video is going. | Higher completion for explainers. | UI clutter if overused. | With/without progress marker. | Completion; effort | Moderate adjacent | P2 |
| H160 | Chapter Chips | Tiny labels for 30–90s clips: Setup, Mistake, Fix, Rule. | Orient viewer over longer short-form. | Better retention in longer clips. | Too much structure for comedy. | Chapter chips vs none. | Completion; sequence recall | Moderate adjacent | P2 |
| H161 | Payoff Card | Use final screen as a self-contained takeaway or checklist. | Creates save/share object. | Higher saves and delayed recall. | May reduce natural loop. | Payoff card vs normal ending. | Saves; recall | Moderate adjacent | P1 |
| H162 | Comment-Eliciting Recall Prompt | Ask a non-trivial answer prompt tied to video concept. | Turns engagement into retrieval. | Higher comments and recall. | Can look engagement-bait. | Recall prompt vs CTA. | Comment quality; recall | Speculative / direct test needed | P2 |
| H163 | Platform-Native Typography Variant | Test clean professional vs TikTok-native emoji/non-standard style. | Matches audience expectations. | Higher engagement for some categories. | Can reduce professionalism/accessibility. | Clean vs native style. | Engagement; trust; comprehension | Emerging direct evidence | P2 |
| H164 | Scroll-Rescue Midpoint Reset | At 40–60%, add a new semantic hook or map update. | Prevents attention decay. | Higher completion. | Feels artificial if not content-driven. | Midpoint reset vs none. | Completion curve; rewatch | Speculative / direct test needed | P2 |
| H165 | Loop-Compatible Ending | End with text that connects to first frame without hiding final meaning. | Encourages rewatch while preserving clarity. | Higher rewatch. | May annoy if obvious. | Loop ending vs hard stop. | Rewatch; recall | Speculative / direct test needed | P2 |
| H166 | Ethical Retention Filter | Reject overlays that increase watch time by confusion instead of clarity. | Optimizes for useful attention. | Better trust and long-term audience quality. | Hard to quantify. | Qualitative review + retention metrics. | Clarification comments; trust | Speculative / governance | P0 |
