# GAZ-011 / SRTL — Screen-Recording Target Labels

## Reference label

GAZ-011 / SRTL — Screen-Recording Target Labels

## Classification

| Field | Value |
|---|---|
| Backlog ID | H066 |
| Method code | GAZ-011 |
| Short code | SRTL |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Place labels near the cursor/control being discussed.

## Mechanism

Reduces split attention in UI tutorials.

## Expected direction

Better procedural recall.

## Failure mode

Can obscure UI targets.

## Minimum viable experiment

Bottom captions vs target labels.

## Primary metrics

Task accuracy; gaze path

## Source IDs

S10; S14
