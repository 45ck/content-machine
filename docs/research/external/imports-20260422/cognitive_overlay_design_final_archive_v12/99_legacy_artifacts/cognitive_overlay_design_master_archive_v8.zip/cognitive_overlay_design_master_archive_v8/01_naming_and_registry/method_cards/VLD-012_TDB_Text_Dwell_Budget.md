# VLD-012 / TDB — Text Dwell Budget

## Reference label

VLD-012 / TDB — Text Dwell Budget

## Classification

| Field | Value |
|---|---|
| Backlog ID | H102 |
| Method code | VLD-012 |
| Short code | TDB |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Rule / Mode |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Limit total seconds of on-screen text per 10 seconds of video.

## Mechanism

Prevents turning video into reading task.

## Expected direction

Better visual recall and lower fatigue.

## Failure mode

Muted viewers may need more text.

## Minimum viable experiment

Low/medium/high dwell budgets.

## Primary metrics

Visual recall; effort; muted comprehension

## Source IDs

S05; S10; S26
