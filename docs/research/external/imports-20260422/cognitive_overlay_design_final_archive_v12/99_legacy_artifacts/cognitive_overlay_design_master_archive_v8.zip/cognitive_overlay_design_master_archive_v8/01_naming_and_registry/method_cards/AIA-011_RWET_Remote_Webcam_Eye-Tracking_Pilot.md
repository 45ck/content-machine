# AIA-011 / RWET — Remote Webcam Eye-Tracking Pilot

## Reference label

AIA-011 / RWET — Remote Webcam Eye-Tracking Pilot

## Classification

| Field | Value |
|---|---|
| Backlog ID | H151 |
| Method code | AIA-011 |
| Short code | RWET |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | Adaptive System |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use webcam gaze estimation for rough large-sample placement tests.

## Mechanism

Scales beyond lab eye-tracking.

## Expected direction

Cheap gaze proxy.

## Failure mode

Lower accuracy than lab hardware.

## Minimum viable experiment

Webcam vs self-report vs subset eye tracker.

## Primary metrics

Gaze estimates; recall

## Source IDs

S30
