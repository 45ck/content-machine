# CTL-004 / HBF — Heavy Bionic Formatting

## Reference label

CTL-004 / HBF — Heavy Bionic Formatting

## Classification

| Field | Value |
|---|---|
| Backlog ID | H170 |
| Method code | CTL-004 |
| Short code | HBF |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P0 |
| Evidence grade | Negative control |
| Status | Backlog |

## Definition / what to try

Apply bionic partial bolding to most words.

## Mechanism

Tests whether heavy bionic hurts.

## Expected direction

Likely underperforms sparse anchors.

## Failure mode

Can look novel but noisy.

## Minimum viable experiment

Compare to BCC and compression.

## Primary metrics

Recall; saccades; effort

## Source IDs

S22; S23
