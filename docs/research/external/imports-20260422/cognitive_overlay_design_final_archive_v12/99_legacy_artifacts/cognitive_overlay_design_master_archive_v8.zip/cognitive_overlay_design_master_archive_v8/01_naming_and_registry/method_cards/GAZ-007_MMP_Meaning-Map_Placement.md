# GAZ-007 / MMP — Meaning-Map Placement

## Reference label

GAZ-007 / MMP — Meaning-Map Placement

## Classification

| Field | Value |
|---|---|
| Backlog ID | H062 |
| Method code | GAZ-007 |
| Short code | MMP |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Place text where it supports the semantic region of the scene.

## Mechanism

Combines semantic value with gaze tendencies.

## Expected direction

Better comprehension than visually loud placement.

## Failure mode

Meaning maps hard to automate.

## Minimum viable experiment

Meaning-aware vs low-level saliency placement.

## Primary metrics

Gist recall; gaze alignment

## Source IDs

S11; S12
