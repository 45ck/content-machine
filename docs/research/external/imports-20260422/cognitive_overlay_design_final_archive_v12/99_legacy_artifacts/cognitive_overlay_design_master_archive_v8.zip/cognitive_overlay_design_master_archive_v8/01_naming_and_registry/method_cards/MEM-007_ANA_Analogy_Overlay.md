# MEM-007 / ANA — Analogy Overlay

## Reference label

MEM-007 / ANA — Analogy Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H122 |
| Method code | MEM-007 |
| Short code | ANA |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Add one compressed analogy for abstract ideas.

## Mechanism

Concrete mapping helps memory.

## Expected direction

Better delayed recall for abstract concepts.

## Failure mode

Bad analogies mislead.

## Minimum viable experiment

Analogy vs definition.

## Primary metrics

Delayed recall; transfer

## Source IDs

S09
