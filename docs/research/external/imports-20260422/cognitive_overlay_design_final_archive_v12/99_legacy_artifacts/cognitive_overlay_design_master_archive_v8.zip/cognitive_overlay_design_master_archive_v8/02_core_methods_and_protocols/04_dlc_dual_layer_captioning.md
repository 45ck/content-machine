# DLC — Dual-Layer Captioning

## Definition

Dual-Layer Captioning separates accessibility captions from creative semantic overlays.

## Layer 1: Closed captions

Full synchronized captions preserve speech, speaker identification, and meaningful non-speech audio.

## Layer 2: Semantic overlay

A separate overlay presents compressed meaning for retention, gist, and muted-first comprehension.

## Why this matters

BCC/BCC+ should not replace full captions. The semantic overlay can be punchy and compressed, but viewers still need access to the full spoken content where necessary.
