# KIN-004 / FDA — Friction Drag Animation

## Reference label

KIN-004 / FDA — Friction Drag Animation

## Classification

| Field | Value |
|---|---|
| Backlog ID | H079 |
| Method code | KIN-004 |
| Short code | FDA |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Make the word friction move slowly or resist movement.

## Mechanism

Embodied metaphor supports concept.

## Expected direction

Higher memory for abstract terms.

## Failure mode

Metaphor may be too literal.

## Minimum viable experiment

Static concept vs metaphor motion.

## Primary metrics

Concept recall; preference

## Source IDs

S19
