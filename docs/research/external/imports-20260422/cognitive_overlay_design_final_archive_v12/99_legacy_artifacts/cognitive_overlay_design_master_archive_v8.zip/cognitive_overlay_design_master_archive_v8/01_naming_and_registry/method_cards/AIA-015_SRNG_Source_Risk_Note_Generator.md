# AIA-015 / SRNG — Source/Risk Note Generator

## Reference label

AIA-015 / SRNG — Source/Risk Note Generator

## Classification

| Field | Value |
|---|---|
| Backlog ID | H155 |
| Method code | AIA-015 |
| Short code | SRNG |
| Category | AI / Adaptive |
| Family | AI and Adaptive Systems |
| Class | System Module |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

For research/health/finance clips, overlay flags if claim is advice, evidence, or speculation.

## Mechanism

Reduces misinformation risk.

## Expected direction

Higher trust and fewer overclaims.

## Failure mode

May reduce punchiness.

## Minimum viable experiment

No risk note vs risk-tagged version.

## Primary metrics

Trust; comments; comprehension

## Source IDs

S11; S12; S14; S30; S31
