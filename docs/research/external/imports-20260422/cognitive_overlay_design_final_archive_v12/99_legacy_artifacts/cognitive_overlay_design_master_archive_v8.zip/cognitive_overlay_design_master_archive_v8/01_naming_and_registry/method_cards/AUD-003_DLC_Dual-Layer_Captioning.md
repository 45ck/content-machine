# AUD-003 / DLC — Dual-Layer Captioning

## Reference label

AUD-003 / DLC — Dual-Layer Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H108 |
| Method code | AUD-003 |
| Short code | DLC |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Multimodal Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Full closed captions plus separate semantic overlay.

## Mechanism

Preserves accessibility while enabling retention design.

## Expected direction

Best overall access + gist.

## Failure mode

Can create clutter if poorly placed.

## Minimum viable experiment

Closed captions only vs dual-layer.

## Primary metrics

Access rating; gist; clutter

## Source IDs

S01; S02; S05
