# SEM-007 / CEP — Claim–Evidence–Payoff Overlay

## Reference label

SEM-007 / CEP — Claim–Evidence–Payoff Overlay

## Classification

| Field | Value |
|---|---|
| Backlog ID | H007 |
| Method code | SEM-007 |
| Short code | CEP |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Label claim, proof, and takeaway as separate beats.

## Mechanism

Helps viewers trust and encode the argument.

## Expected direction

Higher credibility and save rate.

## Failure mode

May reduce emotional flow.

## Minimum viable experiment

Advice clip with claim/payoff labels vs no labels.

## Primary metrics

Credibility rating; saves

## Source IDs

S06; S07; S09; S10; S27
