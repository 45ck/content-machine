# KIN-011 / OAC — Object-Attached Captions

## Reference label

KIN-011 / OAC — Object-Attached Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H086 |
| Method code | KIN-011 |
| Short code | OAC |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Caption moves with object or hand only when labeling it.

## Mechanism

Maintains spatial binding.

## Expected direction

Better tutorial comprehension.

## Failure mode

Motion tracking failure distracts.

## Minimum viable experiment

Attached label vs static caption.

## Primary metrics

Task recall; gaze path

## Source IDs

S14; S19
