# TYP-015 / CR — Capitalization Rhythm

## Reference label

TYP-015 / CR — Capitalization Rhythm

## Classification

| Field | Value |
|---|---|
| Backlog ID | H035 |
| Method code | TYP-015 |
| Short code | CR |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use case intentionally: title case for labels, sentence case for ideas.

## Mechanism

Improves scan hierarchy.

## Expected direction

Lower effort.

## Failure mode

All-caps may reduce readability and feel shouty.

## Minimum viable experiment

Case variants.

## Primary metrics

Effort; retention

## Source IDs

S21; S28
