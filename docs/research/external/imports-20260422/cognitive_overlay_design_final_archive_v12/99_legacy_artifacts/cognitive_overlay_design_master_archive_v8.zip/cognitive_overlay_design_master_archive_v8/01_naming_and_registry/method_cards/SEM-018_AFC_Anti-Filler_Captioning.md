# SEM-018 / AFC — Anti-Filler Captioning

## Reference label

SEM-018 / AFC — Anti-Filler Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H018 |
| Method code | SEM-018 |
| Short code | AFC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Remove basically, actually, kind of, really, and redundant phrases.

## Mechanism

Reduces visual noise.

## Expected direction

Improved perceived clarity.

## Failure mode

Overediting may alter speaker voice.

## Minimum viable experiment

Auto-filler removal vs verbatim.

## Primary metrics

Effort; clarity rating

## Source IDs

S06; S07; S09; S10; S27
