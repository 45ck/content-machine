# CTL — Controls and Failure Modes

This family contains 12 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| CTL-001 | FTO | Full Transcript Overlay | Control / Baseline | Experiment control | P0 | Control | Use complete burned-in transcript as baseline. | Compare against compression/BCC. | Exact recall; effort |
| CTL-002 | KHT | Keyword Highlight Transcript | Control / Baseline | Experiment control | P0 | Control | Highlight important words inside full transcript. | Compare to semantic compression. | Gist; effort |
| CTL-003 | WWDC | Word-by-Word Dynamic Caption | Control / Baseline | Experiment control | P0 | Control | Active word highlight following speech. | Compare to semantic beats. | Gist; fatigue |
| CTL-004 | HBF | Heavy Bionic Formatting | Control / Baseline | Experiment control | P0 | Negative control | Apply bionic partial bolding to most words. | Compare to BCC and compression. | Recall; saccades; effort |
| CTL-005 | ROW | RSVP One-Word Captions | Control / Baseline | Experiment control | P1 | Negative control | One word at a time in same spot. | Compare to semantic beats. | Comprehension; fatigue |
| CTL-006 | CKT | Constant Kinetic Text | Control / Baseline | Experiment control | P1 | Negative control | Every word moves or pops. | Compare to logic motion. | Recall; fatigue; retention |
| CTL-007 | NNO | No Overlay / Native Captions Only | Control / Baseline | Experiment control | P0 | Control | Baseline platform state. | Compare to all variants. | Gist; visual recall; retention |
| CTL-008 | COM | Color-Only Meaning | Control / Baseline | Experiment control | P1 | Negative control | Use color without labels/icons for semantic roles. | Compare to color+label. | Role ID; access rating |
| CTL-009 | BOP | Bottom-Only Placement | Control / Baseline | Experiment control | P0 | Control | Always lower-third regardless of content. | Compare to gaze-safe. | Occlusion; readability |
| CTL-010 | RSP | Random Saliency Pop | Control / Baseline | Experiment control | P1 | Negative control | Make random words visually pop. | Compare to semantic cueing. | Gist; trust |
| CTL-011 | HDCS | High-Density Caption Stack | Control / Baseline | Experiment control | P1 | Negative control | Multiple overlays/captions/stickers simultaneously. | Compare to budgeted text. | Readability; effort |
| CTL-012 | ENS | Emoji/Nonstandard Subtitle Variant | Control / Baseline | Experiment control | P2 | Emerging direct evidence | Use platform-native non-standard typography and emoji. | Compare with clean captioning by category. | Engagement; trust; comprehension |
