# TIM-001 / PSP — Predictive Semantic Priming

## Reference label

TIM-001 / PSP — Predictive Semantic Priming

## Classification

| Field | Value |
|---|---|
| Backlog ID | H041 |
| Method code | TIM-001 |
| Short code | PSP |
| Category | Timing / Rhythm |
| Family | Timing and Rhythm |
| Class | Timing Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Show compressed meaning 200–400 ms before the speaker lands it.

## Mechanism

Reduces prediction load and primes interpretation.

## Expected direction

Better comprehension and smoother processing.

## Failure mode

Too early feels spoiler-like or mismatched.

## Minimum viable experiment

Pre-cue vs sync vs post-cue.

## Primary metrics

Gist recall; smoothness; effort

## Source IDs

S09; S27; S29
