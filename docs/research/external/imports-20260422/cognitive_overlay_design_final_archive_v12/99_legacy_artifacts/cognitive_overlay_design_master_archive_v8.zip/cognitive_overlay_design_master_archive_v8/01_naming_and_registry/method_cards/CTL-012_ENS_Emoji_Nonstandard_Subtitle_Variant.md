# CTL-012 / ENS — Emoji/Nonstandard Subtitle Variant

## Reference label

CTL-012 / ENS — Emoji/Nonstandard Subtitle Variant

## Classification

| Field | Value |
|---|---|
| Backlog ID | H178 |
| Method code | CTL-012 |
| Short code | ENS |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P2 |
| Evidence grade | Emerging direct evidence |
| Status | Backlog |

## Definition / what to try

Use platform-native non-standard typography and emoji.

## Mechanism

Tests TikTok-native engagement signal.

## Expected direction

Could increase engagement for informal categories.

## Failure mode

May harm accessibility/professionalism.

## Minimum viable experiment

Compare with clean captioning by category.

## Primary metrics

Engagement; trust; comprehension

## Source IDs

S21; S28
