# AIA — AI and Adaptive Systems

This family contains 15 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| AIA-001 | SBE | Semantic Beat Extractor | System Module | Pilot second | P1 | Speculative / direct test needed | LLM extracts proposition, role, and beat boundaries from transcript. | Human vs AI beat extraction. | Edit distance; accuracy; time saved |
| AIA-002 | GEN | Overlay Variant Generator | System Module | Pilot second | P1 | Strong practical / direct test needed | Auto-generates transcript, keyword, compression, BCC, BCC+, and controls. | Manual vs generated variants. | Production time; quality score |
| AIA-003 | SHP | Saliency Heatmap Placement | Adaptive System | Pilot second | P1 | Moderate adjacent | Predict likely gaze heatmaps and avoid high-conflict zones. | Fixed vs saliency-aware placement. | Visual recall; occlusion rate |
| AIA-004 | FMHO | Face/Mouth/Hand/Object Detector | System Module | Pilot first | P0 | Strong practical / direct test needed | Detect visual regions that should not be covered. | Manual vs CV safe-zone detection. | Occlusion errors; readability |
| AIA-005 | VLP | Visual Load Predictor | System Module | Pilot second | P1 | Speculative / direct test needed | Estimate per-frame visual complexity to choose word count. | Human-coded vs model-coded load. | Prediction validity; recall |
| AIA-006 | GSWE | Gaze Simulation Without Eye Tracker | Adaptive System | Explore later | P2 | Speculative / direct test needed | Use saliency/meaning maps to simulate likely gaze conflict. | Model score vs user gaze subset. | Correlation with gaze/errors |
| AIA-007 | ABG | Automatic A/B Generator | System Module | Pilot second | P1 | Strong practical / direct test needed | Generate and track variants across platforms. | Randomized content batches. | Variant lift; confidence intervals |
| AIA-008 | BRAS | BCC+ Rubric Auto-Scorer | System Module | Pilot second | P1 | Moderate adjacent | Score compression, anchors, placement, load, contrast, muted clarity. | Rubric vs no rubric production. | Failure rate; pilot performance |
| AIA-009 | PSZT | Platform Safe-Zone Templates | Adaptive System | Pilot first | P0 | Strong practical / direct test needed | Reusable templates for TikTok/Reels/Shorts/Stories UI zones. | Template vs manual export. | Occlusion rate by platform |
| AIA-010 | CRO | Compression Ratio Optimizer | System Module | Explore later | P2 | Speculative / future | Suggest percent transcript to display based on speech rate/visual load. | Heuristic vs learned optimizer. | Gist/effort efficiency |
| AIA-011 | RWET | Remote Webcam Eye-Tracking Pilot | Adaptive System | Explore later | P3 | Speculative / direct test needed | Use webcam gaze estimation for rough large-sample placement tests. | Webcam vs self-report vs subset eye tracker. | Gaze estimates; recall |
| AIA-012 | MPFE | Meaning-Per-Fixation Estimator | Adaptive System | Explore later | P3 | Speculative / future | Combine recall results and gaze/text dwell to estimate efficiency. | Estimate vs actual recall. | Predictive validity |
| AIA-013 | AR | Adaptive Renderer | System Module | Explore later | P2 | Speculative / future | Renders overlays based on detected shot type and visual load. | Manual vs adaptive renderer. | Quality; retention; revision count |
| AIA-014 | HLE | Human-in-the-Loop Editor | Adaptive System | Pilot first | P0 | Strong practical / direct test needed | AI proposes; editor approves proposition, anchor, placement, timing. | AI-only vs human-in-loop. | Accuracy; time saved |
| AIA-015 | SRNG | Source/Risk Note Generator | System Module | Explore later | P2 | Speculative / direct test needed | For research/health/finance clips, overlay flags if claim is advice, evidence, or speculation. | No risk note vs risk-tagged version. | Trust; comments; comprehension |
