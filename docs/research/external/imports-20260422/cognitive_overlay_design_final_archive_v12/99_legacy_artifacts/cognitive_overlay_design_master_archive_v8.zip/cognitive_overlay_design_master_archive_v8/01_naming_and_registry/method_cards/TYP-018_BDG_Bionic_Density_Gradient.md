# TYP-018 / BDG — Bionic Density Gradient

## Reference label

TYP-018 / BDG — Bionic Density Gradient

## Classification

| Field | Value |
|---|---|
| Backlog ID | H038 |
| Method code | TYP-018 |
| Short code | BDG |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Weak / contested |
| Status | Backlog |

## Definition / what to try

Test no bionic, one word bionic, all concepts bionic, all words bionic.

## Mechanism

Find safe bionic dose.

## Expected direction

Sparse bionic may win; heavy loses.

## Failure mode

If no effect, drop bionic component.

## Minimum viable experiment

Dose-response bionic experiment.

## Primary metrics

Recall; saccades; effort

## Source IDs

S22; S23
