# TYP-013 / TTT — Typeface Trust Test

## Reference label

TYP-013 / TTT — Typeface Trust Test

## Classification

| Field | Value |
|---|---|
| Backlog ID | H033 |
| Method code | TYP-013 |
| Short code | TTT |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Compare clean sans, condensed bold, handwritten, meme style.

## Mechanism

Typography may affect credibility and platform-native feel.

## Expected direction

Different winning fonts by content type.

## Failure mode

Aesthetic preference may mask comprehension.

## Minimum viable experiment

Font variants with same text.

## Primary metrics

Trust; retention; recall

## Source IDs

S21; S28
