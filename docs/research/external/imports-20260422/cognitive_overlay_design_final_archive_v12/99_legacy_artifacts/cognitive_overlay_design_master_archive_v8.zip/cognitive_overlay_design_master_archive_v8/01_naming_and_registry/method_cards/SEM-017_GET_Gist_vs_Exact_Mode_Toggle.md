# SEM-017 / GET — Gist vs Exact Mode Toggle

## Reference label

SEM-017 / GET — Gist vs Exact Mode Toggle

## Classification

| Field | Value |
|---|---|
| Backlog ID | H017 |
| Method code | SEM-017 |
| Short code | GET |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Rule / Mode |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Use gist overlay for retention, closed captions for exact speech.

## Mechanism

Separates creative and accessibility functions.

## Expected direction

Better overall satisfaction with accessibility preserved.

## Failure mode

Requires platform support or extra production effort.

## Minimum viable experiment

Full captions plus gist overlay vs overlay alone.

## Primary metrics

Preference; comprehension; access rating

## Source IDs

S01; S05; S09; S10
