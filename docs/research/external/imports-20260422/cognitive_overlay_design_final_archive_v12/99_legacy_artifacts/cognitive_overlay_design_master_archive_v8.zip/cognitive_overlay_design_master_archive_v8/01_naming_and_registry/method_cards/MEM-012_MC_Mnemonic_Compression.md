# MEM-012 / MC — Mnemonic Compression

## Reference label

MEM-012 / MC — Mnemonic Compression

## Classification

| Field | Value |
|---|---|
| Backlog ID | H127 |
| Method code | MEM-012 |
| Short code | MC |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Turn takeaways into memorable parallel structures or rhymes.

## Mechanism

Phonological/structural memory support.

## Expected direction

Better delayed recall.

## Failure mode

Can sound gimmicky.

## Minimum viable experiment

Mnemonic vs plain takeaway.

## Primary metrics

Delayed recall; shares

## Source IDs

S09; S27
