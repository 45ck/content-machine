# MEM-009 / BAS — Before/After State Card

## Reference label

MEM-009 / BAS — Before/After State Card

## Classification

| Field | Value |
|---|---|
| Backlog ID | H124 |
| Method code | MEM-009 |
| Short code | BAS |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Show old state → new state visually/textually.

## Mechanism

Encodes transformation.

## Expected direction

Better motivation and recall.

## Failure mode

Oversimplifies gradual changes.

## Minimum viable experiment

Before/after vs regular caption.

## Primary metrics

Recall; perceived usefulness

## Source IDs

S09; S10; S17; S27; S30
