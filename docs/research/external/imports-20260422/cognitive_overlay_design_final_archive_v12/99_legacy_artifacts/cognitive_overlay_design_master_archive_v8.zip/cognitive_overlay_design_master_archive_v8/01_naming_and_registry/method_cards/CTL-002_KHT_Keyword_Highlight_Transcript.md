# CTL-002 / KHT — Keyword Highlight Transcript

## Reference label

CTL-002 / KHT — Keyword Highlight Transcript

## Classification

| Field | Value |
|---|---|
| Backlog ID | H168 |
| Method code | CTL-002 |
| Short code | KHT |
| Category | Negative Control |
| Family | Controls and Failure Modes |
| Class | Control / Baseline |
| Phase | Experiment control |
| Priority | P0 |
| Evidence grade | Control |
| Status | Backlog |

## Definition / what to try

Highlight important words inside full transcript.

## Mechanism

Commercial-style baseline.

## Expected direction

Moderate improvement over full transcript.

## Failure mode

Still contains too many words.

## Minimum viable experiment

Compare to semantic compression.

## Primary metrics

Gist; effort

## Source IDs

S08; S09
