# SEM-011 / MVC — Minimal Verb Captioning

## Reference label

SEM-011 / MVC — Minimal Verb Captioning

## Classification

| Field | Value |
|---|---|
| Backlog ID | H011 |
| Method code | SEM-011 |
| Short code | MVC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Preserve verbs over nouns when showing fewer words.

## Mechanism

Actions drive what to do next.

## Expected direction

Better instruction recall.

## Failure mode

May lose conceptual nuance.

## Minimum viable experiment

Verb-heavy vs noun-heavy compression.

## Primary metrics

Action recall

## Source IDs

S06; S07; S09; S10; S27
