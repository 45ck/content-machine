# KIN-012 / GST — Gesture-Synced Text

## Reference label

KIN-012 / GST — Gesture-Synced Text

## Classification

| Field | Value |
|---|---|
| Backlog ID | H087 |
| Method code | KIN-012 |
| Short code | GST |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Reveal instruction exactly when hand gesture demonstrates it.

## Mechanism

Aligns temporal/spatial cues.

## Expected direction

Better procedural learning.

## Failure mode

Mistimed sync harms clarity.

## Minimum viable experiment

Gesture-sync vs off-sync.

## Primary metrics

Task accuracy; recall

## Source IDs

S09; S29
