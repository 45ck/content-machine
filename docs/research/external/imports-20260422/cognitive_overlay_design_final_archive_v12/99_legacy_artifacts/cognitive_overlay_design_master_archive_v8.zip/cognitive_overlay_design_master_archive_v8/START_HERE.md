# Start Here

This project is a research and production system for short-form video overlays. It began with the idea of combining compressed captions with bionic-style emphasis, then expanded into a broader field: **Cognitive Overlay Design**.

## One-sentence summary

**Cognitive Overlay Design** is about making short-form video easier to understand by showing fewer, better, better-timed, better-placed words.

## The core sequence

1. **SCC — Semantic Compression Captions**: rewrite speech into compact meaning.
2. **BCC — Bionic Compression Captioning**: add operator anchors and bionic concept anchors.
3. **BCC+ — Bionic Compression Captioning Plus**: add gaze-safe placement, visual-load adaptation, muted-first design, micro-rest rhythm, and full captions.
4. **ASOE — Adaptive Semantic Overlay Engine**: future automated system that chooses and renders overlays.

## The first experiment to run

| Condition | Code | Purpose |
|---|---|---|
| Native captions only | NCO | Baseline |
| Full transcript overlay | FTO | Verbatim overlay baseline |
| Keyword highlight transcript | KHT | Existing tool comparison |
| Semantic compression | SCC | Tests compression |
| Bionic compression captioning | BCC | Tests bionic anchors after compression |
| BCC+ | BCC+ | Tests adaptive placement/density system |
| Heavy bionic control | HBC | Negative/noisy bionic control |

## Most important comparison

> **SCC vs BCC** tells us whether bionic anchors add value beyond compression.

## Second most important comparison

> **BCC vs BCC+** tells us whether gaze-safe placement and visual-load adaptation matter more than typography.
