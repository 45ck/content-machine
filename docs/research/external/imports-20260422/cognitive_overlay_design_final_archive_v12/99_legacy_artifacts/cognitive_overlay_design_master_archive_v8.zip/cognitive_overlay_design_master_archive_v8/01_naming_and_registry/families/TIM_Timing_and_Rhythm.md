# TIM — Timing and Rhythm

This family contains 15 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| TIM-001 | PSP | Predictive Semantic Priming | Timing Method | Pilot first | P0 | Moderate adjacent | Show compressed meaning 200–400 ms before the speaker lands it. | Pre-cue vs sync vs post-cue. | Gist recall; smoothness; effort |
| TIM-002 | SLSB | Sync-Locked Semantic Beat | Timing Method | Pilot second | P1 | Strong adjacent | Show the overlay exactly when the semantic beat is spoken. | Sync vs pre/post. | Comprehension; preference |
| TIM-003 | PCC | Post-Cue Confirmation | Timing Method | Explore later | P2 | Moderate adjacent | Display a summary immediately after the sentence. | Post-cue vs sync. | Delayed recall; completion |
| TIM-004 | PWC | Pause-Window Captioning | Timing Method | Pilot second | P1 | Moderate adjacent | Place heavier text only during speech pauses or low-action moments. | Same overlay during speech vs pauses. | Visual recall; effort |
| TIM-005 | BAC | Breath-Aligned Captions | Timing Method | Explore later | P2 | Speculative / direct test needed | Use natural speech breaths to segment caption events. | Breath-aligned vs uniform timing. | Comfort; completion |
| TIM-006 | CLR | Cut-Locked Reveal | Timing Method | Explore later | P2 | Moderate adjacent | Reveal caption on visual cut or camera movement boundary. | Cut-locked vs mid-shot reveal. | First fixation; recall |
| TIM-007 | MEG | Minimum Exposure Guardrail | Timing Method | Pilot first | P0 | Strong adjacent | No caption shorter than 0.8 sec except one-word impact beats. | Min duration on/off variants. | Missed caption rate; effort |
| TIM-008 | MRR | Micro-Rest Rhythm | Timing Method | Pilot second | P1 | Moderate adjacent | Insert brief no-text gaps between semantic beats. | Continuous text vs micro-rest. | Visual recall; effort; completion |
| TIM-009 | ABS | Attentional-Blink Spacing | Timing Method | Explore later | P2 | Moderate adjacent | Avoid presenting two critical words within 200–500 ms. | Critical words close vs spaced. | Second-keyword recall |
| TIM-010 | TMD | Tempo-Matched Density | Timing Method | Pilot second | P1 | Strong adjacent | Decrease word count as speech tempo rises. | Fixed density vs tempo-adaptive. | Gist recall; effort |
| TIM-011 | CRP | Caption Refractory Period | Timing Method | Explore later | P2 | Speculative / direct test needed | After an emphasized word, hold visual quiet for a beat. | Immediate next text vs refractory gap. | Keyword recall; completion |
| TIM-012 | LFMS | Last-Frame Memory Stamp | Timing Method | Pilot second | P1 | Moderate adjacent | Hold final takeaway for the last 0.8–1.5 sec. | With/without final stamp. | Delayed recall; saves |
| TIM-013 | LCC | Loop Callback Caption | Timing Method | Explore later | P2 | Speculative / direct test needed | End with a phrase that reinterprets the opening hook. | Callback vs generic ending. | Completion; rewatch |
| TIM-014 | SAC | Speed-Adaptive Captions | Timing Method | Explore later | P3 | Speculative / direct test needed | Detect playback speed or speech rate and adjust overlay density. | Manual fast/slow variants. | Comprehension by speech rate |
| TIM-015 | OBS | On-Beat Silence | Timing Method | Explore later | P2 | Moderate adjacent | Use no text during important sounds, laughs, or music drops. | Text during sound vs no text + sound cue. | Enjoyment; comprehension |
