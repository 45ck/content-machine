# VLD-003 / BBAP — Busy Background Auto-Plate

## Reference label

VLD-003 / BBAP — Busy Background Auto-Plate

## Classification

| Field | Value |
|---|---|
| Backlog ID | H093 |
| Method code | VLD-003 |
| Short code | BBAP |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Add a soft plate behind text only when background is complex.

## Mechanism

Improves readability with minimal obstruction.

## Expected direction

Fewer missed captions.

## Failure mode

Plate may cover important visuals.

## Minimum viable experiment

Auto plate vs always/never plate.

## Primary metrics

Readability; aesthetic rating

## Source IDs

S15; S28
