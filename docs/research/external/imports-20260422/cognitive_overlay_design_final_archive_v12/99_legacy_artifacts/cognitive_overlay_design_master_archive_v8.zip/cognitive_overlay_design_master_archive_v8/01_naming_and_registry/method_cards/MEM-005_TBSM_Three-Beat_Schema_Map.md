# MEM-005 / TBSM — Three-Beat Schema Map

## Reference label

MEM-005 / TBSM — Three-Beat Schema Map

## Classification

| Field | Value |
|---|---|
| Backlog ID | H120 |
| Method code | MEM-005 |
| Short code | TBSM |
| Category | Memory / Learning |
| Family | Memory and Learning |
| Class | Learning Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong adjacent |
| Status | Backlog |

## Definition / what to try

Always use a small visual map: Problem → Cause → Fix.

## Mechanism

Builds reusable cognitive scaffold.

## Expected direction

Better sequence recall.

## Failure mode

Can become predictable.

## Minimum viable experiment

Map vs no map.

## Primary metrics

Sequence recall; save rate

## Source IDs

S09; S17
