# Project Overview

The project defines and tests a new family of short-form video overlay methods. The initial idea was to combine compressed captions with bionic-style emphasis. The research direction expanded into a full design/research framework called **Cognitive Overlay Design**.

## Problem

Short-form videos are watched under hostile cognitive conditions: small screens, fast scroll behavior, UI clutter, moving visuals, speech, captions, music, and frequent muted viewing. Normal captions preserve speech, but they do not necessarily optimize for rapid gist extraction, action recall, or watch-time clarity.

## Central design problem

How can we help a viewer understand more with fewer fixations, less gaze travel, and lower visual-verbal load?

## Proposed answer

Use semantic overlays that compress the spoken message into compact meaning units, place those units where they do not block important visual information, time them to semantic beats, and preserve full captions separately for accessibility.

## Current research position

The strongest mechanism is not bionic reading. The strongest mechanism is:

> Semantic compression + signaling + gaze-safe placement + visual-load adaptation.

Bionic-style anchoring should be tested as an optional attention/memory cue, not assumed to improve reading speed.
