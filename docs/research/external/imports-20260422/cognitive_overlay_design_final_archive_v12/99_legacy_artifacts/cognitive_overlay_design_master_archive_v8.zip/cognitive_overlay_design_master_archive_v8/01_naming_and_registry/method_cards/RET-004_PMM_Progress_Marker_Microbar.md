# RET-004 / PMM — Progress Marker Microbar

## Reference label

RET-004 / PMM — Progress Marker Microbar

## Classification

| Field | Value |
|---|---|
| Backlog ID | H159 |
| Method code | RET-004 |
| Short code | PMM |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Show Problem → Cause → Fix progress.

## Mechanism

Reduces uncertainty about where video is going.

## Expected direction

Higher completion for explainers.

## Failure mode

UI clutter if overused.

## Minimum viable experiment

With/without progress marker.

## Primary metrics

Completion; effort

## Source IDs

S09; S25
