# AUD-004 / NSS — Non-Speech Sound Cues

## Reference label

AUD-004 / NSS — Non-Speech Sound Cues

## Classification

| Field | Value |
|---|---|
| Backlog ID | H109 |
| Method code | AUD-004 |
| Short code | NSS |
| Category | Sound / Multimodal |
| Family | Sound and Multimodal |
| Class | Multimodal Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Strong requirement |
| Status | Backlog |

## Definition / what to try

Show [laughter], [music rises], [door slam] only when meaningful.

## Mechanism

Captions include meaningful audio context.

## Expected direction

Better DHH access and story context.

## Failure mode

Too many cues distract.

## Minimum viable experiment

With/without sound cues.

## Primary metrics

Comprehension; access rating

## Source IDs

S01; S03
