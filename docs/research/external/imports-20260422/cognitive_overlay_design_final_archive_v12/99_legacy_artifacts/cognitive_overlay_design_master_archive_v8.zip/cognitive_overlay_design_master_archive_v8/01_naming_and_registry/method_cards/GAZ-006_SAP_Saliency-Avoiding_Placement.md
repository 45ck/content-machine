# GAZ-006 / SAP — Saliency-Avoiding Placement

## Reference label

GAZ-006 / SAP — Saliency-Avoiding Placement

## Classification

| Field | Value |
|---|---|
| Backlog ID | H061 |
| Method code | GAZ-006 |
| Short code | SAP |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Place text away from predicted high-saliency regions unless it is a label.

## Mechanism

Reduces competition with visual content.

## Expected direction

Better visual recall.

## Failure mode

Low-saliency areas may be poor contrast.

## Minimum viable experiment

Fixed vs saliency-aware placement.

## Primary metrics

Visual recall; gaze distribution

## Source IDs

S12; S14
