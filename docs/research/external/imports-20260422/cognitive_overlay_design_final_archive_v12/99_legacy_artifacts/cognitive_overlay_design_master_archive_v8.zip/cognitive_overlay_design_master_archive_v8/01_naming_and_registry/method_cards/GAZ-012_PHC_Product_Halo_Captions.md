# GAZ-012 / PHC — Product Halo Captions

## Reference label

GAZ-012 / PHC — Product Halo Captions

## Classification

| Field | Value |
|---|---|
| Backlog ID | H067 |
| Method code | GAZ-012 |
| Short code | PHC |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Place short labels in a ring around product without covering it.

## Mechanism

Keeps product visible while explaining attributes.

## Expected direction

Better product recall.

## Failure mode

Could look cluttered.

## Minimum viable experiment

Halo labels vs caption block.

## Primary metrics

Attribute recall; visual recall

## Source IDs

S14; S15
