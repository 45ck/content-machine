# Evidence Synthesis

## Core finding

The best-supported direction is **semantic compression plus visual signaling**, not raw speed-reading. The research logic points toward reducing unnecessary text, cueing structure, preserving full captions, and placing overlays to reduce conflict with the visual scene.

## Research pillars

### Caption speed and density

Subtitle-speed research suggests that faster subtitles can reduce complete reading and comprehension. The design implication is to reduce word count rather than forcing faster reading.

### Partial captioning

Partial synchronized captioning suggests that under some conditions, not every transcript word needs to appear for comprehension to remain intact. This supports testing compressed semantic overlays.

### Signaling and multimedia learning

Signaling research supports cues that highlight relevant structure and reduce cognitive load. This supports operator anchors, beat cards, Problem → Cause → Fix structures, and sparse keyword emphasis.

### Visual physiology

Human vision is foveated, peripheral text recognition is limited, and crowding degrades recognition. Overlay text should be short, high-contrast, and placed away from clutter.

### Meaning-guided attention

Meaning can guide attention beyond low-level salience. The overlay should reveal semantic structure rather than merely attracting attention with motion/color.

### Sound-off viewing

When video is watched without sound, visual load increases because text becomes the primary verbal information channel. Muted-first overlay design is therefore a distinct mode.

### Accessibility

Full captions must remain available. Creative overlays should not replace synchronized captions for speech and meaningful non-speech audio.
