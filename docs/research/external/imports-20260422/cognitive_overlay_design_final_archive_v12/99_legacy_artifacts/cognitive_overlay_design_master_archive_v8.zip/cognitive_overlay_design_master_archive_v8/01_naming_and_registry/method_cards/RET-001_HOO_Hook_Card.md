# RET-001 / HOO — Hook Card

## Reference label

RET-001 / HOO — Hook Card

## Classification

| Field | Value |
|---|---|
| Backlog ID | H156 |
| Method code | RET-001 |
| Short code | HOO |
| Category | Platform / Retention |
| Family | Platform Retention |
| Class | Retention Method |
| Phase | Pilot first |
| Priority | P0 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use first 0.5–1.5 sec as a semantic promise.

## Mechanism

Reduces early uncertainty and stops scroll.

## Expected direction

Higher 1s/3s hold.

## Failure mode

Clickbait if promise not delivered.

## Minimum viable experiment

Hook card vs no hook card.

## Primary metrics

1s/3s hold; comments sentiment

## Source IDs

S25; S21
