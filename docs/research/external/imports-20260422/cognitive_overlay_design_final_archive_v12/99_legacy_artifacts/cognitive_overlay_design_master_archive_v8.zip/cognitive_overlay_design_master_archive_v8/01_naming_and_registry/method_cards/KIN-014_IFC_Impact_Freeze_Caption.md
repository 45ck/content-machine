# KIN-014 / IFC — Impact Freeze Caption

## Reference label

KIN-014 / IFC — Impact Freeze Caption

## Classification

| Field | Value |
|---|---|
| Backlog ID | H089 |
| Method code | KIN-014 |
| Short code | IFC |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Briefly freeze/slow frame for a complex takeaway.

## Mechanism

Gives time to encode dense idea.

## Expected direction

Higher recall for complex points.

## Failure mode

Can reduce pacing/retention.

## Minimum viable experiment

Normal speed vs freeze caption.

## Primary metrics

Recall; completion

## Source IDs

S03; S09
