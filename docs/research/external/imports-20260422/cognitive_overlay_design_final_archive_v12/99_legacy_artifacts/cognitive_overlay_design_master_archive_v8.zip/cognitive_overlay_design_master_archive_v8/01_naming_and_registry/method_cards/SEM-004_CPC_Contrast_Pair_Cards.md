# SEM-004 / CPC — Contrast Pair Cards

## Reference label

SEM-004 / CPC — Contrast Pair Cards

## Classification

| Field | Value |
|---|---|
| Backlog ID | H004 |
| Method code | SEM-004 |
| Short code | CPC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Use two-line contrasts: Not X / Y, Stop X / Start Y.

## Mechanism

Uses binary structure to reduce interpretation cost.

## Expected direction

Strong for myth-busting and advice content.

## Failure mode

Can oversimplify complex claims.

## Minimum viable experiment

Contrast pair vs normal sentence.

## Primary metrics

Gist recall; save rate

## Source IDs

S06; S07; S09; S10; S27
