# KIN-008 / MS — Motion Silence

## Reference label

KIN-008 / MS — Motion Silence

## Classification

| Field | Value |
|---|---|
| Backlog ID | H083 |
| Method code | KIN-008 |
| Short code | MS |
| Category | Motion / Kinetic |
| Family | Motion and Kinetic Text |
| Class | Motion Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Keep key ideas static while less important transitions move.

## Mechanism

Static becomes signal in a noisy platform.

## Expected direction

Better focus on key phrases.

## Failure mode

May feel low-energy.

## Minimum viable experiment

Constant motion vs motion silence.

## Primary metrics

Recall; perceived quality

## Source IDs

S19; S10
