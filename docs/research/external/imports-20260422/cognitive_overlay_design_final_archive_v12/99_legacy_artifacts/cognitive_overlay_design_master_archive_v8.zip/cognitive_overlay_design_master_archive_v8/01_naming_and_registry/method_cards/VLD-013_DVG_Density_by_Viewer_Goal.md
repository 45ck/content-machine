# VLD-013 / DVG — Density by Viewer Goal

## Reference label

VLD-013 / DVG — Density by Viewer Goal

## Classification

| Field | Value |
|---|---|
| Backlog ID | H103 |
| Method code | VLD-013 |
| Short code | DVG |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use heavier overlays for learning clips, lighter for entertainment clips.

## Mechanism

Matches intrinsic task demands.

## Expected direction

Better category-specific performance.

## Failure mode

Incorrect classification hurts.

## Minimum viable experiment

Category-specific vs universal density.

## Primary metrics

Recall; retention by category

## Source IDs

S10; S25
