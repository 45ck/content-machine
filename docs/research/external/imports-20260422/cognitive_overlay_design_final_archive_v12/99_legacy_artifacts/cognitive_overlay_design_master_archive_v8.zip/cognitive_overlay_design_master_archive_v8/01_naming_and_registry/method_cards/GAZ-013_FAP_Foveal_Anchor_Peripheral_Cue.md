# GAZ-013 / FAP — Foveal Anchor + Peripheral Cue

## Reference label

GAZ-013 / FAP — Foveal Anchor + Peripheral Cue

## Classification

| Field | Value |
|---|---|
| Backlog ID | H068 |
| Method code | GAZ-013 |
| Short code | FAP |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Explore later |
| Priority | P2 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Put readable text centrally; use peripheral arrows/icons for orientation.

## Mechanism

Matches foveal/peripheral strengths.

## Expected direction

Better orientation without peripheral reading burden.

## Failure mode

Could increase visual complexity.

## Minimum viable experiment

Text-only vs text+peripheral cue.

## Primary metrics

Gist recall; gaze travel

## Source IDs

S31; S15
