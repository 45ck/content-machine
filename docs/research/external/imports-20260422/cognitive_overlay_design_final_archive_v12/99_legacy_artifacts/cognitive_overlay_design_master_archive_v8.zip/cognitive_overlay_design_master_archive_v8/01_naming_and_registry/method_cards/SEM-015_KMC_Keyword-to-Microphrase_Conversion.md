# SEM-015 / KMC — Keyword-to-Microphrase Conversion

## Reference label

SEM-015 / KMC — Keyword-to-Microphrase Conversion

## Classification

| Field | Value |
|---|---|
| Backlog ID | H015 |
| Method code | SEM-015 |
| Short code | KMC |
| Category | Semantic / Compression |
| Family | Semantic Compression |
| Class | Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Moderate adjacent |
| Status | Backlog |

## Definition / what to try

Convert isolated keywords into 2–4 word phrase chunks.

## Mechanism

Keeps syntax while staying sparse.

## Expected direction

Better than keyword-only overlays.

## Failure mode

Slightly more text may hurt visual recall.

## Minimum viable experiment

Keywords vs microphrases.

## Primary metrics

Gist recall; visual recall

## Source IDs

S06; S07; S09; S10; S27
