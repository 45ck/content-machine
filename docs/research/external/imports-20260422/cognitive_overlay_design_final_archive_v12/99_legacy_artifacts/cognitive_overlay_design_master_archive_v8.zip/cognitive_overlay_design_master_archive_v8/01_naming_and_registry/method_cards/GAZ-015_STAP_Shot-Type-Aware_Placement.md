# GAZ-015 / STAP — Shot-Type-Aware Placement

## Reference label

GAZ-015 / STAP — Shot-Type-Aware Placement

## Classification

| Field | Value |
|---|---|
| Backlog ID | H070 |
| Method code | GAZ-015 |
| Short code | STAP |
| Category | Placement / Gaze |
| Family | Placement and Gaze |
| Class | Placement Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Use different placement rules for talking head, demo, screen recording, story.

## Mechanism

Matches visual task demands.

## Expected direction

Higher across-category performance.

## Failure mode

Requires accurate shot classification.

## Minimum viable experiment

Generic vs shot-aware placement.

## Primary metrics

Comprehension by category

## Source IDs

S12; S14
