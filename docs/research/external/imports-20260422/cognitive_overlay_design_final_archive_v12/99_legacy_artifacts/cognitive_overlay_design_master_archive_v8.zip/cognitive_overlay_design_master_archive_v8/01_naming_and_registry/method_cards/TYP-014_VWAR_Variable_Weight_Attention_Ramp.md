# TYP-014 / VWAR — Variable Weight Attention Ramp

## Reference label

TYP-014 / VWAR — Variable Weight Attention Ramp

## Classification

| Field | Value |
|---|---|
| Backlog ID | H034 |
| Method code | TYP-014 |
| Short code | VWAR |
| Category | Typography / Anchors |
| Family | Typography and Anchors |
| Class | Anchor / Typography Component |
| Phase | Explore later |
| Priority | P3 |
| Evidence grade | Speculative / direct test needed |
| Status | Backlog |

## Definition / what to try

Gradually increase weight on words as they become relevant.

## Mechanism

Smooth cueing instead of sudden pop.

## Expected direction

Better perceived smoothness.

## Failure mode

Animation could distract.

## Minimum viable experiment

Static bold vs weight ramp.

## Primary metrics

Smoothness; recall; gaze

## Source IDs

S19; S28
