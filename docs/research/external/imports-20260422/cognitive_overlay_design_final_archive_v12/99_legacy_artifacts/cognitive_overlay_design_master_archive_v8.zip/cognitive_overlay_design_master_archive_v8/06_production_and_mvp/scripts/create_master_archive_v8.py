from pathlib import Path
import csv, re, shutil, zipfile, datetime
from collections import defaultdict, Counter

base = Path('/mnt/data')
root = base / 'cognitive_overlay_design_master_archive_v8'
zip_path = base / 'cognitive_overlay_design_master_archive_v8.zip'

method_csv = base / 'cognitive_overlay_design_method_registry_v7.csv'
conditions_csv = base / 'cognitive_overlay_design_condition_codes_v7.csv'
idea_csv = base / 'cognitive_overlay_design_big_idea_bank_v6.csv'

family_codes = {
    'SEM': 'Semantic Compression',
    'TYP': 'Typography and Anchors',
    'TIM': 'Timing and Rhythm',
    'GAZ': 'Placement and Gaze',
    'KIN': 'Motion and Kinetic Text',
    'VLD': 'Visual Load and Clutter',
    'AUD': 'Sound and Multimodal',
    'MEM': 'Memory and Learning',
    'ACC': 'Accessibility and Personalization',
    'AIA': 'AI and Adaptive Systems',
    'RET': 'Platform Retention',
    'CTL': 'Controls and Failure Modes',
}

def read_csv(path):
    with path.open(newline='', encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))

def safe(s, max_len=90):
    s = re.sub(r'[—–]', '-', s or '')
    s = re.sub(r'[^A-Za-z0-9._-]+', '_', s.strip())
    s = re.sub(r'_+', '_', s).strip('_')
    return (s[:max_len] or 'item')

def md_table(rows, headers):
    out = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---']*len(headers)) + ' |']
    for row in rows:
        vals=[]
        for h in headers:
            v = row.get(h,'') if isinstance(row, dict) else row[h]
            if v is None: v=''
            v = str(v).replace('\n',' ').replace('|','\\|')
            vals.append(v)
        out.append('| ' + ' | '.join(vals) + ' |')
    return '\n'.join(out)

def write_md(rel, content):
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content.strip() + '\n', encoding='utf-8')

if root.exists():
    shutil.rmtree(root)
root.mkdir(parents=True)
methods = read_csv(method_csv)
conditions = read_csv(conditions_csv)
ideas = read_csv(idea_csv)

for folder in [
    '00_executive_summary', '01_naming_and_registry/families', '01_naming_and_registry/method_cards',
    '02_core_methods_and_protocols', '03_research_and_evidence', '04_idea_bank/families',
    '05_experiments_and_validation', '06_production_and_mvp/scripts', '07_data_assets/csv',
    '07_data_assets/workbooks', '07_data_assets/templates', '08_original_artifacts/individual_files',
    '08_original_artifacts/previous_packs_expanded', '09_archive_notes'
]:
    (root / folder).mkdir(parents=True, exist_ok=True)

# Copy assets
for f in [method_csv, conditions_csv, idea_csv]:
    if f.exists(): shutil.copy2(f, root/'07_data_assets/csv'/f.name)
for f in base.glob('*.xlsx'):
    shutil.copy2(f, root/'07_data_assets/workbooks'/f.name)
for f in base.glob('*.py'):
    shutil.copy2(f, root/'06_production_and_mvp/scripts'/f.name)
for pat in ['*.md','*.csv','*.xlsx','*.zip','*.py']:
    for f in base.glob(pat):
        if f.name.startswith('create_master_archive_v8') or f.name == zip_path.name:
            continue
        try: shutil.copy2(f, root/'08_original_artifacts/individual_files'/f.name)
        except Exception: pass
for f in base.glob('*.zip'):
    if f.name == zip_path.name: continue
    dest = root/'08_original_artifacts/previous_packs_expanded'/safe(f.stem)
    dest.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(f, 'r') as z:
            z.extractall(dest)
    except Exception:
        pass

readme = f"""
# Cognitive Overlay Design Master Archive v8

This archive consolidates the full project into one organized package: the research framing, naming system, method registry, idea bank, hypotheses, experiment plans, production workflow, MVP artifacts, data templates, source notes, and original prior workbooks/reports.

## Start here

1. Read `START_HERE.md` for the fastest orientation.
2. Use `01_naming_and_registry/00_core_vocabulary.md` to reference names consistently.
3. Use `01_naming_and_registry/02_method_registry_all.md` when choosing methods to test.
4. Use `05_experiments_and_validation/02_first_pilot.md` to run the first validation cycle.
5. Use `06_production_and_mvp/01_production_workflow.md` when building actual TikTok/Reels/Shorts assets.

## Core field hierarchy

| Level | Name | Code | Meaning |
|---|---|---|---|
| Whole field | Cognitive Overlay Design | COD | Designing on-screen text, timing, placement, motion, and emphasis to improve comprehension, attention, retention, and accessibility. |
| Short-form branch | Physiological Retention Typography | PRT | Short-form/mobile overlay design based on visual physiology, attention, working memory, saliency, fatigue, and scroll behavior. |
| Method family | Semantic Compression Captioning Family | SCCF | Methods that rewrite speech into compact meaning units rather than displaying a full transcript. |
| Core method | Semantic Compression Captions | SCC | Compression-only baseline: shortest meaning-preserving phrases. |
| Named method | Bionic Compression Captioning | BCC | SCC plus operator anchors and bionic concept anchors. |
| Advanced protocol | Bionic Compression Captioning Plus | BCC+ | BCC plus gaze-safe placement, visual-load adaptation, muted-first design, micro-rest timing, and full captions. |
| Future system | Adaptive Semantic Overlay Engine | ASOE | Automation/product system that selects, places, renders, scores, and tests overlays. |

## Project law

> Do not make viewers read faster. Engineer the video so they need fewer fixations to understand more.

## Master research question

> Does semantic compression, with or without bionic anchors and adaptive placement, improve gist recall, action recall, muted comprehension, and retention compared with full transcript overlays and word-by-word dynamic captions?

## Archive structure

| Folder | Contents |
|---|---|
| `00_executive_summary` | Project overview, research position, decision rules. |
| `01_naming_and_registry` | Stable names, short codes, condition codes, method cards, families. |
| `02_core_methods_and_protocols` | Detailed docs for SCC, BCC, BCC+, DLC, ASOE, and related protocols. |
| `03_research_and_evidence` | Evidence synthesis, physiology/cognition research map, unanswered questions, source index. |
| `04_idea_bank` | Large bank of methods/hypotheses grouped by family and priority. |
| `05_experiments_and_validation` | Pilot design, experiment recipes, metrics, analysis plan. |
| `06_production_and_mvp` | Production workflow, generator guide, MVP script files. |
| `07_data_assets` | CSVs, workbooks, and reusable data assets. |
| `08_original_artifacts` | Prior generated packs and original reports preserved. |
| `09_archive_notes` | Changelog and manifest. |

## Naming rule

Use `SCC` when testing compression only. Use `BCC` only when bionic concept anchors are present. Use `BCC+` only when BCC includes gaze-safe placement, visual-load adaptation, muted-first design, micro-rests, and full closed-caption preservation.
"""
write_md('README.md', readme)

start_here = """
# Start Here

This project is a research and production system for short-form video overlays. It began with the idea of combining compressed captions with bionic-style emphasis, then expanded into a broader field: **Cognitive Overlay Design**.

## One-sentence summary

**Cognitive Overlay Design** is about making short-form video easier to understand by showing fewer, better, better-timed, better-placed words.

## The core sequence

1. **SCC — Semantic Compression Captions**: rewrite speech into compact meaning.
2. **BCC — Bionic Compression Captioning**: add operator anchors and bionic concept anchors.
3. **BCC+ — Bionic Compression Captioning Plus**: add gaze-safe placement, visual-load adaptation, muted-first design, micro-rest rhythm, and full captions.
4. **ASOE — Adaptive Semantic Overlay Engine**: future automated system that chooses and renders overlays.

## The first experiment to run

| Condition | Code | Purpose |
|---|---|---|
| Native captions only | NCO | Baseline |
| Full transcript overlay | FTO | Verbatim overlay baseline |
| Keyword highlight transcript | KHT | Existing tool comparison |
| Semantic compression | SCC | Tests compression |
| Bionic compression captioning | BCC | Tests bionic anchors after compression |
| BCC+ | BCC+ | Tests adaptive placement/density system |
| Heavy bionic control | HBC | Negative/noisy bionic control |

## Most important comparison

> **SCC vs BCC** tells us whether bionic anchors add value beyond compression.

## Second most important comparison

> **BCC vs BCC+** tells us whether gaze-safe placement and visual-load adaptation matter more than typography.
"""
write_md('START_HERE.md', start_here)

write_md('00_executive_summary/01_project_overview.md', """
# Project Overview

The project defines and tests a new family of short-form video overlay methods. The initial idea was to combine compressed captions with bionic-style emphasis. The research direction expanded into a full design/research framework called **Cognitive Overlay Design**.

## Problem

Short-form videos are watched under hostile cognitive conditions: small screens, fast scroll behavior, UI clutter, moving visuals, speech, captions, music, and frequent muted viewing. Normal captions preserve speech, but they do not necessarily optimize for rapid gist extraction, action recall, or watch-time clarity.

## Central design problem

How can we help a viewer understand more with fewer fixations, less gaze travel, and lower visual-verbal load?

## Proposed answer

Use semantic overlays that compress the spoken message into compact meaning units, place those units where they do not block important visual information, time them to semantic beats, and preserve full captions separately for accessibility.

## Current research position

The strongest mechanism is not bionic reading. The strongest mechanism is:

> Semantic compression + signaling + gaze-safe placement + visual-load adaptation.

Bionic-style anchoring should be tested as an optional attention/memory cue, not assumed to improve reading speed.
""")

write_md('00_executive_summary/02_research_position.md', """
# Research Position

## Strongest claim

Cognitive Overlay Design may improve short-form comprehension by reducing unnecessary reading, increasing semantic signaling, and improving text placement/timing.

## Weakest claim

Bionic Reading alone makes people read captions faster. Current research does not support this as the central claim.

## Defensible framing

BCC is not speed-reading for video. It is a sparse semantic overlay method that uses partial-word anchors only after speech has already been compressed into a meaningful beat.

## What should be tested first

1. **SCC vs Full Transcript Overlay**: does compression improve gist/action recall?
2. **SCC vs BCC**: do bionic anchors add value beyond compression?
3. **BCC vs BCC+**: do placement and visual-load adaptation improve performance?
4. **BCC vs Heavy Bionic Control**: does sparse anchoring beat dense bionic formatting?

## Main predicted outcome

Semantic compression will likely produce most of the benefit. Bionic anchors may add a smaller effect for memory, attention, subjective clarity, or recognition. BCC+ may outperform BCC because placement and load adaptation reduce interference with the video.
""")

write_md('00_executive_summary/03_decision_rules.md', """
# Decision Rules

## Naming decisions

- Use **SCC** when the overlay is compression-only.
- Use **BCC** only when bionic concept anchors are present.
- Use **BCC+** only when BCC includes placement, density, muted-first, micro-rest, and full-caption layers.
- Use **DLC** when describing the architecture of full closed captions plus a separate creative overlay.
- Use **ASOE** when discussing the future automated product/system.

## Research decisions

| Result | Decision |
|---|---|
| SCC beats full transcript | Keep semantic compression as core mechanism. |
| BCC beats SCC | Keep bionic anchors as a core method feature. |
| BCC does not beat SCC | Treat bionic anchors as optional styling. |
| BCC+ beats BCC | Prioritize gaze-safe placement and visual-load adaptation. |
| Heavy bionic underperforms | Avoid dense bionic formatting except as a control. |
| Word-by-word dynamic captions underperform | Use them only for rhythm/comedy/music, not dense learning. |

## Production decisions

- If a caption exceeds 7 words, compress it.
- If text blocks mouth, eyes, hands, product, UI, or action, move it.
- If a clip cannot be understood muted, improve the semantic overlay.
- If the overlay replaces accessibility captions, the system is incomplete.
- If motion does not reveal structure, remove it.
""")

# Registry docs
core_vocab = "# Core Vocabulary\n\n" + md_table([
    {'Code':'COD','Name':'Cognitive Overlay Design','Type':'Field','Definition':'Designing text, timing, placement, motion, and emphasis in video to improve comprehension, retention, attention, and accessibility.'},
    {'Code':'PRT','Name':'Physiological Retention Typography','Type':'Branch','Definition':'Short-form/mobile overlay design based on visual physiology, gaze, attention, working memory, saliency, fatigue, and scroll behavior.'},
    {'Code':'SCCF','Name':'Semantic Compression Captioning Family','Type':'Family','Definition':'Methods that rewrite speech into compact meaning units rather than full transcript text.'},
    {'Code':'SCC','Name':'Semantic Compression Captions','Type':'Core method','Definition':'Shortest meaning-preserving overlay derived from speech.'},
    {'Code':'BCC','Name':'Bionic Compression Captioning','Type':'Named method','Definition':'SCC plus full-word operator anchors and partial-word bionic concept anchors.'},
    {'Code':'BCC+','Name':'Bionic Compression Captioning Plus','Type':'Advanced protocol','Definition':'BCC plus gaze-safe placement, visual-load adaptation, muted-first design, micro-rest rhythm, and full captions.'},
    {'Code':'DLC','Name':'Dual-Layer Captioning','Type':'Architecture','Definition':'Full closed captions for accessibility plus a separate semantic overlay for retention/gist.'},
    {'Code':'ASOE','Name':'Adaptive Semantic Overlay Engine','Type':'Future system','Definition':'Automated/human-in-loop engine that extracts, names, places, renders, scores, and tests overlays.'},
    {'Code':'MPS','Name':'Meaning per Second','Type':'Metric','Definition':'Amount of understood/remembered meaning per second watched.'},
    {'Code':'MPF','Name':'Meaning per Fixation','Type':'Metric','Definition':'Amount of understood/remembered meaning per gaze fixation or visual attention cost.'},
], ['Code','Name','Type','Definition'])
core_vocab += "\n\n## Family codes\n\n" + md_table([{'Code':c,'Family':n} for c,n in family_codes.items()], ['Code','Family'])
write_md('01_naming_and_registry/00_core_vocabulary.md', core_vocab)
write_md('01_naming_and_registry/01_condition_codes.md', "# Condition Codes\n\nUse these in pilots, file names, A/B tests, and notes.\n\n" + md_table(conditions, ['Condition Code','Short Code','Canonical Name','Definition','Type']))
write_md('01_naming_and_registry/02_method_registry_all.md', "# Full Method Registry\n\n" + md_table(methods, ['Method Code','Short Code','Canonical Name','Category','Class','Phase','Priority','Evidence Grade','Definition / What to try']))

fam_counts = Counter(m['Category Code'] for m in methods)
write_md('01_naming_and_registry/03_method_families_summary.md', "# Method Families Summary\n\n" + md_table([{'Code':c,'Family':n,'Count':fam_counts.get(c,0),'Folder':f'families/{c}_{safe(n)}.md'} for c,n in family_codes.items()], ['Code','Family','Count','Folder']))

by_family = defaultdict(list)
for m in methods:
    by_family[m['Category Code']].append(m)
for code, rows in by_family.items():
    fam_name = family_codes.get(code, rows[0].get('Category','Unknown'))
    write_md(f'01_naming_and_registry/families/{code}_{safe(fam_name)}.md', f"# {code} — {fam_name}\n\nThis family contains {len(rows)} named methods/components/controls.\n\n" + md_table(rows, ['Method Code','Short Code','Canonical Name','Class','Phase','Priority','Evidence Grade','Definition / What to try','Minimum Viable Experiment','Primary Metrics']))

# Cards
for m in methods:
    card = f"""
# {m['Method Code']} / {m['Short Code']} — {m['Canonical Name']}

## Reference label

{m['Reference Label']}

## Classification

| Field | Value |
|---|---|
| Backlog ID | {m['Backlog ID']} |
| Method code | {m['Method Code']} |
| Short code | {m['Short Code']} |
| Category | {m['Category']} |
| Family | {m['Family Name']} |
| Class | {m['Class']} |
| Phase | {m['Phase']} |
| Priority | {m['Priority']} |
| Evidence grade | {m['Evidence Grade']} |
| Status | {m['Status']} |

## Definition / what to try

{m['Definition / What to try']}

## Mechanism

{m['Mechanism']}

## Expected direction

{m['Expected Direction']}

## Failure mode

{m['Failure Mode']}

## Minimum viable experiment

{m['Minimum Viable Experiment']}

## Primary metrics

{m['Primary Metrics']}

## Source IDs

{m['Source IDs']}
"""
    write_md(f"01_naming_and_registry/method_cards/{m['Method Code']}_{safe(m['Short Code'])}_{safe(m['Canonical Name'])}.md", card)

# Core protocols
protocol_docs = {
'01_scc_semantic_compression_captions.md': """
# SCC — Semantic Compression Captions

## Definition

Semantic Compression Captions rewrite speech into the shortest meaning-preserving phrases suitable for short-form video overlays.

## Purpose

Reduce the amount of text the viewer must process while preserving the main point, instruction, contrast, or payoff.

## Example

Spoken:

> Most people don’t fail because they lack motivation. They fail because their day has no structure.

SCC:

> Not motivation.  
> Structure.

## What SCC tests

SCC tests whether compression itself improves gist recall, action recall, and perceived ease compared with full transcript overlays.
""",
'02_bcc_bionic_compression_captioning.md': """
# BCC — Bionic Compression Captioning

## Definition

BCC combines semantic compression with two anchor types:

1. **Full-word operator anchors**: **Not**, **Stop**, **Less**, **First**, **Then**.
2. **Bionic concept anchors**: partial-word emphasis on core concepts, such as **moti**vation, **struc**ture, **fric**tion.

## Example

> **Not** **moti**vation.  
> **Struc**ture.

## Purpose

Test whether sparse typographic anchoring improves attention, recognition, or memory after the text has already been compressed.

## Core test

Compare SCC against BCC. If BCC does not beat SCC, bionic anchors become optional styling.
""",
'03_bcc_plus_advanced_protocol.md': """
# BCC+ — Bionic Compression Captioning Plus

## Definition

BCC+ is the advanced protocol: BCC plus gaze-safe placement, visual-load adaptation, muted-first design, micro-rest rhythm, and full closed-caption preservation.

## Formula

> BCC+ = SCC + operator anchors + concept anchors + gaze-safe placement + adaptive density + muted-first comprehension + micro-rest rhythm + full captions

## Example sequence

> **Not** **moti**vation.  
> **Struc**ture.  
> Reduce **fric**tion.  
> Shrink the **start**.

## Key comparison

> BCC vs BCC+

If BCC+ beats BCC, the strongest factor may be adaptive overlay design rather than bionic anchors.
""",
'04_dlc_dual_layer_captioning.md': """
# DLC — Dual-Layer Captioning

## Definition

Dual-Layer Captioning separates accessibility captions from creative semantic overlays.

## Layer 1: Closed captions

Full synchronized captions preserve speech, speaker identification, and meaningful non-speech audio.

## Layer 2: Semantic overlay

A separate overlay presents compressed meaning for retention, gist, and muted-first comprehension.

## Why this matters

BCC/BCC+ should not replace full captions. The semantic overlay can be punchy and compressed, but viewers still need access to the full spoken content where necessary.
""",
'05_asoe_adaptive_semantic_overlay_engine.md': """
# ASOE — Adaptive Semantic Overlay Engine

## Definition

The Adaptive Semantic Overlay Engine is the future product/system direction. It would generate and evaluate overlays using semantic extraction, visual analysis, placement rules, and experiment feedback.

## Required modules

1. Transcript ingestion.
2. Proposition extraction.
3. Semantic beat extraction.
4. Method selection.
5. Anchor selection.
6. Visual-load prediction.
7. Face/mouth/hand/object detection.
8. Platform UI safe-zone templates.
9. Gaze/saliency conflict prediction.
10. Renderer/exporter.
11. Rubric auto-scorer.
12. A/B variant generator.
13. Analytics ingestion.
"""
}
for fn, content in protocol_docs.items():
    write_md(f'02_core_methods_and_protocols/{fn}', content)

# Research docs
source_urls=set()
for f in list(base.glob('*.md')) + list(base.glob('*.csv')):
    txt = f.read_text(encoding='utf-8', errors='ignore')
    for url in re.findall(r'https?://[^\s)\]]+', txt):
        source_urls.add(url.rstrip('.,'))
write_md('03_research_and_evidence/01_evidence_synthesis.md', """
# Evidence Synthesis

## Core finding

The best-supported direction is **semantic compression plus visual signaling**, not raw speed-reading. The research logic points toward reducing unnecessary text, cueing structure, preserving full captions, and placing overlays to reduce conflict with the visual scene.

## Research pillars

### Caption speed and density

Subtitle-speed research suggests that faster subtitles can reduce complete reading and comprehension. The design implication is to reduce word count rather than forcing faster reading.

### Partial captioning

Partial synchronized captioning suggests that under some conditions, not every transcript word needs to appear for comprehension to remain intact. This supports testing compressed semantic overlays.

### Signaling and multimedia learning

Signaling research supports cues that highlight relevant structure and reduce cognitive load. This supports operator anchors, beat cards, Problem → Cause → Fix structures, and sparse keyword emphasis.

### Visual physiology

Human vision is foveated, peripheral text recognition is limited, and crowding degrades recognition. Overlay text should be short, high-contrast, and placed away from clutter.

### Meaning-guided attention

Meaning can guide attention beyond low-level salience. The overlay should reveal semantic structure rather than merely attracting attention with motion/color.

### Sound-off viewing

When video is watched without sound, visual load increases because text becomes the primary verbal information channel. Muted-first overlay design is therefore a distinct mode.

### Accessibility

Full captions must remain available. Creative overlays should not replace synchronized captions for speech and meaningful non-speech audio.
""")
write_md('03_research_and_evidence/02_physiology_and_cognition.md', """
# Physiology and Cognition Map

## Visual channel bottleneck

Short-form viewers process speech, face, motion, UI, captions, overlays, and platform signals simultaneously. If audio is muted, the visual channel carries nearly all verbal meaning.

## Foveal/peripheral constraint

Detailed text must be foveated. Peripheral overlays should be cues, not full sentences.

## Visual crowding

Text placed near other text, UI, stickers, busy backgrounds, or patterned surfaces becomes harder to recognize. This justifies crowding-aware placement and backplates.

## Working memory

Viewers cannot hold long sentence fragments while also processing motion. Use semantic beats and one-idea-per-screen.

## Attention and saliency

Bright/moving text grabs attention, but meaning-rich text earns attention. The goal is not to maximize salience; it is to maximize meaning gained per gaze cost.

## Speech perception

The mouth and face support speech comprehension, especially when audio is degraded. Talking-head overlays should avoid covering mouth and eyes.

## Fatigue

Continuous text and motion can produce a constant reading task. Micro-rest rhythm gives the eyes time to return to the video.
""")
write_md('03_research_and_evidence/03_research_questions.md', """
# Research Questions and Unknowns

1. Does **BCC** outperform **SCC** after compression is already done?
2. Does **BCC+** outperform **BCC** because of placement and adaptive density?
3. What compression ratio preserves gist without becoming cryptic?
4. What highlight density is optimal for short-form video?
5. Where should overlays be placed for each content type?
6. Should semantic text appear before, during, or after the spoken phrase?
7. How much motion helps before it becomes distracting?
8. Should audio-on and muted viewing use different overlay strategies?
9. Which viewer groups benefit or suffer: L2, DHH, dyslexic, ADHD, expert, novice, older viewers?
10. Which metric best captures success: meaning per second, meaning per fixation, gist recall, action recall, or completion rate?
""")
write_md('03_research_and_evidence/04_hypothesis_backlog.md', "# Hypothesis Backlog\n\n" + md_table(methods, ['Backlog ID','Method Code','Short Code','Canonical Name','Priority','Evidence Grade','Mechanism','Expected Direction','Failure Mode','Minimum Viable Experiment','Primary Metrics']))
write_md('03_research_and_evidence/05_source_index.md', "# Source Index\n\nURLs extracted from prior reports and notes.\n\n" + '\n'.join(f'{i}. {u}' for i,u in enumerate(sorted(source_urls),1)))

# Idea bank
write_md('04_idea_bank/01_big_idea_bank_all.md', "# Big Idea Bank\n\n" + md_table(ideas, ['ID','Category','Idea / Hypothesis','What to try','Mechanism to test','Expected direction','Failure mode','Minimum viable experiment','Primary metrics','Evidence grade','Priority','Source IDs']))
priority_order={'P0':0,'P1':1,'P2':2,'P3':3}
priority_methods = sorted(methods, key=lambda r: (priority_order.get(r.get('Priority','P9'),9), r.get('Phase',''), r.get('Method Code','')))
write_md('04_idea_bank/02_priority_queue.md', "# Priority Queue\n\n" + md_table(priority_methods[:80], ['Method Code','Short Code','Canonical Name','Category','Phase','Priority','Evidence Grade','Minimum Viable Experiment','Primary Metrics']))
by_cat=defaultdict(list)
for row in ideas: by_cat[row['Category']].append(row)
for cat, rows in by_cat.items():
    write_md(f'04_idea_bank/families/{safe(cat)}.md', f"# {cat}\n\n{len(rows)} ideas/hypotheses.\n\n" + md_table(rows, ['ID','Idea / Hypothesis','What to try','Mechanism to test','Expected direction','Failure mode','Minimum viable experiment','Primary metrics','Evidence grade','Priority']))

# Experiments
write_md('05_experiments_and_validation/01_validation_protocol.md', """
# Validation Protocol

## Purpose

Validate whether semantic compression, bionic anchors, gaze-safe placement, and visual-load adaptation improve short-form video outcomes.

## Main conditions

| Condition | Code | Purpose |
|---|---|---|
| Native captions only | NCO | Platform baseline |
| Full transcript overlay | FTO | Verbatim overlay baseline |
| Keyword highlight transcript | KHT | Existing-tool comparison |
| Semantic compression | SCC | Compression-only test |
| Bionic compression captioning | BCC | Tests bionic anchors after compression |
| BCC+ | BCC+ | Tests adaptive placement/density/muted-first protocol |
| Heavy bionic control | HBC | Negative/noisy bionic control |
| Word-by-word dynamic captions | WDC | Existing dynamic caption comparison |

## Main measures

Gist recall, action recall, contrast recall, exact wording recall, muted comprehension, visual recall, perceived effort, completion rate, rewatch rate, save/share rate, and gaze metrics when available.

## Decision rule

If SCC beats full transcript, keep semantic compression. If BCC beats SCC, keep bionic anchors. If BCC+ beats BCC, prioritize adaptive placement/density as a core product capability.
""")
write_md('05_experiments_and_validation/02_first_pilot.md', """
# First Pilot

## Pilot goal

Run the smallest useful test to identify whether BCC should remain a core method or whether semantic compression alone does most of the work.

## Pilot design

- 6–12 videos, 15–45 seconds each.
- Categories: productivity, study/learning, fitness/health, finance/business, tutorial/demo, story/commentary.
- Conditions: FTO, KHT, SCC, BCC, BCC+, HBC, optionally NCO/WDC.
- Viewing modes: audio-on and muted.
- Participants: 30–50 for pilot; 120–250 for validation.

## Example variants

FTO: full transcript.  
KHT: full transcript with key words highlighted.  
SCC: `Not motivation. / Structure.`  
BCC: `**Not** **moti**vation. / **Struc**ture.`  
BCC+: `**Not** **moti**vation. / **Struc**ture. / Reduce **fric**tion. / Shrink the **start**.`  
HBC: heavy bionic formatting across most words.
""")
write_md('05_experiments_and_validation/03_experiment_recipes.md', """
# Experiment Recipes

## E1 — Core Isolation

Question: Does BCC beat SCC? Conditions: SCC vs BCC. Metrics: gist recall, contrast recall, perceived effort, completion rate.

## E2 — Adaptive Protocol Test

Question: Does BCC+ beat BCC? Conditions: BCC vs BCC+. Metrics: visual recall, muted comprehension, completion rate, perceived effort.

## E3 — Placement Test

Question: Does gaze-safe placement beat bottom-fixed placement? Conditions: BFP vs GSP.

## E4 — Timing Offset Test

Question: Does predictive semantic priming help? Conditions: PSP 400 ms, PSP 200 ms, SYNC, POST 200 ms, POST 400 ms.

## E5 — Visual Load Adaptation

Question: Should caption density change with frame complexity? Conditions: fixed density vs VLAC.

## E6 — Motion Dose

Question: How much motion helps before it overloads? Conditions: static, fade/scale, logic motion, word pop, karaoke, constant kinetic.

## E7 — Audio Mode Test

Question: Should audio-on and muted viewers receive different overlay strategies?

## E8 — Highlight Density

Question: What emphasis density is best? Conditions: 0%, 5%, 10–15%, 25%, 50%, heavy bionic.

## E9 — Micro-Rest Rhythm

Question: Do no-text gaps improve visual recall and reduce fatigue?

## E10 — Viewer Segment Test

Question: Which viewer groups benefit from which overlay modes?
""")
write_md('05_experiments_and_validation/04_measurement_dictionary.md', """
# Measurement Dictionary

| Metric | Definition | Why it matters |
|---|---|---|
| Gist recall | Viewer can state the main point. | Tests rapid meaning extraction. |
| Action recall | Viewer knows what to do next. | Tests practical usefulness. |
| Contrast recall | Viewer remembers the false belief and correction. | Tests operator-first and contrast methods. |
| Exact recall | Viewer remembers specific wording. | Full captions may win here. |
| Visual recall | Viewer remembers what happened visually. | Detects if text stole too much attention. |
| Muted comprehension | Viewer understands without sound. | Tests muted-first design. |
| Perceived effort | Viewer rates difficulty. | Captures cognitive load subjectively. |
| Completion rate | Fraction of video watched. | Platform retention signal. |
| Rewatch rate | Frequency of replay. | Can indicate value or confusion. |
| Saves/shares | Platform utility/memorability signal. | Measures perceived usefulness. |
| Text dwell time | Gaze time on overlay text. | Measures visual cost. |
| Face/object dwell time | Gaze time on important visual regions. | Measures video preservation. |
| Meaning per Second | Recall/understanding divided by seconds watched. | Platform-friendly efficiency metric. |
| Meaning per Fixation | Recall/understanding divided by fixation cost. | Research-grade efficiency metric. |
""")
write_md('05_experiments_and_validation/05_analysis_plan.md', """
# Analysis Plan

## Primary contrasts

1. SCC vs FTO: tests compression.
2. BCC vs SCC: tests bionic anchors.
3. BCC+ vs BCC: tests adaptive protocol.
4. HBC vs BCC: tests sparse vs heavy bionic formatting.
5. GSP vs BFP: tests placement.
6. PSP vs SYNC vs POST: tests timing.
7. VLAC vs fixed density: tests visual-load adaptation.

## Interpretation matrix

| Result | Meaning |
|---|---|
| SCC > FTO | Compression is useful. |
| BCC > SCC | Bionic anchors add value. |
| BCC ≈ SCC | Bionic anchors are optional. |
| BCC+ > BCC | Placement/load/timing are stronger than typography alone. |
| HBC < BCC | Dense bionic styling is harmful or noisy. |
| GSP > BFP | Placement should be adaptive. |
| PSP > SYNC | Predictive semantic priming is useful. |
| VLAC > fixed | Caption density should adapt to visual load. |
""")

# Production workflow
write_md('06_production_and_mvp/01_production_workflow.md', """
# Production Workflow

## Step 1 — Transcript

Create a full transcript and preserve it for closed captions.

## Step 2 — Proposition extraction

Identify the underlying claim or instruction.

## Step 3 — Semantic beats

Break the proposition into short beats.

## Step 4 — Choose method

Use SCC for clean compression, BCC when testing bionic anchors, and BCC+ when using placement/density/muted-first rules.

## Step 5 — Add anchors

Full-bold operators: Not, No, Stop, Start, Less, More, First, Then.  
Partial-bold concept words: **moti**vation, **struc**ture, **fric**tion, **trig**ger, **sys**tem.

## Step 6 — Place safely

Avoid covering mouth, eyes, hands, object, UI, action, diagrams, or native captions.

## Step 7 — Time to beats

One-word impact: 0.5–0.8 sec. Two to three words: 0.8–1.2 sec. Four to seven words: 1.2–2.0 sec. Eight or more words: rewrite.

## Step 8 — Muted test

Watch without sound. If the main idea is unclear, add one clarifying word or beat.

## Step 9 — Visual interference test

If the overlay blocks what the viewer needs to process, move or shorten it.
""")
prod = base/'bcc_plus_production_guide.md'
if prod.exists(): shutil.copy2(prod, root/'06_production_and_mvp/02_bcc_plus_production_guide_original.md')
write_md('06_production_and_mvp/03_overlay_generator_guide.md', """
# Overlay Generator Guide

The current prototype includes `bcc_overlay_generator.py`. It is a human-in-the-loop asset generator rather than a fully automated ASOE system.

## Expected input

```csv
video_id,start,end,spoken_text,semantic_caption,role,keywords,placement_zone,visual_load
```

## Expected outputs

- SRT captions
- VTT captions
- ASS subtitle/overlay files
- JSON overlay plans
- Editor CSV exports

## Future improvements

Automatic proposition extraction, semantic beat detection, anchor selection, face/mouth/hand/object detection, visual-load prediction, saliency-safe placement, platform safe-zone templates, rubric auto-scoring, and A/B variant generation.
""")

# notes and manifest
write_md('09_archive_notes/CHANGELOG.md', f"""
# Changelog

## v8 — Master organized archive

Created on {datetime.date.today().isoformat()}.

### Added

- Consolidated all prior packs into one archive.
- Added `README.md` and `START_HERE.md`.
- Added detailed markdown registry for core vocabulary, condition codes, method families, method cards, and experiments.
- Added individual method cards for {len(methods)} named methods/components/controls.
- Added family-level markdown files for all method families.
- Added source index extracted from prior reports.
- Added first pilot, validation protocol, analysis plan, and production workflow.
- Preserved original files in `08_original_artifacts`.

### Current research stance

The strongest likely system is Semantic Compression + Signaling + Gaze-Safe Placement + Visual-Load Adaptation. Bionic anchors remain worth testing but should not be treated as the main mechanism until SCC vs BCC validates them.
""")

# Manifest last
manifest = []
for p in sorted(root.rglob('*')):
    if p.is_file():
        manifest.append(f"- `{p.relative_to(root)}` ({p.stat().st_size} bytes)")
write_md('09_archive_notes/MANIFEST.md', "# Manifest\n\n" + '\n'.join(manifest))

# Zip
if zip_path.exists(): zip_path.unlink()
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file():
            z.write(p, p.relative_to(root.parent))
print(zip_path)
print(sum(1 for p in root.rglob('*') if p.is_file()))
print(zip_path.stat().st_size)
