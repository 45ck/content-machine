# VLD-015 / RFL — Readability Failure Log

## Reference label

VLD-015 / RFL — Readability Failure Log

## Classification

| Field | Value |
|---|---|
| Backlog ID | H105 |
| Method code | VLD-015 |
| Short code | RFL |
| Category | Visual Load / Clutter |
| Family | Visual Load and Clutter |
| Class | Load-Control Method |
| Phase | Pilot second |
| Priority | P1 |
| Evidence grade | Strong practical / direct test needed |
| Status | Backlog |

## Definition / what to try

Annotate every point where a tester missed or struggled with text.

## Mechanism

Creates iterative quality loop.

## Expected direction

Fewer recurring failures.

## Failure mode

Manual work needed.

## Minimum viable experiment

No log vs failure-log revision.

## Primary metrics

Revision improvement rate

## Source IDs

S28; S30
