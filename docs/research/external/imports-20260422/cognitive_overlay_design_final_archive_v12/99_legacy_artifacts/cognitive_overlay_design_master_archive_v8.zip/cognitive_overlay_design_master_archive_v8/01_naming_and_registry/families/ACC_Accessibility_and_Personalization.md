# ACC — Accessibility and Personalization

This family contains 10 named methods/components/controls.

| Method Code | Short Code | Canonical Name | Class | Phase | Priority | Evidence Grade | Definition / What to try | Minimum Viable Experiment | Primary Metrics |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ACC-001 | CCP | Closed-Caption Preservation Rule | Rule / Mode | Pilot first | P0 | Strong requirement | Always keep full captions available when using creative overlays. | User tests with overlay only vs dual layer. | Access rating; comprehension |
| ACC-002 | LSM | L2 Simplified Mode | Rule / Mode | Explore later | P2 | Moderate adjacent | Use simpler vocabulary and more context for second-language viewers. | Native vs L2-tailored captions. | L2 gist; effort |
| ACC-003 | ESM | Expert Shorthand Mode | Rule / Mode | Explore later | P2 | Moderate adjacent | Use domain shorthand for expert audiences. | Expert vs novice overlay versions. | Comprehension by expertise |
| ACC-004 | NLM | Novice Label Mode | Rule / Mode | Pilot second | P1 | Strong adjacent | Add labels for unfamiliar concepts before compressing heavily. | Labels vs no labels for beginners. | Beginner gist; effort |
| ACC-005 | DFV | Dyslexia-Friendly Variant Test | Access / Personalization Method | Explore later | P3 | Speculative / direct test needed | Compare bionic, LARF-like annotation, spacing, and plain compression for dyslexic viewers. | Dyslexic participants by overlay type. | Reading ease; comprehension |
| ACC-006 | LMM | Low-Motion Mode | Rule / Mode | Pilot second | P1 | Moderate adjacent | Provide a static/low-animation overlay for viewers sensitive to motion. | Static vs kinetic variants. | Comfort; retention |
| ACC-007 | OVD | Older Viewer Duration Mode | Rule / Mode | Explore later | P2 | Speculative / direct test needed | Increase caption duration and font size for older viewers. | Standard vs longer/larger captions. | Readability; effort |
| ACC-008 | CBSC | Color-Blind Safe Coding | Access / Personalization Method | Pilot first | P0 | Strong requirement | Never rely on color alone; pair with labels/icons/shape. | Color-only vs color+label. | Role identification; access rating |
| ACC-009 | RSA | Reader-Speed Adaptive Mode | Rule / Mode | Explore later | P3 | Speculative / future | Allow overlays to persist longer or simplify if viewer often pauses/rewatches. | Manual slow/fast versions. | Comprehension by reading speed |
| ACC-010 | VSA | Viewer-State Adaptive Mode | Rule / Mode | Explore later | P3 | Speculative / future | Switch overlay mode based on audio-on/off, device, language, and content category. | Static vs adaptive modes. | Gist; effort; retention |
