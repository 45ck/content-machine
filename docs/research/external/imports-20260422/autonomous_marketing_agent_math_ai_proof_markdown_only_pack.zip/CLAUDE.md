# Claude Code Entry Point

Read `AGENTS.md` first.

Use this repository as a Markdown-native autonomous marketing operating system.

## Claude Code usage

Use skills and subagents for specialized work:

- market research
- buyer-state diagnosis
- tactic selection
- ad generation
- landing page generation
- platform payload planning
- experiment analysis
- memory updates

Claude Code supports project-level settings, permissions, hooks, custom subagents, and skills. Use those features to keep the agent operating inside repo-local instructions and reusable Markdown context.

Primary docs:

- https://code.claude.com/docs/en/overview
- https://code.claude.com/docs/en/sub-agents
- https://code.claude.com/docs/en/settings
- https://code.claude.com/docs/en/permissions
- https://code.claude.com/docs/en/hooks
- https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview

## Model stance

For complex campaign reasoning, frontier models such as Claude Opus 4.7 are relevant because Anthropic positions Opus 4.7 as its most capable generally available model for complex reasoning and agentic coding, with 1M context and 128k max output support.

Source: https://platform.claude.com/docs/en/about-claude/models/whats-new-claude-4-7
